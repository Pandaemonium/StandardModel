import Mathlib
import PhysicsSM.Spinor.SpinorTenfoldGammaSymm

/-!
# Spinor.SpinorTenfoldFierzKernel

Kernel-checkable closed-form machinery for the basis-level symmetrized
`Spin(10)` Fierz identity.

The key fact is that `cliffordActionZ (gBasisZ S T) (basisZ U)` is **a single
signed wedge monomial** (the closed form `termData S T U`): the `a`-half of
`gBasisZ S T` is supported on the unique index `i ∈ S` with `S.erase i = Tᶜ`,
and the `b`-half on the unique `i ∉ S` with `insert i S = Tᶜ`, and the two
halves require incompatible cardinalities, so at most one monomial survives.

This reduces the symmetrized Fierz identity to a finite per-configuration sign
cancellation that the Lean kernel can check by `decide` on the cheap
`(coeff, target)` data, with no `native_decide`.

## Provenance

Proofs produced by the Aristotle proof agent
(job `93e29d35-37f8-4c3c-bad7-02b5fca82612`, task
`AgentTasks/spin10-fierz-kernel-decide-aristotle-2026-06-10.md`) and reviewed
for semantic alignment. The `cancel_all` enumeration is plain kernel `decide`
with a raised heartbeat budget; the identity is independently verified by
`Scripts/oracle/validate_spinor_tenfold.py`. The main theorems built on
`fierzZ_three` are in `PhysicsSM.Spinor.SpinorTenfoldFierz`.

Status: trusted — no `sorry`, no `axiom` (in particular no `native_decide`).
-/

namespace PhysicsSM.Spinor.SpinorTenfold

open Finset

/-- The Clifford action written as a sum of scaled basis operators (integer
mirror of `cliffordAction_eq_sum`). -/
theorem cliffordActionZ_eq_sum (v : V10Z) (f : FockSpinorZ) :
    cliffordActionZ v f
      = (∑ i, v.1 i • wedgeZ i f) + (∑ i, v.2 i • contractZ i f) := by
  funext S
  simp [cliffordActionZ, Finset.sum_apply]

/-- Closed-form single monomial `(coeff, target)` for
`cliffordActionZ (gBasisZ S T) (basisZ U)`.

The `a`-half index is the unique `i ∈ S` with `S.erase i = Tᶜ` and `i ∉ U`;
the `b`-half index is the unique `i ∉ S` with `insert i S = Tᶜ` and `i ∈ U`.
At most one of these exists. -/
def termData (S T U : Finset (Fin 5)) : ℤ × Finset (Fin 5) :=
  match (List.finRange 5).find? (fun i => decide (i ∈ S ∧ S.erase i = Tᶜ ∧ i ∉ U)) with
  | some i => ((gBasisZ S T).1 i * opSignZ i (insert i U), insert i U)
  | none =>
    match (List.finRange 5).find? (fun i => decide (i ∉ S ∧ insert i S = Tᶜ ∧ i ∈ U)) with
    | some i => ((gBasisZ S T).2 i * opSignZ i (U.erase i), U.erase i)
    | none => (0, ∅)

/-
The `a`-half of `gBasisZ S T` is supported on at most one index: if `i ∈ S`
with `S.erase i = Tᶜ`, then `(gBasisZ S T).1 j = 0` for every `j ≠ i`.
-/
theorem gBasisZ_fst_eq_zero_of_ne (S T : Finset (Fin 5)) {i j : Fin 5}
    (hi : i ∈ S) (he : S.erase i = Tᶜ) (hj : j ≠ i) :
    (gBasisZ S T).1 j = 0 := by
  unfold gBasisZ; simp +decide [ he, hi, hj.symm ] ;
  intro hjS hjT; replace he := congr_arg ( fun x => j ∈ x ) he; simp_all +decide [ Finset.ext_iff ] ;
  grind

/-
When the `a`-half geometry holds (`i ∈ S`, `S.erase i = Tᶜ`), the `b`-half
of `gBasisZ S T` vanishes identically (incompatible cardinalities).
-/
theorem gBasisZ_snd_eq_zero_of_aActive (S T : Finset (Fin 5)) {i : Fin 5}
    (hi : i ∈ S) (he : S.erase i = Tᶜ) (j : Fin 5) :
    (gBasisZ S T).2 j = 0 := by
  unfold gBasisZ;
  simp +decide [ Finset.ext_iff ] at he ⊢;
  grind +ring

/-
The `b`-half of `gBasisZ S T` is supported on at most one index.
-/
theorem gBasisZ_snd_eq_zero_of_ne (S T : Finset (Fin 5)) {i j : Fin 5}
    (hi : i ∉ S) (he : insert i S = Tᶜ) (hj : j ≠ i) :
    (gBasisZ S T).2 j = 0 := by
  unfold gBasisZ
  simp only [Prod.snd]
  rw [if_neg]
  rintro ⟨hjS, hjc⟩
  have h1 : insert j S = Tᶜ := (compl_eq_comm.mp hjc).symm
  have h2 : insert j S = insert i S := h1.trans he.symm
  have hjmem : j ∈ insert i S := by rw [← h2]; exact Finset.mem_insert_self j S
  rcases Finset.mem_insert.mp hjmem with h | h
  · exact hj h
  · exact hjS h

/-
When the `b`-half geometry holds (`i ∉ S`, `insert i S = Tᶜ`), the `a`-half
of `gBasisZ S T` vanishes identically (incompatible cardinalities).
-/
theorem gBasisZ_fst_eq_zero_of_bActive (S T : Finset (Fin 5)) {i : Fin 5}
    (hi : i ∉ S) (he : insert i S = Tᶜ) (j : Fin 5) :
    (gBasisZ S T).1 j = 0 := by
  unfold gBasisZ;
  simp_all +decide [ Finset.ext_iff ];
  grind

/-
The `a`-half index, if any, is genuinely the head returned by `find?`.
-/
theorem find?_aHalf_eq (S T U : Finset (Fin 5)) {i : Fin 5}
    (hi : i ∈ S) (he : S.erase i = Tᶜ) (hU : i ∉ U) :
    (List.finRange 5).find? (fun k => decide (k ∈ S ∧ S.erase k = Tᶜ ∧ k ∉ U)) = some i := by
  have huniq : ∀ k : Fin 5, k ∈ S → S.erase k = Tᶜ → k = i := by
    intro k hkS hkc
    by_contra hki
    have heq : S.erase k = S.erase i := by rw [hkc, he]
    have hik : i ∈ S.erase k := by
      rw [Finset.mem_erase]; exact ⟨fun h => hki h.symm, hi⟩
    rw [heq] at hik
    exact (Finset.notMem_erase i S) hik
  have hpi : (decide (i ∈ S ∧ S.erase i = Tᶜ ∧ i ∉ U)) = true := by
    simp [hi, he, hU]
  have hfalse : ∀ k : Fin 5, k ≠ i →
      (decide (k ∈ S ∧ S.erase k = Tᶜ ∧ k ∉ U)) = false := by
    intro k hk
    simp only [decide_eq_false_iff_not, not_and]
    intro hkS hkc _
    exact hk (huniq k hkS hkc)
  rw [show List.finRange 5 = [0,1,2,3,4] from by decide]
  fin_cases i
  · exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 1 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 1 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 2 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 1 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 2 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 3 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi

/-
The `b`-half index, if any, is genuinely the head returned by `find?`.
-/
theorem find?_bHalf_eq (S T U : Finset (Fin 5)) {i : Fin 5}
    (hi : i ∉ S) (he : insert i S = Tᶜ) (hU : i ∈ U) :
    (List.finRange 5).find? (fun k => decide (k ∉ S ∧ insert k S = Tᶜ ∧ k ∈ U)) = some i := by
  have huniq : ∀ k : Fin 5, k ∉ S → insert k S = Tᶜ → k = i := by
    intro k hkS hkc
    have heq : insert k S = insert i S := by rw [hkc, he]
    have hkmem : k ∈ insert i S := by rw [← heq]; exact Finset.mem_insert_self k S
    rcases Finset.mem_insert.mp hkmem with h | h
    · exact h
    · exact absurd h hkS
  have hpi : (decide (i ∉ S ∧ insert i S = Tᶜ ∧ i ∈ U)) = true := by
    simp [hi, he, hU]
  have hfalse : ∀ k : Fin 5, k ≠ i →
      (decide (k ∉ S ∧ insert k S = Tᶜ ∧ k ∈ U)) = false := by
    intro k hk
    simp only [decide_eq_false_iff_not, not_and]
    intro hkS hkc _
    exact hk (huniq k hkS hkc)
  rw [show List.finRange 5 = [0,1,2,3,4] from by decide]
  fin_cases i
  · exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 1 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 1 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 2 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi
  · rw [List.find?_cons_of_neg (by rw [hfalse 0 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 1 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 2 (by decide)]; decide),
        List.find?_cons_of_neg (by rw [hfalse 3 (by decide)]; decide)]
    exact List.find?_cons_of_pos hpi

/-
**The closed form is correct**: the Clifford action of a basis
gamma-bilinear on a basis monomial is a single signed wedge monomial.
-/
set_option maxHeartbeats 1000000 in
-- The case analysis over the two `find?` branches with the sum collapses is
-- somewhat heavy; the default heartbeat budget is not quite enough.
theorem termData_eq (S T U : Finset (Fin 5)) :
    cliffordActionZ (gBasisZ S T) (basisZ U)
      = (termData S T U).1 • basisZ (termData S T U).2 := by
  rw [cliffordActionZ_eq_sum];
  unfold termData;
  cases' hfa : List.find? ( fun i => decide ( i ∈ S ∧ S.erase i = Tᶜ ∧ i ∉ U ) ) ( List.finRange 5 ) with i;
  · cases' hfb : List.find? ( fun i => decide ( i ∉ S ∧ insert i S = Tᶜ ∧ i ∈ U ) ) ( List.finRange 5 ) with i;
    · rw [ Finset.sum_eq_zero, Finset.sum_eq_zero ] <;> simp +decide [ * ];
      · intro i; by_cases hi : i ∈ U <;> simp_all +decide [ contractZ_basisZ_of_mem, contractZ_basisZ_of_not_mem ] ;
        unfold gBasisZ; aesop;
      · intro j; by_cases hjU : j ∈ U <;> simp_all +decide [ wedgeZ_basisZ_of_not_mem, wedgeZ_basisZ_of_mem ] ;
        unfold gBasisZ; aesop;
    · rw [ Finset.sum_eq_zero, Finset.sum_eq_single i ] <;> simp_all +decide [ Finset.sum_eq_zero_iff_of_nonneg, mul_nonneg ];
      · rw [ mul_assoc, contractZ_basisZ_of_mem ];
        · ext; simp [basisZ];
        · grind;
      · intro j hj; simp_all +decide [ gBasisZ ] ;
        intro hj₁ hj₂; specialize hfa j; simp_all +decide [ Finset.ext_iff ] ;
        grind;
      · intro x; by_cases hx : x ∈ S <;> simp_all +decide [ gBasisZ ] ;
        intro hx'; specialize hfa x hx; simp_all +decide [ Finset.ext_iff ] ;
        grind;
  · have hfa' : i ∈ S ∧ S.erase i = Tᶜ ∧ i ∉ U := by
      grind;
    rw [ Finset.sum_eq_single i, Finset.sum_eq_zero ] <;> simp_all +decide [ Finset.sum_ite ];
    · rw [ wedgeZ_basisZ_of_not_mem i U hfa'.2.2 ] ; ext ; simp +decide [ mul_assoc, mul_comm, mul_left_comm ];
      unfold basisZ; aesop;
    · intro x; rw [ gBasisZ_snd_eq_zero_of_aActive S T hfa'.1 hfa'.2.1 x ] ; simp +decide ;
    · intro j hj; rw [ gBasisZ_fst_eq_zero_of_ne S T hfa'.1 hfa'.2.1 hj ] ; simp +decide ;

/-- Cancellation predicate for three signed monomials: at every target the
signed coefficients sum to zero. -/
abbrev cancel3 (m1 m2 m3 : ℤ × Finset (Fin 5)) : Prop :=
  ∀ Y ∈ ({m1.2, m2.2, m3.2} : Finset (Finset (Fin 5))),
    (if m1.2 = Y then m1.1 else 0) + (if m2.2 = Y then m2.1 else 0)
      + (if m3.2 = Y then m3.1 else 0) = 0

/-
If three signed monomials cancel at every target, their sum is zero.
-/
theorem cancel3_imp_zero (m1 m2 m3 : ℤ × Finset (Fin 5)) (h : cancel3 m1 m2 m3) :
    m1.1 • basisZ m1.2 + m2.1 • basisZ m2.2 + m3.1 • basisZ m3.2 = 0 := by
  convert h using 1;
  constructor <;> intro h <;> simp_all +decide [ funext_iff, Finset.sum_apply' ];
  · assumption;
  · intro x; specialize h x; by_cases hx : x = m1.2 <;> by_cases hx' : x = m2.2 <;> by_cases hx'' : x = m3.2 <;> simp_all +decide [ basisZ ] ;
    all_goals split_ifs at h <;> simp_all +decide [ add_assoc ] ;

set_option maxHeartbeats 4000000 in
-- The per-configuration sign cancellation over all even triples, checked by the
-- Lean kernel via `decide` on the cheap `(coeff, target)` data (no
-- `native_decide`). The large `maxHeartbeats`/`maxRecDepth` are needed because
-- the kernel enumerates all `32³` triples of even subsets.
set_option maxRecDepth 10000 in
theorem cancel_all :
    ∀ S T U : Finset (Fin 5), S.card % 2 = 0 → T.card % 2 = 0 → U.card % 2 = 0 →
      cancel3 (termData S T U) (termData S U T) (termData T U S) := by sorry

/-- The three-term symmetrized Fierz identity in the integer Fock mirror. -/
theorem fierzZ_three (S T U : Finset (Fin 5))
    (hS : S.card % 2 = 0) (hT : T.card % 2 = 0) (hU : U.card % 2 = 0) :
    cliffordActionZ (gBasisZ S T) (basisZ U)
      + cliffordActionZ (gBasisZ S U) (basisZ T)
      + cliffordActionZ (gBasisZ T U) (basisZ S) = 0 := by
  rw [termData_eq S T U, termData_eq S U T, termData_eq T U S]
  exact cancel3_imp_zero _ _ _ (cancel_all S T U hS hT hU)

end PhysicsSM.Spinor.SpinorTenfold
