import CodeLatticeE8.Octonion.Basic
import CodeLatticeE8.E8.RootBridge

/-!
# Octavian closure verification – slice 1 of 4

Kernel-verified finite checks for short-shell vectors 0–59
(the 16 coordinate units plus the first 44 weight-four vectors).
-/

set_option linter.style.longLine false
set_option linter.style.setOption false
set_option linter.style.maxHeartbeats false

namespace CodeLatticeE8.Octonion

open CodeLatticeE8.Code
open CodeLatticeE8.ConstructionA
open CodeLatticeE8.E8
open CodeLatticeE8.E8.RootBridge

private instance : DecidablePred (· ∈ hammingConstructionA) := fun z =>
  decidable_of_iff _
    (mem_hammingConstructionA_iff_parityCheck z).symm

-- Vectors 0–29 (16 coordinate + 14 weight-four)
set_option maxRecDepth 4096 in
set_option maxHeartbeats 800000000 in
theorem closure_slice_0 :
    (shortShellVectorList.take 30).Forall (fun x =>
      shortShellVectorList.Forall (fun y =>
        (2 ∣ mulInt x y (0 : Fin 8) ∧ 2 ∣ mulInt x y (1 : Fin 8) ∧
         2 ∣ mulInt x y (2 : Fin 8) ∧ 2 ∣ mulInt x y (3 : Fin 8) ∧
         2 ∣ mulInt x y (4 : Fin 8) ∧ 2 ∣ mulInt x y (5 : Fin 8) ∧
         2 ∣ mulInt x y (6 : Fin 8) ∧ 2 ∣ mulInt x y (7 : Fin 8)) ∧
        octavianUnitMul x y ∈ hammingConstructionA)) := by decide

-- Vectors 30–59
set_option maxRecDepth 4096 in
set_option maxHeartbeats 800000000 in
theorem closure_slice_1 :
    ((shortShellVectorList.drop 30).take 30).Forall (fun x =>
      shortShellVectorList.Forall (fun y =>
        (2 ∣ mulInt x y (0 : Fin 8) ∧ 2 ∣ mulInt x y (1 : Fin 8) ∧
         2 ∣ mulInt x y (2 : Fin 8) ∧ 2 ∣ mulInt x y (3 : Fin 8) ∧
         2 ∣ mulInt x y (4 : Fin 8) ∧ 2 ∣ mulInt x y (5 : Fin 8) ∧
         2 ∣ mulInt x y (6 : Fin 8) ∧ 2 ∣ mulInt x y (7 : Fin 8)) ∧
        octavianUnitMul x y ∈ hammingConstructionA)) := by decide

end CodeLatticeE8.Octonion
