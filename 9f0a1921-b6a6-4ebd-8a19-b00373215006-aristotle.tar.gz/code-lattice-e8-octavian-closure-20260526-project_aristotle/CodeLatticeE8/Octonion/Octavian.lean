import CodeLatticeE8.Octonion.OctavianSlice1
import CodeLatticeE8.Octonion.OctavianSlice2
import CodeLatticeE8.Octonion.OctavianSlice3
import CodeLatticeE8.Octonion.OctavianSlice4

/-!
# Octavian unit shell from Hamming Construction A

This module connects the Cayley-Dickson coordinate multiplication to the
Hamming Construction A short shell.

The short shell `hammingE8ShortShell` consists of integer coordinate vectors
`z : Fin 8 → ℤ` with unscaled squared norm `4`.  Interpreting such a vector
as the octonion `z / 2`, these are the 240 norm-one integral octonion units in
Coxeter's model.

The product of two represented units is

```text
(x / 2) * (y / 2) = mulInt x y / 4.
```

To return to doubled coordinates, we therefore define

```text
octavianUnitMul x y = mulInt x y / 2.
```

## Main theorems

- `two_dvd_mulInt_of_shortShell`: every coordinate of `mulInt x y` is
  divisible by `2` when `x` and `y` are short-shell vectors.
- `octavianUnitMul_mem_hammingConstructionA`: the halved product belongs to
  the Hamming Construction A lattice.
- `octavianUnitMul_sqNorm`: the halved product has unscaled squared norm `4`.
- `octavianUnitMul_mem_shortShell`: the full closure theorem combining the
  above.

## Proof strategy

The divisibility-by-two and lattice-membership checks are verified by
kernel-checked `decide` computations, split into eight parallel slices of
thirty vectors each (in `OctavianSlice1`–`OctavianSlice4`).

The squared-norm identity is derived *algebraically* from the
norm-multiplicativity theorem `normSqInt_mulInt` and the divisibility result,
avoiding any additional finite enumeration.
-/

set_option linter.style.longLine false

namespace CodeLatticeE8.Octonion

open CodeLatticeE8.Code
open CodeLatticeE8.ConstructionA
open CodeLatticeE8.E8
open CodeLatticeE8.E8.RootBridge

/-! ## Decidability instances -/

private instance : DecidablePred (· ∈ hammingE8ShortShell) := fun z =>
  @instDecidableAnd _ _
    (decidable_of_iff _
      (mem_hammingConstructionA_iff_parityCheck z).symm)
    (Int.decEq (sqNorm z) 4)

/-! ## A small finite certificate on coordinate units -/

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
-- Kernel-verified finite check over the 16 coordinate units.
private theorem coordinateShortVectorList_octavianUnitMul_mem :
    coordinateShortVectorList.Forall (fun x =>
      coordinateShortVectorList.Forall (fun y =>
        octavianUnitMul x y ∈ hammingE8ShortShell)) := by
  decide

/-- The normalized Cayley-Dickson product closes on the 16 coordinate units in
the Hamming Construction A short shell.

This is the smallest nontrivial subcase of the octavian unit multiplication
theorem. -/
theorem octavianUnitMul_mem_shortShell_of_mem_coordinateShortVectorList
    {x y : Coords ℤ}
    (hx : x ∈ coordinateShortVectorList) (hy : y ∈ coordinateShortVectorList) :
    octavianUnitMul x y ∈ hammingE8ShortShell := by
  have hxall := List.forall_iff_forall_mem.mp
    coordinateShortVectorList_octavianUnitMul_mem x hx
  exact List.forall_iff_forall_mem.mp hxall y hy

/-! ## Combining the slice computations -/

/-- The combined predicate verified by the slice computations: all mulInt
coordinates are even, and the halved product lies in the Construction A
lattice. -/
private def ClosurePred (x y : Coords ℤ) : Prop :=
  (2 ∣ mulInt x y (0 : Fin 8) ∧ 2 ∣ mulInt x y (1 : Fin 8) ∧
   2 ∣ mulInt x y (2 : Fin 8) ∧ 2 ∣ mulInt x y (3 : Fin 8) ∧
   2 ∣ mulInt x y (4 : Fin 8) ∧ 2 ∣ mulInt x y (5 : Fin 8) ∧
   2 ∣ mulInt x y (6 : Fin 8) ∧ 2 ∣ mulInt x y (7 : Fin 8)) ∧
  octavianUnitMul x y ∈ hammingConstructionA

/-- Helper: `List.Forall p` is preserved under `take` / `drop`
decomposition. -/
private theorem Forall_of_take_drop {α : Type*} {p : α → Prop}
    {l : List α} {n : ℕ}
    (h1 : List.Forall p (l.take n))
    (h2 : List.Forall p (l.drop n)) :
    List.Forall p l := by
  rw [← List.take_append_drop n l]
  exact List.forall_append.mpr ⟨h1, h2⟩

/-- Kernel-verified: the combined closure predicate holds for all 240 × 240
pairs.  Assembled from eight parallel 30-vector slices. -/
private theorem closure_all :
    shortShellVectorList.Forall (fun x =>
      shortShellVectorList.Forall (fun y =>
        ClosurePred x y)) := by
  apply Forall_of_take_drop (n := 30) closure_slice_0
  simp only [List.drop_drop]
  apply Forall_of_take_drop (n := 30) closure_slice_1
  simp only [List.drop_drop]
  apply Forall_of_take_drop (n := 30) closure_slice_2
  simp only [List.drop_drop]
  apply Forall_of_take_drop (n := 30) closure_slice_3
  simp only [List.drop_drop]
  apply Forall_of_take_drop (n := 30) closure_slice_4
  simp only [List.drop_drop]
  apply Forall_of_take_drop (n := 30) closure_slice_5
  simp only [List.drop_drop]
  apply Forall_of_take_drop (n := 30) closure_slice_6
  simp only [List.drop_drop]
  apply Forall_of_take_drop (n := 30) closure_slice_7
  simp only [List.drop_drop]
  -- shortShellVectorList.drop 240 = [] since the list has 240 elements
  have hlen : shortShellVectorList.length = 240 := shortShellVectorList_length
  simp [List.drop_eq_nil_of_le (by omega : shortShellVectorList.length ≤ 240)]

/-- Extract the closure predicate for a specific pair from the finite
certificate. -/
private theorem closure_of_mem {x y : Coords ℤ}
    (hx : x ∈ shortShellVectorList) (hy : y ∈ shortShellVectorList) :
    ClosurePred x y := by
  have hx_all := List.forall_iff_forall_mem.mp closure_all x hx
  exact List.forall_iff_forall_mem.mp hx_all y hy

/-! ## Algebraic helpers -/

/-- The octonion norm `normSqInt` and the Construction A norm `sqNorm`
coincide on `Fin 8 → ℤ`. -/
private theorem normSqInt_eq_sqNorm (x : Coords ℤ) :
    normSqInt x = sqNorm x := by
  rfl

/-- When every coordinate of `mulInt x y` is even, `mulInt x y k` equals
`2 * octavianUnitMul x y k`. -/
private theorem mulInt_eq_two_mul_octavianUnitMul (x y : Coords ℤ) (k : Fin 8)
    (h : 2 ∣ mulInt x y k) :
    mulInt x y k = 2 * octavianUnitMul x y k := by
  simp only [octavianUnitMul]
  omega

/-- When all coordinates of `mulInt x y` are even, the octonion norm of
`mulInt x y` equals `4 * normSqInt (octavianUnitMul x y)`. -/
private theorem normSqInt_mulInt_eq_four_mul (x y : Coords ℤ)
    (h : ∀ k : Fin 8, 2 ∣ mulInt x y k) :
    normSqInt (mulInt x y) = 4 * normSqInt (octavianUnitMul x y) := by
  simp only [normSqInt]
  repeat rw [Fin.sum_univ_eight]
  have h0 := mulInt_eq_two_mul_octavianUnitMul x y 0 (h 0)
  have h1 := mulInt_eq_two_mul_octavianUnitMul x y 1 (h 1)
  have h2 := mulInt_eq_two_mul_octavianUnitMul x y 2 (h 2)
  have h3 := mulInt_eq_two_mul_octavianUnitMul x y 3 (h 3)
  have h4 := mulInt_eq_two_mul_octavianUnitMul x y 4 (h 4)
  have h5 := mulInt_eq_two_mul_octavianUnitMul x y 5 (h 5)
  have h6 := mulInt_eq_two_mul_octavianUnitMul x y 6 (h 6)
  have h7 := mulInt_eq_two_mul_octavianUnitMul x y 7 (h 7)
  rw [h0, h1, h2, h3, h4, h5, h6, h7]
  ring

/-- Extract the divisibility component from the closure predicate for all
eight coordinates. -/
private theorem two_dvd_all_of_closurePred {x y : Coords ℤ}
    (h : ClosurePred x y) (k : Fin 8) : 2 ∣ mulInt x y k := by
  obtain ⟨⟨h0, h1, h2, h3, h4, h5, h6, h7⟩, _⟩ := h
  fin_cases k <;> assumption

/-! ## Public closure theorems -/

/-- Every coordinate of the Cayley-Dickson product `mulInt x y` is
divisible by `2` when both `x` and `y` lie in the Hamming Construction A
short shell. -/
theorem two_dvd_mulInt_of_shortShell {x y : Coords ℤ}
    (hx : x ∈ hammingE8ShortShell) (hy : y ∈ hammingE8ShortShell)
    (k : Fin 8) :
    2 ∣ mulInt x y k :=
  two_dvd_all_of_closurePred
    (closure_of_mem
      (shortShell_mem_shortShellVectorList hx)
      (shortShell_mem_shortShellVectorList hy))
    k

/-- The normalized product `octavianUnitMul x y` belongs to the Hamming
Construction A lattice whenever both factors are short-shell vectors. -/
theorem octavianUnitMul_mem_hammingConstructionA {x y : Coords ℤ}
    (hx : x ∈ hammingE8ShortShell) (hy : y ∈ hammingE8ShortShell) :
    octavianUnitMul x y ∈ hammingConstructionA :=
  (closure_of_mem
    (shortShell_mem_shortShellVectorList hx)
    (shortShell_mem_shortShellVectorList hy)).2

/-- The normalized product has unscaled squared norm `4` on the short shell.

Proved algebraically from the norm-multiplicativity identity
`normSqInt_mulInt` and the coordinate-divisibility theorem, without
enumerating all 240 × 240 products again. -/
theorem octavianUnitMul_sqNorm {x y : Coords ℤ}
    (hx : x ∈ hammingE8ShortShell) (hy : y ∈ hammingE8ShortShell) :
    sqNorm (octavianUnitMul x y) = 4 := by
  -- normSqInt (mulInt x y) = normSqInt x * normSqInt y = 4 * 4 = 16
  have hnorm := normSqInt_mulInt x y
  rw [normSqInt_eq_sqNorm, normSqInt_eq_sqNorm] at hnorm
  have hxn := (mem_shortShell_iff x).mp hx |>.2
  have hyn := (mem_shortShell_iff y).mp hy |>.2
  rw [hxn, hyn] at hnorm
  -- normSqInt (mulInt x y) = 4 * sqNorm (octavianUnitMul x y)
  have hscale := normSqInt_mulInt_eq_four_mul x y
    (fun k => two_dvd_mulInt_of_shortShell hx hy k)
  rw [normSqInt_eq_sqNorm] at hscale
  linarith

/-- **Full closure**: the normalized Cayley-Dickson product closes on the
240-element Hamming Construction A short shell.

This is the octavian-unit multiplication theorem: the 240 norm-one units
in the Coxeter octavian integer model form a multiplicative set. -/
theorem octavianUnitMul_mem_shortShell {x y : Coords ℤ}
    (hx : x ∈ hammingE8ShortShell) (hy : y ∈ hammingE8ShortShell) :
    octavianUnitMul x y ∈ hammingE8ShortShell := by
  rw [mem_shortShell_iff]
  exact ⟨octavianUnitMul_mem_hammingConstructionA hx hy,
         octavianUnitMul_sqNorm hx hy⟩

end CodeLatticeE8.Octonion
