# Summary of changes for run 24f83790-27d6-453e-b9fe-988b337578bc
Discharged all three `sorry`s in `src/ChiralIndexProtection.lean` (F6 — protected massless modes from a finite chiral index). The file builds cleanly with no `sorry`/`admit`/`native_decide`/new `axiom`, and each target's axiom footprint is exactly `[propext, Classical.choice, Quot.sound]`, guarded in-file with `#print axioms`.

Proved statements:
- `corner_ker_ge_index`: for the off-diagonal corner `A : Matrix (Fin nm) (Fin np) ℂ`, `np - nm ≤ finrank ℂ (ker (mulVecLin A))`. Proof is rank–nullity: `finrank (range A) + finrank (ker A) = np`, `finrank (range A) ≤ nm`, then `omega` (which also handles the truncated ℕ-subtraction case `nm ≥ np`, where the bound is 0).
- `corner_ker_ge_index_perturbed`: the same bound for `A + A'`, i.e. the protected count is stable under any odd perturbation since the index depends only on the dimensions.
- `witness_one_protected_mode`: the concrete `np = 2`, `nm = 1` carrier (index 1) has `≥ 1` protected zero mode, as a specialization of the first theorem.

Note on "exactly one": only the perturbation-invariant lower bound (`≥ 1`) is formalized, since that is the index-protected count guaranteed for every corner and stable under all odd perturbations; the "exactly one" refinement holds only for a full-rank corner and was left out of scope, as documented in `ARISTOTLE_SUMMARY.md`.

Added `ARISTOTLE_SUMMARY.md` with the final statements and scope notes. All changes committed and pushed.

# F6 — Protected massless modes from a finite chiral index

All three `sorry`s in `src/ChiralIndexProtection.lean` are discharged. The file
builds cleanly and each target has the required kernel-checked axiom footprint
`[propext, Classical.choice, Quot.sound]` (verified in-file with `#print axioms`).

## Final statements (all proved)

- `corner_ker_ge_index {np nm : ℕ} (A : Matrix (Fin nm) (Fin np) ℂ) :`
  `np - nm ≤ Module.finrank ℂ (LinearMap.ker (Matrix.mulVecLin A))`

  Pure rank–nullity on the off-diagonal corner `A : (Fin np → ℂ) → (Fin nm → ℂ)`:
  `finrank (range A) + finrank (ker A) = np` and `finrank (range A) ≤ nm`, so
  `finrank (ker A) ≥ np − nm` (the `ℕ`-subtraction case `nm ≥ np` is handled by
  `omega`, where the bound is `0` and trivial).

- `corner_ker_ge_index_perturbed {np nm : ℕ} (A A' : Matrix (Fin nm) (Fin np) ℂ) :`
  `np - nm ≤ Module.finrank ℂ (LinearMap.ker (Matrix.mulVecLin (A + A')))`

  The index bound depends only on the dimensions `np, nm`, not on the map, so it
  applies verbatim to the perturbed corner `A + A'`. This is the perturbation
  stability: no odd (mass) perturbation can lift the protected count below the
  index.

- `witness_one_protected_mode (A : Matrix (Fin 1) (Fin 2) ℂ) :`
  `1 ≤ Module.finrank ℂ (LinearMap.ker (Matrix.mulVecLin A))`

  The concrete `np = 2`, `nm = 1` carrier (index `2 − 1 = 1`) has at least one
  protected zero mode, obtained as the specialization of `corner_ker_ge_index`.

## Witness count "exactly one"

Only the guaranteed lower bound (`≥ 1`) is formalized, since that is the
index-protected count that holds for *every* corner and is stable under all odd
perturbations. The "exactly one" refinement holds only for a full-rank (nonzero)
corner and is not part of the protection statement, so it was left out of scope;
the lower bound above is the perturbation-invariant guarantee.

## Physical reading

A chiral asymmetry `dim V₊ ≠ dim V₋` forces `|ind|` massless modes that no odd
mass perturbation can lift — the finite-dimensional shadow of the
Atiyah–Singer / Witten-index protection mechanism.
