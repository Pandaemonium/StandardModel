# Summary of changes for run a6649a3a-ffdb-4c14-b1c4-8fb3dea2bae9
Discharged all four documented `sorry`s in `src/MassNullDecomposition.lean` (the CONVERSE / "all mass is null-edge disagreement" direction). The file builds with no `sorry`/`admit`/`native_decide`/new axioms, and each landed theorem has an in-file `#guard_msgs … #print axioms` guard confirming the footprint is exactly `[propext, Classical.choice, Quot.sound]`. Mathlib only.

Proved:
- Level A `massive_eq_two_null`: every future-timelike 4-momentum is a sum of two future-pointing null momenta. Constructive, via `r = √(spaceNormSq p)`, `Real.sq_sqrt`/`Real.sqrt_pos`, a case split on `spaceNormSq p = 0` (fixed axis) vs. nonzero (`k₁,k₂ = ((E±r)/2)(1, ±p⃗/r)`), closed with `field_simp` + `nlinarith`. Timelikeness gives `r < E` so both energies are positive.
- Level A `massSq_eq_two_null_disagreement`: chains the above with the forward `two_null_sum_massSq` to get `massSq p = 2·mink k1 k2`.
- Level B `posSemidef_eq_null_edge_sum`: full factorization `P = M·Mᴴ` from Mathlib's PSD characterization (taking M = Bᴴ).
- Level B `det_eq_null_edge_disagreement`: `det P = normSq(det M)` via `det_mul` + `det_conjTranspose` + `Complex.normSq_conj` + `Complex.normSq_eq_conj_mul_self`.

Notes: I added `open scoped ComplexOrder` — required for `Matrix.PosSemidef` on ℂ-matrices to even elaborate (the file as shipped did not compile without it). The PSD factorization lemma is flagged deprecated in this Mathlib toward a general C*-algebra version whose required matrix order instance isn't in scope, so the correct matrix-specific lemma is retained; this leaves only two harmless deprecation warnings and does not affect the axiom footprint. No target needed an extra hypothesis and none resisted. Details are in `ARISTOTLE_SUMMARY.md`. All work committed and pushed.

# Universal null decomposition — the CONVERSE ("all mass is null-edge disagreement")

All four documented `sorry`s in `src/MassNullDecomposition.lean` are discharged.
The file builds cleanly (no `sorry`/`admit`/`native_decide`/new `axiom`), and each
landed theorem carries an in-file `#guard_msgs … #print axioms` guard confirming the
axiom footprint is exactly `[propext, Classical.choice, Quot.sound]`. Mathlib only.

## Final statements (all proved)

### Level A — 4-momentum

- `massive_eq_two_null (p : Four) (hp0 : 0 < p 0) (hpos : 0 < massSq p) :`
  `∃ k1 k2, massSq k1 = 0 ∧ massSq k2 = 0 ∧ 0 < k1 0 ∧ 0 < k2 0 ∧ (∀ i, p i = k1 i + k2 i)`
  — every future-timelike 4-momentum is the sum of two future-pointing null momenta.

- `massSq_eq_two_null_disagreement (p : Four) (hp0 : 0 < p 0) (hpos : 0 < massSq p) :`
  `∃ k1 k2, massSq k1 = 0 ∧ massSq k2 = 0 ∧ (∀ i, p i = k1 i + k2 i) ∧ massSq p = 2 * mink k1 k2`
  — its mass square equals twice the Minkowski disagreement of the two null constituents.

### Level B — momentum matrix

- `posSemidef_eq_null_edge_sum {n} (P : Matrix (Fin n) (Fin n) ℂ) (hP : P.PosSemidef) :`
  `∃ M, P = M * Mᴴ`
  — full factorization into null-edge dyads (columns of `M` are the null spinors).

- `det_eq_null_edge_disagreement {n} (P : Matrix (Fin n) (Fin n) ℂ) (hP : P.PosSemidef) :`
  `∃ M, P = M * Mᴴ ∧ P.det = (Complex.normSq M.det : ℂ)`
  — the Plücker mass `det P` is the disagreement `normSq(det M)` of the decomposition.

## Constructions / Mathlib lemmas used

- **Level A** is genuinely constructive. With `E = p 0`, `r = √(spaceNormSq p)`:
  - Case `spaceNormSq p = 0` (spatial part vanishes, forced by `sq_nonneg`): split the
    energy along the fixed axis, `k₁ = (E/2)(1,0,0,1)`, `k₂ = (E/2)(1,0,0,-1)`.
  - Case `spaceNormSq p ≠ 0`: `k₁ = ((E+r)/2)(1, p⃗/r)`, `k₂ = ((E-r)/2)(1, -p⃗/r)`.
    Timelikeness (`hpos` with `massSq p = E² - spaceNormSq p`) gives `r < E`, hence both
    energies are positive. Nullity and the sum reduce to `r² = spaceNormSq p` via
    `Real.sq_sqrt` / `Real.sqrt_pos`, closed with `field_simp` + `nlinarith`.
  - The disagreement identity chains `massive_eq_two_null` with the provided forward
    `two_null_sum_massSq`.

- **Level B** wraps Mathlib's PSD factorization
  `Matrix.posSemidef_iff_eq_conjTranspose_mul_self : P.PosSemidef ↔ ∃ B, P = Bᴴ * B`
  (taking `M = Bᴴ`, so `Mᴴ = B`), and the determinant identity uses `Matrix.det_mul`,
  `Matrix.det_conjTranspose`, `Complex.normSq_conj`, and `Complex.normSq_eq_conj_mul_self`.

## Notes

- The file needs `open scoped ComplexOrder` for `Matrix.PosSemidef` on `ℂ`-matrices to
  elaborate (it requires `PartialOrder ℂ`); this was added. The original file as shipped
  did not compile without it.
- `Matrix.posSemidef_iff_eq_conjTranspose_mul_self` is flagged deprecated in this Mathlib
  toward the general `CStarAlgebra.nonneg_iff_eq_star_mul_self`; the replacement needs the
  matrix C*-order (`0 ≤ P`) instance, which is not in scope for `Matrix (Fin n) (Fin n) ℂ`
  by default, so the matrix-specific lemma is retained. This is a harmless warning only —
  the lemma is correct and the axiom footprint is unaffected.

No target required an extra hypothesis; none resisted.
