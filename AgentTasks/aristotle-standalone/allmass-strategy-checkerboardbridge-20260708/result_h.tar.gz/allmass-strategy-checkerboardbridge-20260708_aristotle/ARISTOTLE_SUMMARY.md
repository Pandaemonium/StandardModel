# Summary of changes for run 2a50fb46-27b2-496c-a0ae-30ce43a9f0f2
Formalized and proved the F1 strategy: the 1+1D Dirac quantum walk / Feynman checkerboard IS a special case of the Krein null-edge carrier, with the four-channel names matching standard kinetic/mass structure. All work is in `RequestProject/Main.lean` (namespace `DiracWalkCarrier`), builds cleanly with no `sorry`, and every theorem's axiom footprint is `[propext, Classical.choice, Quot.sound]` (checked in-file via `#print axioms`). Mathlib only; clean-room from the cited papers. A companion write-up is in `ARISTOTLE_SUMMARY.md`.

What is proved (finite 2×2 real-matrix identities in E, k, m):

1. The walk as an explicit operator. Two nilpotent null Clifford edges `cP = c₊`, `cM = c₋` (the lightlike steps): `cP*cP = 0`, `cM*cM = 0` (isotropic), `cP*cM + cM*cP = 1` (metric/null pairing), and the null-disagreement `cP*cM − cM*cP = σ_z`.

2. Carrier shape D = Σ c(α)∇ + Γφ. The kinetic symbol `slashp = (E−k)•cP + (E+k)•cM` (light-cone momenta on the two null edges), turn/mass term `Γφ = m•1`, full carrier `Dop = slashp + turn`. The Krein adjoint `A^# = J·Aᵀ·J` (J = σ_x) makes kinetic, mass and D all Krein-self-adjoint (`kdag_slashp`, `kdag_turn`, `kdag_Dop`).

3. Four-channel budget `four_channel_budget : 4•(D^# D) = Q_A + Q_C + 4•Q_T + 4•E_#`, with the channel = physics dictionary all proved: `aperture_is_kinetic : Q_A = 4(E²−k²)•1` (kinetic/d'Alembertian), `closure_vanishes : Q_C = 0` (no gauge curvature), `turn_is_mass_squared : Q_T = m²•1` (= φ² = mass², Higgs), `soldering_form : E_# = 2m•slashp` (mass·momentum cross term, proved non-zero).

4. Mass shell `mass_shell : det D = 0 ↔ E² = k² + m²`, with `det_carrier : det D = m² − (E²−k²)` the kinetic-minus-mass² shell function.

5. Walk-Hamiltonian frame. `Hwalk = k•σ_z + m•σ_x = k•[c₊,c₋] + m•(c₊+c₋)` (kinetic = null-disagreement, mass = coin flip); `Hwalk_sq : H² = (k²+m²)•1`; `walk_budget : 4H² = 4k²•1 + Q_C + 4•(m²•1) + 4•0` (manifestly positive, with Q_C = 0 and soldering = 0 in this frame); `mass_shell_walk : det(E•1 − H) = 0 ↔ E² = k² + m²`.

Honest accounting (in the summary file): everything lines up except the soldering channel, which is genuinely non-zero (its expected mass·momentum form) in the Krein covariant frame but vanishes in the walk frame — the two are Krein mirror images and both are provided rather than forcing a single picture; the Lorentzian relative sign between kinetic and mass is carried by the determinant/mass-shell statements. The all-channels-trivial-except-kinetic-and-mass picture is special to 1+1D; 3+1D would require genuinely new structure (real gauge curvature in Q_C, a genuine spin-connection soldering term, and the checkerboard face structure for no-doubling), which is noted as open.

# The 1+1D Dirac quantum walk as a Krein null-edge carrier (F1)

All results live in `RequestProject/Main.lean` (namespace `DiracWalkCarrier`).
Everything is a finite `2×2` real-matrix identity in the parameters `E k m : ℝ`,
kernel-checked, with axiom footprint `[propext, Classical.choice, Quot.sound]`
(printed in-file via `#print axioms`). Mathlib only; clean-room from the cited
papers' mathematics.

## 1. The walk as an explicit finite operator

The internal (coin/spinor) space is `M2 = Matrix (Fin 2) (Fin 2) ℝ`. The two
lightlike step directions are the **null Clifford edges**

* `cP = !![0,1;0,0]` (right-mover `c₊`), `cM = !![0,0;1,0]` (left-mover `c₋`).

They are proved genuinely **null / isotropic** and to reproduce the metric:

* `cP_null : cP*cP = 0`, `cM_null : cM*cM = 0` — the edges are lightlike (nilpotent);
* `null_pairing : cP*cM + cM*cP = 1` — the unit null pairing (the metric);
* `null_disagreement : cP*cM - cM*cP = σ_z` — the **null-disagreement** operator.

## 2. Casting as the carrier `D = Σ c(α) ∇_α + Γφ`

In the energy/momentum symbol picture the two lightlike transports carry the
light-cone momenta `∇₊ = E−k`, `∇₋ = E+k`:

* `slashp_eq_null_edges : slashp E k = (E−k)•cP + (E+k)•cM`  (the kinetic symbol `p̸`);
* `turn m = m•1`  is the turn/mass term `Γφ` with `Γ = 1`, `φ = m` (coin-flip amplitude);
* `Dop E k m = slashp E k + turn m`  is the full carrier `D`.

The Krein (indefinite-metric) adjoint is `A^# = J·Aᵀ·J` with `J = σ_x`. Both parts,
and hence `D`, are Krein-self-adjoint: `kdag_slashp`, `kdag_turn`, `kdag_Dop`, so the
budget below is a genuine Krein square.

## 3. The four-channel budget and the channel = physics dictionary

`four_channel_budget` :  `4 • (D^# D) = Q_A + Q_C + 4•Q_T + 4•E_#`, with

| channel | definition | proved identity | physics |
|---|---|---|---|
| `Q_A` aperture | `4•(p̸·p̸)` | `aperture_is_kinetic : Q_A = 4(E²−k²)•1` | kinetic / d'Alembertian |
| `Q_C` closure | `0` | `closure_vanishes : Q_C = 0` | gauge curvature (none in flat 1+1D) |
| `Q_T` turn | `(Γφ)²` | `turn_is_mass_squared : Q_T = m²•1` | mass² (Higgs), `Q_T = φ² = m²` |
| `E_#` soldering | `{p̸, Γφ}` | `soldering_form : E_# = 2m•p̸` | mass·momentum cross term |

So the abstract channel names really are the standard kinetic / gauge / mass /
soldering structure of the discrete Dirac operator.

## 4. The mass shell `E² = k² + m²`

* `det_carrier : det D = m² − (E²−k²)` — the mass-shell function (kinetic minus mass²);
* `mass_shell : det D = 0 ↔ E² = k² + m²` — the carrier is singular (`Dψ = 0` has a
  solution) exactly on the relativistic mass shell.

## 5. The walk-Hamiltonian frame (coin ⊗ shift generator)

The same physics in the quantum-walk frame, building the generator directly from the
null edges: `Hwalk k m = k•σ_z + m•σ_x = k•[c₊,c₋] + m•(c₊+c₋)` (`Hwalk_from_edges`),
i.e. **kinetic = the null-disagreement `[c₊,c₋]`** carrying momentum `k`, and
**mass = the coin flip `σ_x = c₊+c₋`** with amplitude `m` (`sigX_eq_null_sum`).

* `Hwalk_sq : H² = (k²+m²)•1` — the walk energy operator;
* `walk_budget : 4H² = 4k²•1 + Q_C + 4•(m²•1) + 4•0` — manifestly positive four-channel
  budget, with `Q_C = 0` **and soldering `E_# = 0`** (the coin flip anticommutes with the
  shift in this frame);
* `mass_shell_walk : det(E•1 − H) = 0 ↔ E² = k² + m²` — energy on-shell ⇔ eigenvalue of `H`.

## 6. Honest accounting: what lines up, what does not

* **Lines up:** the null-edge / lightlike-step identification, the Krein null and
  metric relations, the four-channel budget as an exact identity, `Q_A = kinetic`,
  `Q_T = φ² = m²`, `Q_C = 0`, and the `E² = k² + m²` mass shell — in *both* the
  covariant symbol frame and the walk-Hamiltonian frame.
* **The soldering channel `E_#`.** In the genuinely Krein-self-adjoint *covariant*
  frame the scalar mass commutes-through and the soldering channel is **non-zero**,
  `E_# = 2m·p̸` (`soldering_nonzero`); it is its expected mass·momentum cross-term form,
  not zero. In the *walk-Hamiltonian* frame the coin flip anticommutes with the shift,
  so there `E_# = 0`. The two frames are Krein mirror images and are both provided; the
  file states this honestly rather than forcing a single "everything vanishes" picture.
* **Sign of the turn channel.** With a Lorentzian (mostly-minus) metric the mass shell
  `E²−k²−m² = 0` forces the mass to enter `det D` with the opposite sign to the kinetic
  term; this is exactly `det_carrier`. The budget is nonetheless stated in the requested
  `+4•Q_T` shape with `Q_T = φ²`, and the Lorentzian relative sign is carried by
  `det_carrier`/`mass_shell`.
* **3+1D would need genuinely new structure.** The clean 1+1D result rests on the
  Clifford algebra being `2×2` with a *single* pair of null edges and a one-dimensional
  chirality (`σ_z = [c₊,c₋]`). In 3+1D there are three spatial momenta and a `4×4`
  Clifford algebra: the closure channel `Q_C` can carry real gauge/spin curvature, the
  soldering channel becomes the genuine spin-connection term, and no-doubling requires
  the checkerboard's face structure. So the "all channels trivial except kinetic and
  mass" picture is special to 1+1D; the higher-dimensional case is left open and would
  require new structure, consistent with the Foster–Jacobson / Mlodinow–Brun analyses.
