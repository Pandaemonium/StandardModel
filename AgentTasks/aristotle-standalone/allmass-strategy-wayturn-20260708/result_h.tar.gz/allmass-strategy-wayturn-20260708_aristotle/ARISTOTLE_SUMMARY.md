# Summary of changes for run 582b43db-a7fd-420d-84b3-a1135086a34f
Proved the Wigner–Araki–Yanase no-go for the chirality ("turn") gate (Conjecture H) in `RequestProject/Main.lean` (namespace `WAY`). The file builds cleanly; every theorem is kernel-checked with no sorry/admit/native_decide and no new axioms. In-file `#print axioms` guards confirm the footprint is exactly `[propext, Classical.choice, Quot.sound]`. Finite-dimensional operators are matrices over a commutative ring (witness over ℂ) with the Kronecker/tensor product; total charge `Q = Q_s ⊗ 1 + 1 ⊗ Q_a`.

Theorems delivered:
1. `way_defect_identity` (quantitative core): for a trivial-ancilla gate `U = u ⊗ 1`, the charge-conservation defect `U Q − Q U = [u, Q_s] ⊗ 1`, independent of the ancilla charge `Q_a`. A trivial ancilla can never reduce the defect below the system commutator.
2. `way_nogo` (the clean M-target): if `U = u ⊗ 1` conserves the total charge (nonempty ancilla), then `u` commutes with `Q_s`. Contrapositive: a gate with `[u, Q_s] ≠ 0` cannot be a charge-conserving closed-system unitary with a trivial ancilla.
3. `chirality_gate_not_isospin_commuting` (witness): the explicit 2×2 chirality flip (Pauli-X) and isospin (Pauli-Z) over ℂ do not commute.
4. `chirality_requires_nontrivial_ancilla` (corollary): for any nonempty ancilla and any ancilla charge `Q_a`, `chiralityGate ⊗ 1` fails to conserve `isospin ⊗ 1 + 1 ⊗ Q_a` — the gate genuinely requires a nontrivial charge-carrying ancilla.

The optional quantitative Ozawa-type bound (gate error ~ 1/ancilla-charge-variance, the finite `m ∝ φ` resource law for a general entangling U) was not formalized; it is honestly pre-registered as the precise next target in `ARISTOTLE_SUMMARY.md`. Note `way_defect_identity` is the exact, ancilla-independent endpoint of that bound. All work is committed and pushed.

# Aristotle summary — WAY no-go for the chirality ("turn") gate (Conjecture H)

All results live in `RequestProject/Main.lean`, namespace `WAY`. The file builds cleanly
under Lean `v4.28.0` + Mathlib. Every result is kernel-checked with no
`sorry`/`admit`/`native_decide` and no new `axiom`; in-file `#print axioms` guards confirm
the footprint is exactly `[propext, Classical.choice, Quot.sound]`.

## Setting

Finite-dimensional operators are matrices over a commutative ring `R` (the witness uses
`ℂ`), with the Kronecker/tensor product `⊗ₖ`. The total conserved charge is
`Q = Q_s ⊗ 1 + 1 ⊗ Q_a` (system isospin `Q_s`, ancilla charge `Q_a`). A trivial-ancilla
gate is `U = u ⊗ 1`.

## Theorems delivered

1. **`way_defect_identity`** (the quantitative core, proved).
   For any `Q_s, u : Matrix m m R` and any ancilla charge `Q_a : Matrix n n R`,
   ```
   (u ⊗ 1) Q − Q (u ⊗ 1) = [u, Q_s] ⊗ 1 ,   Q = Q_s ⊗ 1 + 1 ⊗ Q_a .
   ```
   The charge-conservation *defect* of a trivial-ancilla gate is exactly the system
   commutator `[u, Q_s]` tensored with the identity — **independent of `Q_a`**. No choice of
   ancilla charge can reduce the defect; a trivial (product, non-entangling) ancilla
   contributes nothing. This is the exact identity underlying the WAY resource statement.

2. **`way_nogo`** (the clean M-target, proved).
   If `U = u ⊗ 1` conserves the total charge (`U Q = Q U`) with a nonempty ancilla, then
   `u * Q_s = Q_s * u`. Follows from `way_defect_identity`: the defect vanishes, so
   `[u, Q_s] ⊗ 1 = 0`, and evaluating at a fixed diagonal ancilla index extracts
   `[u, Q_s] = 0`. Contrapositive: a chirality gate with `[u, Q_s] ≠ 0` cannot be a
   charge-conserving closed-system unitary with a trivial ancilla.

3. **`chirality_gate_not_isospin_commuting`** (witness, proved).
   Explicit `2×2` operators `chiralityGate = [[0,1],[1,0]]` (Pauli-X chirality flip) and
   `isospin = [[1,0],[0,−1]]` (Pauli-Z isospin) over `ℂ` satisfy
   `chiralityGate * isospin ≠ isospin * chiralityGate`. So the no-go bites for a concrete
   gate.

4. **`chirality_requires_nontrivial_ancilla`** (corollary, proved).
   For *any* nonempty ancilla index type and *any* ancilla charge `Q_a`, the trivial-ancilla
   implementation `chiralityGate ⊗ 1` fails to conserve `isospin ⊗ 1 + 1 ⊗ Q_a`. The
   chirality (turn) gate genuinely requires a nontrivial, charge-carrying, entangling
   ancilla — the reading "the Higgs is the WAY-evading reference frame for weak isospin".

## Optional quantitative bound — status (honest)

The full Ozawa-type quantitative WAY bound (gate error `~ 1/`ancilla-charge-variance, giving
the finite `m ∝ φ` resource law for a *general, entangling* `U`) was **not** formalized.
It requires reduced dynamics, input/output ancilla states, an error metric, and a variance
of `Q_a` — a substantially larger development. It is pre-registered here as the precise
next target:

> For a total unitary `U` with `[U, Q] = 0` on system⊗ancilla and a fixed normalized ancilla
> state `ξ`, let `V` be the induced system channel. Then the gate infidelity for realizing a
> target unitary that fails to commute with `Q_s` is bounded below by a quantity
> `∝ ‖[V_target, Q_s]‖² / Var_ξ(Q_a)`, so the achievable effective turn amplitude scales like
> `φ` with `1/Var(Q_a)` corrections.

What *is* proved above (`way_defect_identity`) is the exact, ancilla-independent version of
the obstruction in the trivial-ancilla (zero-variance-coherence) limit, which is the sharp
endpoint of that bound.
