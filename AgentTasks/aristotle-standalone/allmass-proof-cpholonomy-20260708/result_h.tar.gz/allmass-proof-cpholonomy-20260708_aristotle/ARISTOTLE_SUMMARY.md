# Summary of changes for run 7987a2df-9767-4b10-a6c0-428627bd5cf0
All three targets in `src/CPHolonomy.lean` (Conjecture D, the CP/mixing frontier) are proved with no `sorry`/`admit`/`native_decide` and no new axioms. Each theorem's kernel-checked footprint is exactly `[propext, Classical.choice, Quot.sound]`, verified by in-file `#print axioms`. The file builds cleanly (Mathlib only, no warnings).

Definitions: `bracket ψ φ = ψ₀φ₁ − ψ₁φ₀` (the 2-spinor wedge `⟨ψ,φ⟩ = det[ψ|φ]`) and `tripleJ p1 p2 p3 = ⟨12⟩⟨23⟩⟨31⟩`.

Proved identities:
1. `triple_SL2_invariant` — invariance under a common `g` with `det g = 1`. Backed by the helper `bracket_mulVec`: `bracket (g·ψ)(g·φ) = det g · bracket ψ φ` (the 2×2 determinant identity); the product then picks up `(det g)³ = 1`.
2. `triple_CP_odd` — `tripleJ(conj·) = conj(tripleJ)` (conjugation is a ring hom), so `arg J ↦ −arg J` and `Im J ≠ 0` is a genuine non-gaugeable CP-odd invariant.
3. `triple_mass_magnitude` — `‖J‖ = ‖⟨12⟩‖·‖⟨23⟩‖·‖⟨31⟩‖`, so a nonzero CP phase needs all three brackets ≠ 0 (three-way non-collinearity).

Honest scope note (also stated in the file docstring, in the added lemma `triple_rescale`, and in `ARISTOTLE_SUMMARY.md`): `tripleJ` is `SL(2,ℂ)`-invariant but NOT independent-rescaling-invariant — `triple_rescale` proves it scales by `(λ₁λ₂λ₃)²` under `ψᵢ ↦ λᵢψᵢ`. Thus `‖J‖` is normalization-dependent and `arg J` is a physical CP invariant only after fixing a normalization of the individual rays; the CP-odd sign of `Im J` is preserved by positive-real rescalings and flipped by conjugation.

Deliverables: the completed `src/CPHolonomy.lean` (with the five `#print axioms` guards) and `ARISTOTLE_SUMMARY.md`. All work committed and pushed.

# CP phase as projective null-ray holonomy — summary (Conjecture D)

All targets in `src/CPHolonomy.lean` are proved with no `sorry`/`admit`/`native_decide`
and no new axioms. Kernel-checked axiom footprint for every theorem (verified by the
in-file `#print axioms`): `[propext, Classical.choice, Quot.sound]`. Mathlib only.

## Definitions

- `bracket ψ φ = ψ₀φ₁ − ψ₁φ₀` — the 2-spinor wedge `⟨ψ,φ⟩ = det [ψ | φ]`.
- `tripleJ p1 p2 p3 = bracket p1 p2 · bracket p2 p3 · bracket p3 p1` — the closed
  triple holonomy `J = ⟨12⟩⟨23⟩⟨31⟩`.

## The three identities

1. **`triple_SL2_invariant`** — invariance under a *common* `g` with `det g = 1`:
   `tripleJ (g·p1)(g·p2)(g·p3) = tripleJ p1 p2 p3`. Proved via the bracket-scaling
   lemma **`bracket_mulVec`**: `bracket (g·ψ)(g·φ) = det g · bracket ψ φ` (the 2×2
   determinant identity `det(g·[ψ|φ]) = det g · det[ψ|φ]`). The product then picks up
   `(det g)³ = 1³ = 1`.

2. **`triple_CP_odd`** — under componentwise conjugation,
   `tripleJ (conj p1)(conj p2)(conj p3) = conj (tripleJ p1 p2 p3)` (conjugation is a
   ring hom, so it distributes over the product of brackets). Consequently the phase
   flips, `arg J ↦ −arg J`, so `Im J` is a genuine CP-odd invariant: `Im J ≠ 0` is
   non-gaugeable CP violation, while a gaugeable-away phase has `Im J = 0`.

3. **`triple_mass_magnitude`** — `‖tripleJ‖ = ‖⟨12⟩‖·‖⟨23⟩‖·‖⟨31⟩‖` (`norm_mul`),
   tying the CP magnitude to the three pairwise disagreements. A nonzero CP holonomy
   therefore requires all three brackets `≠ 0`: genuine three-way non-collinearity.

## Invariance group of the *phase* and normalization scope (honest note)

`tripleJ` is invariant under the **common** `SL(2,ℂ)` action (`det g = 1`). It is
**not** invariant under **independent rescalings** `ψᵢ ↦ λᵢ ψᵢ`: the extra lemma
**`triple_rescale`** proves it scales by `(λ₁λ₂λ₃)²`. Hence:

- The *magnitude* `‖J‖` is normalization-dependent (it depends on the chosen
  representatives of each null ray), so it is only a projective invariant after a
  normalization is fixed (e.g. unit spinors).
- `arg J` is a physical CP invariant only *after* fixing such a normalization of the
  individual rays; it is unchanged by any *positive-real* independent rescaling
  (`λᵢ > 0` real), since `(λ₁λ₂λ₃)²` is then a positive real factor that does not
  rotate the phase. In particular the CP-odd datum — the sign of `Im J` — is preserved
  by positive-real rescalings and flipped by conjugation.

So `tripleJ` is `SL(2,ℂ)`-invariant but *not* independent-rescaling-invariant; its
phase is the physical object only relative to a fixed normalization.
