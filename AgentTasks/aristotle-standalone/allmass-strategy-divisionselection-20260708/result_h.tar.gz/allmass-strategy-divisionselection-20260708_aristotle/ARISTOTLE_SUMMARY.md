# Summary of changes for run d19e085e-583d-4361-bbb2-66bb872d0f05
Formalized the division-algebra dimension-selection result (Conjecture N, "why d = 4") from `STRATEGY_PROMPT.md` in `RequestProject/Main.lean` (namespace `NullEdge`). The file builds cleanly with no `sorry`/`admit`/`native_decide`/new `axiom`, and in-file `#print axioms` blocks confirm every headline theorem rests only on `[propext, Classical.choice, Quot.sound]`. Mathlib only.

What landed:
- The four-member family `K = ℝ, ℂ, ℍ, 𝕆` as `DivAlg` with `minkowskiDim` (3,4,6,10). Carriers: Mathlib `ℝ`, `ℂ`, `Quaternion ℝ`, and — since octonions are absent from Mathlib — a from-scratch Cayley–Dickson double `Oct := Quaternion ℝ × Quaternion ℝ` (`omul`).
- Composition discriminator: `comm_real`, `comm_complex` (ℝ, ℂ commutative), `noncomposes_quat` (ℍ not commutative), `noncomposes_oct` (𝕆 not commutative).
- Wedge/Bargmann-phase discriminator: `bargmann_cyclic_complex` (ℂ triple product cyclically invariant), `bargmann_noncyclic_quat` (ℍ fails cyclic well-definedness), `oct_nonassoc` (𝕆 associator obstruction); plus continuity: `phaseR_eq`/`phaseR_finite` (ℝ phase set = {±1}, finite — no continuous phase) vs `phaseC_infinite` (ℂ unit circle infinite).
- Assembly: `division_algebra_selection` proves `(Composes k ∧ ContinuousPhase k) ↔ k = C` — ℝ fails continuity, ℍ/𝕆 fail commutativity, only ℂ satisfies both; `selects_dim_four` gives `C.minkowskiDim = 4`; `dimension_is_four` derives d = 4 from the two physical premises. The `Composes`/`ContinuousPhase` predicates unfold definitionally to the genuine statements about the concrete carriers, so the selection reduces to the proved algebraic facts.

Honest boundary (also in `ARISTOTLE_SUMMARY.md`): octonions are modeled as one standard Cayley–Dickson double, with only the structural (non)commutativity/(non)associativity facts developed (a full normed composition-algebra instance was not built, and is not needed). `ContinuousPhase` for ℍ/𝕆 is stated but not proved because those members already fail composition, so the conjunction is false regardless. The physics identifications (2×2 Hermitian = Minkowski space, SL(2,K) = Lorentz group, det P mass identity) are recorded as motivating docstrings, not formalized; "continuous/abelian" is captured algebraically (infinitude of the phase set; cyclic-triple/commutativity) rather than as Lie-group statements.

See `ARISTOTLE_SUMMARY.md` for the full write-up. All changes are committed and pushed.

# Division-algebra dimension selection (Conjecture N): why `d = 4`

All results live in `RequestProject/Main.lean`, namespace `NullEdge`. The file
builds cleanly with **no `sorry`/`admit`/`native_decide`/new `axiom`**, and the
in-file `#print axioms` guard confirms every headline theorem rests only on the
allowed footprint `[propext, Classical.choice, Quot.sound]`. Mathlib only.

## What was formalized

The four-member normed-division-algebra family `K = ℝ, ℂ, ℍ, 𝕆` (Minkowski
dimensions `d = 3, 4, 6, 10`) is indexed by `DivAlg`, with `DivAlg.minkowskiDim`.
The concrete carriers are Mathlib's `ℝ`, `ℂ`, `Quaternion ℝ`, and — since
octonions are **not** in Mathlib — a from-scratch Cayley–Dickson double
`Oct := Quaternion ℝ × Quaternion ℝ` with product
`(a,b)*(c,d) = (a·c − d̄·b, d·a + b·c̄)` (`omul`).

### Discriminator 1 — composition (tensor products / multi-particle systems)
A bilinear tensor product of direction registers needs a **commutative** base.
* `comm_real`, `comm_complex` : `ℝ`, `ℂ` are commutative.
* `noncomposes_quat` : `ℍ` is not commutative (`i·j ≠ j·i`).
* `noncomposes_oct` : `𝕆` is not commutative (`e₁·e₂ ≠ e₂·e₁`), on the
  Cayley–Dickson model.

### Discriminator 2 — wedge / Bargmann CP phase
Two independent failure modes are proved:
* **Order-independence (cyclicity of the Bargmann triple).**
  `bargmann_cyclic_complex` : over `ℂ`, `a·b·c = c·a·b` (cyclic, order-independent).
  `bargmann_noncyclic_quat` : over `ℍ` there exist `a,b,c` with `a·b·c ≠ c·a·b`
  (the noncommutative `Sp(1)` "phase" loses cyclic well-definedness).
  `oct_nonassoc` : over `𝕆` the associator obstructs the triple product itself
  (`(e₁·e₂)·e₄ ≠ e₁·(e₂·e₄)`), so no well-defined `a·b·c` exists at all.
* **Continuity of the phase group.**
  `phaseR_eq` / `phaseR_finite` : over `ℝ` the unit-norm ("phase") set is exactly
  `{+1, −1}`, hence finite — CP is only a discrete sign, no continuous phase.
  `phaseC_infinite` : over `ℂ` the unit circle is infinite — a genuine continuous
  phase.

### Assembly — the selection theorem
`Composes` and `ContinuousPhase` are predicates on `DivAlg` defined literally as
the corresponding statements about the concrete carriers (commutativity, and
infinitude of the unit-norm set).

* `division_algebra_selection` :
  `(Composes k ∧ ContinuousPhase k) ↔ k = DivAlg.C`.
  `ℝ` fails continuity, `ℍ` and `𝕆` fail commutativity; only `ℂ` satisfies both.
* `selects_dim_four` : `DivAlg.C.minkowskiDim = 4`.
* `dimension_is_four` : the two physical premises jointly force `k.minkowskiDim = 4`.

## How the discriminators are encoded (honesty note)

`Composes`/`ContinuousPhase` are *not* hand-set truth tables: each case unfolds
definitionally to the real mathematical statement about the actual carrier type,
and the selection proof discharges each case using the theorems above
(`noncomposes_quat`, `noncomposes_oct`, `phaseR_not_infinite`, `comm_complex`,
`phaseC_infinite`). So the selection theorem's content genuinely reduces to the
proved algebraic facts.

## Boundary / caveats (honest)

* **Octonions.** Mathlib has no octonion type, so `𝕆` is modeled as one standard
  Cayley–Dickson double of `Quaternion ℝ`. The proved facts (non-commutativity,
  non-associativity) are the structural discriminators actually used and are
  convention-independent; a full normed-composition-algebra instance for `Oct`
  was not developed (not needed for the selection).
* **`ContinuousPhase` for `ℍ`/`𝕆`.** These cases are stated (infinitude of the
  unit-norm set) but not proved, because they are not needed: `ℍ` and `𝕆`
  already fail the composition premise, so the conjunction is false regardless.
  The one genuinely needed continuity fact, `phaseC_infinite`, is fully proved,
  as is the negative `ℝ` fact `phaseR_finite`.
* **"Continuous / abelian" is captured algebraically**, not as Lie-group
  statements: continuity is rendered as infinitude of the phase set (`ℝ` finite
  vs `ℂ` infinite), and abelianness/order-independence as the cyclic-triple and
  commutativity lemmas. The physics-level identifications (2×2 Hermitian matrices
  over `K` as Minkowski space, `SL(2,K)` as Lorentz group, `det P` mass identity)
  are recorded as motivation in the file's docstrings, not formalized.

## Verification

`#print axioms` blocks at the end of `Main.lean` print, for every headline
result, `[propext, Classical.choice, Quot.sound]` (and `selects_dim_four` uses
no axioms). The file builds with `lake build RequestProject.Main`.
