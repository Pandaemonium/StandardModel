# Summary of changes for run b61e99bc-881e-4c6d-9bc2-aa2914c6a9b2
## Verdict: NON-RIGID — the four-block split is not forced (but the soldering block and the type-count are)

I formalized the F2 carrier-rigidity question in `RequestProject/Main.lean` (builds cleanly, no `sorry`/`admit`/`native_decide`/new axioms; footprint ⊆ `[propext, Classical.choice, Quot.sound]`, with the abstract theorems using only `[propext, Quot.sound]`). A full write-up is in `ARISTOTLE_SUMMARY.md`.

**Setup.** The carrier `D = c₁∇₁ + c₂∇₂ + Γφ` is modeled in a ring with an involutive antiautomorphism `star` (the Krein adjoint `#`, i.e. a `StarRing`) under the stated axioms: `cₑ²=0`, `Γ²=1`, `star Γ=Γ`, `{Γ,cₑ}=0`, `[Γ,∇ₑ]=[Γ,φ]=0`, `star φ=φ`. Two edges is the smallest setting with a nonzero closure channel.

**What is proved (all kernel-checked):**
- `square_decomposition`: the exact four-block identity `2·(D#D) = Q_A + Q_C + 2·E_# + 2·Q_T` — the expansion falls entirely into these four groups, no fifth block.
- Grade-typing: `Q_A` (aperture), `Q_C` (closure), `Q_T` (turn) are **all** Γ-even and `#`-self-adjoint, while `E_#` (soldering) is the unique Γ-odd block (`*_even`, `solder_odd`, `*_selfadjoint`). So the two structures the axioms actually supply — the chiral grading Γ and the Krein adjoint `#` — assign aperture/closure/turn the *same* `(Γ,#)`-type and cannot distinguish them.
- `parity_decomposition_unique`: the Γ-even/odd (2-block) split is unique, hence forced. Applied to the square, `square_oddPart` gives `oddPart(2·D#D)=2·E_#` (soldering IS canonically isolated) and `square_evenPart` gives `evenPart(2·D#D)=Q_A+Q_C+2·Q_T` (the even bulk is left unrefined).
- Concrete non-vacuity: an explicit 4×4 rational Krein carrier (`η=diag(1,−1,1,−1)`, adjoint `A#=ηAᵀη` proved involutive/antimultiplicative/additive; all axioms verified) in which `Q_A=diag(0,0,4,10)`, `Q_C=diag(0,0,4,8)`, `Q_T=1` are **pairwise distinct, nonzero, and of identical `(Γ,#)`-type** (`shared_type_but_distinct`, `channels_pairwise_distinct`). This makes the obstruction concrete rather than vacuous.

**Interpretation.** The carrier axioms force only a two-block (chiral-parity) decomposition and canonically isolate the soldering block. Separating the even bulk into aperture/closure/turn is a *choice*, not a consequence: it requires two extra selecting structures that are not axioms — a solder-degree grading (number of `c`-letters: turn 0, aperture/closure 2) and an edge-index symmetrization (aperture symmetric vs closure antisymmetric). The program's "unification is decomposition" therefore needs these as additional axioms. The *count* of channel types is nonetheless rigid: the square lives entirely in the two Γ-graded sectors, with no room for a fifth type.

# F2 — Carrier rigidity: is the four-block square forced?

**Verdict: NON-RIGID (with a precise, machine-checked obstruction).**
The carrier axioms force only a *two-block* (chiral-parity) decomposition of the
square. Splitting the even bulk into the three named channels
aperture / closure / turn is **not** implied by the axioms; it requires two extra
selecting structures that the program does not currently fix. The soldering block,
by contrast, **is** forced. The *number* of channel types is nonetheless rigid.

All results are in `RequestProject/Main.lean`, kernel-checked, no `sorry`/`admit`/
`native_decide`/new `axiom`, with footprint `⊆ [propext, Classical.choice, Quot.sound]`
(verified in-file behaviour; `Classical.choice` enters only through the concrete
`Matrix`/`ℚ` witnesses, the abstract theorems use only `[propext, Quot.sound]`).

## Setup

The carrier is modeled as `D = c₁∇₁ + c₂∇₂ + Γφ` in a ring `R` with an involutive
antiautomorphism `star` (the Krein adjoint `#`, i.e. a `StarRing`), under the axioms:
`cₑ² = 0`, `Γ² = 1`, `star Γ = Γ`, `{Γ, cₑ} = 0`, `[Γ, ∇ₑ] = [Γ, φ] = 0`,
`star φ = φ`. Two edges is the smallest setting exhibiting a nonzero closure channel.

## What is proved

### The four-block identity — no fifth block
`square_decomposition`:
`2·(D# D) = Q_A + Q_C + 2·E_# + 2·Q_T`,
where `Q_A` = aperture (edge-*symmetric* solder metric `{cₑ#,c_f}`), `Q_C` = closure
(edge-*antisymmetric* `[cₑ#,c_f]₋`), `Q_T = φ#φ` = turn, `E_#` = soldering (the `c`–`φ`
cross term). The `D# D` expansion falls *entirely* into these four groups — there is
no independent fifth term.

### Grade-type of each channel (the crux)
Under the only two structures the axioms provide — the chiral grading `Γ` and the
Krein adjoint `#` — the channels have `(Γ,#)`-type:

| channel | `Γ`-parity | `#`-parity |
|---|---|---|
| aperture `Q_A` | even (`aperture_even`) | self-adjoint (`aperture_selfadjoint`) |
| closure `Q_C`  | even (`closure_even`)  | self-adjoint (`closure_selfadjoint`) |
| turn `Q_T`     | even (`turn_even`)     | self-adjoint (`turn_selfadjoint`) |
| soldering `E_#`| **odd** (`solder_odd`) | self-adjoint (`solder_selfadjoint`) |

So `Q_A`, `Q_C`, `Q_T` all carry the **same** `(Γ,#)`-type (even, self-adjoint):
the axiom grading cannot tell them apart. Only `E_#` is separated (it is the unique
`Γ`-odd block).

### The coarse (2-block) split is genuinely forced
`parity_decomposition_unique`: the decomposition of any element into a `Γ`-even and a
`Γ`-odd part is unique. Applied to the square (`square_oddPart`, `square_evenPart`):

* `oddPart Γ (2·D#D) = 2·E_#`   — the chiral grading **canonically isolates the
  soldering block**;
* `evenPart Γ (2·D#D) = Q_A + Q_C + 2·Q_T`  — everything else is lumped into one
  even sector that the grading does **not** refine.

### Concrete non-vacuity (an explicit 4×4 rational Krein carrier)
Section `Concrete`: an explicit carrier with `η = diag(1,−1,1,−1)` (proved
indefinite, `eta_indefinite`) and Krein adjoint `A# = η Aᵀ η` (proved involutive /
antimultiplicative / additive — a genuine `StarRing`-type adjoint:
`kadj_invol`, `kadj_antimul`, `kadj_add`). All carrier axioms hold (`ax_*`). There:

* `Q_A = diag(0,0,4,10)`, `Q_C = diag(0,0,4,8)`, `Q_T = 1` (`aperture_val`,
  `closure_val`, `turn_val`);
* `shared_type_but_distinct` / `channels_pairwise_distinct`: these three channels are
  each `Γ`-even and `#`-self-adjoint (identical `(Γ,#)`-type) **yet pairwise distinct
  and nonzero**.

This makes the obstruction concrete: the axiom grading provably cannot separate
aperture, closure and turn — they are genuinely different operators of the same type.

## Interpretation / what the program must add

The four-block split becomes forced (rigid) only after adjoining structures **not**
among the carrier axioms:

1. a **solder-degree** grading (number of `c`-letters: `Q_T` has 0, `Q_A`/`Q_C` have
   2) — separates turn from {aperture, closure};
2. an **edge-index symmetrization** (`Q_A` symmetric vs `Q_C` antisymmetric in the
   edge pair) — separates aperture from closure.

Only the chiral grading `Γ` is currently an axiom, and it separates just the
soldering block. Hence "unification is decomposition" needs (at least) these two
extra selecting axioms; without them the aperture/closure/turn split is a *choice*,
not a consequence.

The *count* of channel types is, however, rigid: `D# D` lives entirely in the two
`Γ`-graded sectors (even bulk + odd solder), with the even bulk carrying exactly the
solder-degree-2 (aperture, closure) and solder-degree-0 (turn) content — no room for
a fifth type.
