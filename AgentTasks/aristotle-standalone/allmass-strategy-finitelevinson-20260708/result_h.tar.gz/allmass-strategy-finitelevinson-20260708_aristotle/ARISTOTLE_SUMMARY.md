# Summary of changes for run 6a5fb9e0-991f-4c47-949f-5164e1c11ebb
Delivered the finite-Levinson / null-edge-mass program targets in `RequestProject/Main.lean`, building cleanly and kernel-checked with axiom footprint exactly `[propext, Classical.choice, Quot.sound]` (guarded by in-file `#print axioms`). No `sorry`/`admit`/`native_decide`/new `axiom`; Mathlib only.

Results that land:

1. `finite_optical_theorem` (companion M-target) — fully general and faithful: for any complex 2×2 S-matrix `S = !![r, t'; t, r']` with `Sᴴ * S = 1`, it proves probability conservation `|r|²+|t|² = 1` and `|t'|²+|r'|² = 1`, plus the phase relation `conj r · t' + conj t · r' = 0`.

2. `finite_levinson` (the spine) — on an explicit rational barrier fixture, proves the three-way equality `#{bound states} = winding of arg(det S(θ)) = reflection-sector index` (= 3), each a finite `decide`-checked computation. `finite_levinson_two` re-confirms the correspondence on a second fixture (= 2).

Mathematical content: `det S(θ)` on the quasi-energy circle is (up to a positive real factor) a finite Blaschke product whose interior zeros are the bound states; the winding is computed as a genuine discrete phase-increment sum (signed crossings of a reference ray by the sampled loop). The three quantities are defined by genuinely different formulas — a topological crossing count (`levWindingDet`), a spectral filter (`levBoundCount`), and a reflection-ray crossing count (`levReflIndex`) — so their equality is real content. Everything is made exact/decidable via Gaussian-integer arithmetic on a 12-point radius-10 sampling of the circle.

`ARISTOTLE_SUMMARY.md` gives an honest account: the optical theorem and the winding/Blaschke machinery are fully general; the Levinson equality is proved (as the brief permits) fixture-specifically by `decide`, and I note the "Kill" caveat — a center outside the disk (Jost pole inside) contributes −1 to the winding, so the correspondence holds precisely for the genuine Blaschke/unitary-Jost structure (all centers inside), which is the case formalized. A fully universal statement would require formalizing the argument principle for finite Blaschke products and the equality of the discrete crossing-count with the analytic winding, which is beyond this finite fixture deliverable. All work is committed and pushed.

# ARISTOTLE_SUMMARY — Conjecture L: a finite Levinson theorem

All results live in `RequestProject/Main.lean`. The project builds cleanly; every listed
theorem is kernel-checked with axiom footprint exactly
`[propext, Classical.choice, Quot.sound]` (verified by the in-file `#print axioms`
guards). No `sorry`, `admit`, `native_decide`, `@[implemented_by]`, or new `axiom` is used.
Mathlib only.

## What landed

### 1. `finite_optical_theorem` — the finite optical theorem (companion M-target)

For **any** complex `2 × 2` scattering matrix `S = !![r, t'; t, r']` with `Sᴴ * S = 1`:

* `|r|² + |t|² = 1` and `|t'|² + |r'|² = 1` (probability conservation in both channels);
* `conj r · t' + conj t · r' = 0` (the reflection/transmission phase relation).

This is fully general and faithful — it holds for every complex `2 × 2` unitary S-matrix,
not just a fixture. It is the exact forward sum rule + phase relation requested.

### 2. `finite_levinson` — the finite Levinson equality (on an explicit fixture)

On a concrete rational barrier fixture we prove the three-way equality

```
#{bound states}  =  winding of arg(det S(θ))  =  reflection-sector index   ( = 3 )
```

as finite, kernel-checked (`decide`) computations. `finite_levinson_two` re-proves the
same correspondence on a second fixture (count `2`) as a robustness check.

## The mathematics behind the fixture (why it is genuine, not circular)

For a finite unitary scattering system the scattering determinant `det S(θ)`, viewed on
the quasi-energy circle `z = e^{iθ}`, is (up to a positive real factor) a finite
**Blaschke product** `B(z) = ∏_i (z - a_i)/(1 - conj(a_i)·z)` with `|a_i| < 1`. This is
the ratio of Jost functions; its zeros `a_i` inside the unit disk are exactly the barrier's
bound states, and the argument principle gives

> winding number of `θ ↦ B(e^{iθ})` around `0`  =  number of zeros inside the disk.

That is the discrete Levinson correspondence. The three quantities in `finite_levinson`
are defined by **genuinely different formulas**, so their equality is real content, not a
tautology:

* `levWindingDet` — winding of `det S` as a *discrete phase-increment sum*: the signed
  count of crossings of the `+x` ray by the sampled polygonal loop (`windingPos`);
* `levBoundCount` — the *spectral* count: number of Blaschke zeros with `|a_i| < 1`
  (a filter over `bfCenters`);
* `levReflIndex` — the *reflection-sector* index: the winding recomputed via crossings of
  the `−x` (reflection) reference ray (`windingNeg`).

To make all of this an exact, `decide`-able finite computation:

* the quasi-energy circle is sampled at `12` explicit points scaled to radius `10`, so all
  coordinates are Gaussian integers (`zs`); winding is scale-invariant;
* each center `a_i` is stored as `A_i = 10·a_i ∈ ℤ[i]` (`bfCenters`), so `|a_i| < 1`
  becomes `|A_i|² < 100`;
* `det S(θ_j)` is computed up to a positive real factor with Gaussian-integer arithmetic
  (`blaschkeProd`), which suffices because positive real factors do not change the winding.

The winding computation was validated independently: `windingPos` returns `n` for the loop
`z ↦ z^n` and for Blaschke products with `n` interior zeros, and `−1` for a factor whose
center lies outside the disk (the pole-inside case), matching the argument principle.

## What generalizes vs. what stays fixture-specific

Generalizes (proved in full generality):
* `finite_optical_theorem` — every complex `2 × 2` unitary S-matrix.
* The winding/Blaschke machinery (`gmul`, `blaschkeFactor`, `windingPos`, `windingNeg`)
  is generic; only the theorem *instances* are pinned to fixtures.

Stays fixture-specific (as the brief permits):
* `finite_levinson` / `finite_levinson_two` are proved by `decide` on concrete
  Gaussian-integer fixtures. The equality
  `winding = interior-zero count = reflection index` is verified for those instances, not
  proved as a universal theorem over all Blaschke products. A fully general statement would
  require formalizing the argument principle for finite Blaschke products (winding of an
  arbitrary interior-zero-only product equals the number of factors) and a proof that the
  discrete crossing-count equals the analytic winding when the sampling resolves every
  half-turn — both outside the scope of this finite, kernel-checked fixture deliverable.
* The `12`-point sampling resolves windings for the degree-`≤ 4` determinants used here;
  higher-degree fixtures would need proportionally finer samples.

## Note on the "Kill" branch

The correspondence is **not** automatic for arbitrary phase data: a factor whose center
lies outside the unit disk (equivalently, a Jost pole inside the disk) contributes `−1`
rather than `0` to the winding, so `winding = (#interior zeros) − (#interior poles)`, which
differs from the naive interior-center count. The positive Levinson equality holds
precisely for the genuine Blaschke (unitary-Jost) structure, i.e. all centers inside the
disk — which is exactly the fixture proved here.
