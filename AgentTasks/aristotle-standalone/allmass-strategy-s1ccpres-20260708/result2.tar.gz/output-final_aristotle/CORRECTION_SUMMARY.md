# Correction: non-degenerate physical-sector `b`-eigenbasis existence

This supersedes the earlier delivery documented in `ARISTOTLE_SUMMARY.md`, which
proved only the **degenerate** case.  The earlier statement imposed both
`QG.IsHermitian` and `QG * QG = 0`; over ℂ with the definite conjugate-transpose
adjoint these together force `QG = 0`, so the "physical sector" was just the full
carrier and the genuine simultaneous-structure argument was never exercised.

## What changed

The physical Gauss/BRST charge is **nilpotent and non-Hermitian** (self-adjoint
only for the indefinite Krein form). The Hermitian hypothesis was therefore
**dropped entirely**. The corrected hypotheses are exactly:

* `d : ι → ℂ`, `hd : ∀ i, d i = 1 ∨ d i = -1` — the `±1` grading `b = diagonal d`;
* `QG : Matrix ι ι ℂ`, `hQGnil : QG * QG = 0` — nilpotent (no Hermitian assumption);
* `hbQG : diagonal d * QG = QG * diagonal d` — `QG` commutes with the grading.

This does **not** collapse `QG`: e.g. on `Fin 3`, `d = (1,-1,1)`, `QG = e₀·e₂ᵀ`
is nonzero, nilpotent, non-Hermitian, commutes with `b`, and yields a genuine
1-dimensional physical sector (`card ι − 2·rank = 3 − 2 = 1`).

## Final statement (`src/S1CCPresentationExistence.lean`)

`physical_sector_b_eigenbasis_exists` now produces `P : Matrix ι κ ℂ` and
`e : κ → ℂ` with:

```
(∀ j, e j = 1 ∨ e j = -1) ∧
diagonal d * P = P * diagonal e ∧                 -- (a) columns are b-eigenvectors
QG * P = 0 ∧                                       -- (b) columns in ker QG
Fintype.card κ = Fintype.card ι - 2 * QG.rank ∧    -- (c) full physical dimension
(∃ L : Matrix κ ι ℂ, L * P = 1) ∧                  -- (d1) columns linearly independent
(∀ v, QG *ᵥ v = 0 → ∃ w z, v = P *ᵥ w + QG *ᵥ z)   -- (d2) span a complement of range QG
```

Clauses (c) and (d2) together make `range P` a genuine **complement of
`range QG` inside `ker QG`** (since `range QG ⊆ ker QG` from `QG² = 0`, the
physical dimension is `(card ι − rank) − rank = card ι − 2·rank`), and (d1)
gives the left inverse, i.e. the columns are independent. Orthonormality
`Pᴴ P = 1` is deliberately **not** used — without Hermitian structure it is not
the right notion, and `compression_balanced_eigbasis` needs only the
`b`-intertwining.

`physical_sector_balanced` (the prize) is re-derived on these corrected
hypotheses by feeding the eigenbasis to the already-proved
`compression_balanced_eigbasis`.

## The genuine argument (`src/S1CCEigenbasis.lean`, new)

The real math lives in the new abstract file, stated for a nilpotent `φ`
commuting with an involution `β` on a finite-dimensional ℂ-space (no Hermitian
hypothesis anywhere):

* `range_le_ker`, `ker_beta_invariant`, `range_beta_invariant` — `range φ ⊆ ker φ`
  and both are `β`-invariant.
* `involution_isCompl_eigenspaces` — the `±1` eigenspaces of the involution `β`
  are complementary.
* `invariant_eigen_sup` — a `β`-invariant submodule is the sum of its
  intersections with the two eigenspaces.
* `exists_relCompl` — relative complement of `A ≤ B`.
* `exists_eigen_complement` — assembles `Wp ⊕ Wm`, a `β`-eigen-decomposed
  complement of `range φ` inside `ker φ`, with the dimension count
  `dim Wp + dim Wm + 2·dim(range φ) = dim V` (via `finrank_sup_add_finrank_inf`
  and rank–nullity).
* `eigenbasis_core` — turns the complement into a linearly independent family of
  `β`-eigenvectors (`±1` eigenvalues) in `ker φ` spanning it, with the cardinality
  pinned.

`b` descends to `ker QG / range QG` and we pick a `b`-eigenbasis of a complement
of `range QG` there — the non-degenerate simultaneous-structure argument the
reviewer asked for.

## Verification

* `lake build` succeeds; no `sorry` / `admit` / `native_decide` / `axiom` /
  `@[implemented_by]` in any of the new proofs.
* In-file `#guard_msgs` + `#print axioms` confirm the footprint
  `[propext, Classical.choice, Quot.sound]` for both
  `physical_sector_b_eigenbasis_exists` and `physical_sector_balanced`.
* `S1CCEigenbasis.eigenbasis_core` and its helpers are `sorry`-free.
