/-
# S1-CC: the general-representative reduction (witness ⇒ general)

This file upgrades the explicit `6×6` witness of `S1CCPhysicalSectorWitness.lean`
to the **general scalar-metric statement**: the closure Krein form on the
physical Gauss sector is balanced (`n₊ = n₋`) for *every* representative, not
just the coordinate-aligned witness.

## The structural point

The witness balance is proved by a `b`-anticonjugation `b (J Q_C) b = -(J Q_C)`
of the full-carrier closure form, together with the descent of `b` to the
physical sector `V'/N`.  The key observation of this file is that this mechanism
is **structural and coordinate-free**:

* The closure grading `b = σz ⊗ 1` is a **diagonal `±1` grading** of the carrier.
* Passing to the physical sector `V'/N = ker Q_G / range Q_G` is realized (after
  diagonalizing the Hermitian Gauss operator `G` on the color leg — always
  possible since `[G,K]=0` makes `K` block-diagonal in the `G`-eigenbasis and
  leaves `b = σz ⊗ 1` untouched) as a **submatrix compression** `J ↦ J.submatrix r r`
  onto the coset representatives `r`.
* A diagonal grading anticonjugation is inherited by *any* submatrix compression
  (`compression_inherits_anticonj`), for *any* choice of representatives `r`.

Everything is stated over arbitrary finite index types: `ι` indexes the full
carrier (for the physical program a *product* type such as `Fin 2 × Fin 3`,
Clifford ⊗ color), and `κ` indexes the coset representatives.  Hence, by the
balance engine `hermitian_balanced_count_of_neg_charpoly`, the compressed form is
balanced for every scalar-metric `Q_G`.  The particular `Q_G` only fixes *which*
index set `r : κ → ι` the compression uses; it never affects the inherited
anticonjugation, so it never affects the balance.

This is the promised "upgrade witness → general": balance holds for the whole
scalar-metric class, and the only escape (a genuinely *soldered* `Q_G` mixing
the Clifford and color legs, so that `b` no longer preserves `ker Q_G`/`range Q_G`)
is exactly the pre-registered kill condition **K-A**.  See
`S1CC_GENERAL_REDUCTION.md` for the precise no-go boundary.  The witness itself
is re-derived as a literal instance in `S1CCWitnessAsInstance.lean`.
-/

import src.S1CCBalancedInertia

namespace PhysicsSM.Draft.NullEdge.GateYM.S1CCGeneralReduction

open Matrix
open PhysicsSM.Draft.NullEdge.GateYM.S1CCBalancedInertia

variable {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ] [DecidableEq κ]

/-- A `±1` grading `d` yields an involutive diagonal matrix, `(diagonal d)² = 1`. -/
theorem diagonal_grading_sq (d : ι → ℂ) (hd : ∀ i, d i = 1 ∨ d i = -1) :
    diagonal d * diagonal d = 1 := by
  ext i j; by_cases hi : i = j <;> simp_all +decide [ Matrix.mul_apply ] ;
  · cases hd j <;> simp +decide [ *, Matrix.one_apply ]; all_goals simp +decide [ *, diagonal ];
  · simp +decide [ diagonal, hi ]

/-- **Compression inherits anticonjugation.** If a diagonal grading `diagonal d`
anticonjugates a matrix `J` on the full carrier (`diagonal d * J * diagonal d = -J`),
then for *any* representative selection `r : κ → ι` the descended grading
`diagonal (d ∘ r)` anticonjugates the submatrix compression `J.submatrix r r`.
This holds entrywise and is independent of which indices `r` selects — the heart
of the witness → general upgrade. -/
theorem compression_inherits_anticonj (J : Matrix ι ι ℂ) (d : ι → ℂ)
    (hanti : diagonal d * J * diagonal d = -J) (r : κ → ι) :
    diagonal (d ∘ r) * J.submatrix r r * diagonal (d ∘ r) = -(J.submatrix r r) := by
  ext i j; simp +decide [ *, Matrix.mul_apply, Matrix.diagonal ] ;
  replace hanti := congr_fun ( congr_fun hanti ( r i ) ) ( r j ) ; simp_all +decide [ Matrix.mul_apply, Matrix.diagonal ] ;

/-- **General reduction (prize).** Let `J` be Hermitian on the full carrier `ι`,
`d` a `±1` closure grading whose diagonal matrix anticonjugates `J`, and
`r : κ → ι` *any* selection of physical-sector coset representatives.
Then the compressed closure form `J.submatrix r r` is **balanced**: it has
exactly as many strictly positive as strictly negative Hermitian eigenvalues.

No hypothesis on the Gauss charge `Q_G` appears: the only role `Q_G` plays is to
determine the representative set `r`, and balance holds for *every* `r`. -/
theorem compression_balanced (J : Matrix ι ι ℂ) (hJ : J.IsHermitian)
    (d : ι → ℂ) (hd : ∀ i, d i = 1 ∨ d i = -1)
    (hanti : diagonal d * J * diagonal d = -J) (r : κ → ι) :
    (Finset.univ.filter (fun i => 0 < (hJ.submatrix r).eigenvalues i)).card =
      (Finset.univ.filter (fun i => (hJ.submatrix r).eigenvalues i < 0)).card := by
  set B := J.submatrix r r with hBdef
  set S := diagonal (d ∘ r) with hSdef
  have hSsq : S * S = 1 := diagonal_grading_sq (d ∘ r) (fun i => hd (r i))
  haveI : Invertible S := ⟨S, hSsq, hSsq⟩
  have hinv : ⅟S = S := invOf_eq_right_inv hSsq
  have hAnti : ⅟S * B * S = -B := by
    rw [hinv]; exact compression_inherits_anticonj J d hanti r
  exact hermitian_balanced_count_of_neg_charpoly B (hJ.submatrix r)
    (anticonj_charpoly_eq B S hAnti)

/-- **No-positivity corollary.** If, in addition, the compressed form is
nondegenerate (`IsUnit (J.submatrix r r).det`) on a nonempty sector, then it has
a strictly negative eigenvalue — so the closure form is **never positive
semidefinite** on a nontrivial physical sector. -/
theorem compression_has_neg_eigenvalue (J : Matrix ι ι ℂ)
    (hJ : J.IsHermitian) (d : ι → ℂ) (hd : ∀ i, d i = 1 ∨ d i = -1)
    (hanti : diagonal d * J * diagonal d = -J) (r : κ → ι)
    (hdet : IsUnit (J.submatrix r r).det) (hκ : Nonempty κ) :
    ∃ i, (hJ.submatrix r).eigenvalues i < 0 := by
  contrapose! hdet; have := compression_balanced J hJ d hd hanti r; simp_all +decide ;
  -- No strictly negative eigenvalue ⇒ that filter is empty.
  have h_empty_neg : Finset.univ.filter (fun i => (hJ.submatrix r).eigenvalues i < 0) = ∅ := by
    exact Finset.eq_empty_of_forall_notMem fun i hi => not_lt_of_ge ( hdet i ) ( Finset.mem_filter.mp hi |>.2 );
  simp_all +decide [ Finset.ext_iff ];
  rw [ Matrix.IsHermitian.det_eq_prod_eigenvalues ( hJ.submatrix r ) ];
  exact Finset.prod_eq_zero ( Finset.mem_univ hκ.some ) ( by norm_num [ le_antisymm ( this _ ) ( hdet _ ) ] )

end PhysicsSM.Draft.NullEdge.GateYM.S1CCGeneralReduction

/-! ## Build-enforced axiom pins -/

/-- info: 'PhysicsSM.Draft.NullEdge.GateYM.S1CCGeneralReduction.compression_balanced' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms PhysicsSM.Draft.NullEdge.GateYM.S1CCGeneralReduction.compression_balanced

/-- info: 'PhysicsSM.Draft.NullEdge.GateYM.S1CCGeneralReduction.compression_has_neg_eigenvalue' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms PhysicsSM.Draft.NullEdge.GateYM.S1CCGeneralReduction.compression_has_neg_eigenvalue
