# Summary of changes for run ff4da7c0-fc2a-4ae4-bb06-53bcc5092849
Completed the F8 task "binding defect = entanglement deficit" in `src/BindingEntanglementDeficit.lean`. All theorems are kernel-checked, Mathlib-only, contain no `sorry`/`admit`/`native_decide`/new axioms, and the in-file `#print axioms` confirms the footprint is exactly `[propext, Classical.choice, Quot.sound]` for each.

Coupled block: `Bc(λ,κ) = !![λ, κi; −κi, λ]`.

Exact entanglement measure used: the ℓ₁ off-diagonal coherence (concurrence-type measure) of the normalized coupled density `ρ = Bc / tr Bc`, namely `C(ρ) := 2‖ρ₀₁‖`, which has closed form `C(ρ) = κ/λ`.

Results proved:
1. `binding_defect_eq_coupling` — exact spectral statement: `spectrum ℂ (Bc λ κ) = {λ−κ, λ+κ}`, the least eigenvalue is `λ−κ` (`IsLeast`), so the binding defect `Δ = λ − (λ−κ) = κ`.
2. `binding_defect_eq_concurrence` (the prize) — the EXACT identity `κ = C(ρ)·λ` (equivalently `Δ = C(ρ)·(tr Bc)/2`, since `tr Bc = 2λ`): the mass lost to binding equals the coupled block's coherence/concurrence times the aperture.
3. `concurrence_eq` — `C(ρ) = κ/λ`.
4. `binding_below_threshold_iff_entangled` — `Δ ≠ 0 ↔ C(ρ) ≠ 0` (binds below the constituent sum iff entangled, `κ ≠ 0`).

Honesty note (also in `ARISTOTLE_SUMMARY.md`): the identity is an exact equality, not an approximation. The normalization is explicit and standard — the factor relating defect to coherence is exactly the aperture `λ = (tr Bc)/2`. The only extra hypothesis beyond the stated regime `0 ≤ κ ≤ λ` is `0 < λ`, needed so `ρ = Bc/tr Bc` is well defined (when `λ = 0` the regime forces `κ = 0`, `Δ = 0` trivially). `ARISTOTLE_SUMMARY.md` documents the measure, identities, and this normalization.

# Binding defect = entanglement deficit (F8) — results

All results live in `src/BindingEntanglementDeficit.lean`, are kernel-checked, use
Mathlib only, and contain no `sorry`/`admit`/`native_decide`/new `axiom`. The
in-file `#print axioms` reports the footprint `[propext, Classical.choice,
Quot.sound]` for every theorem.

## The coupled block

`Bc(λ,κ) = !![λ, κi; −κi, λ]` (Hermitian; the spectator mode `λ` of the full
mass-gap block is dropped).

## Exact entanglement measure used

The normalized coupled density is `ρ = Bc / tr Bc` (`coupledDensity`), a genuine
`2×2` density matrix in the binding regime `0 ≤ κ ≤ λ`, `0 < λ`. The entanglement
measure is the **`ℓ₁` off-diagonal coherence** (the concurrence-type / coherence
measure of the coupled block):

    C(ρ) := 2‖ρ₀₁‖   (`concurrence`).

It has the closed form `C(ρ) = κ/λ` (`concurrence_eq`).

## Results

1. `binding_defect_eq_coupling` — the binding defect is the coupling `κ`.
   Proven as an exact spectral statement:
   `spectrum ℂ (Bc λ κ) = {λ−κ, λ+κ}`, the least eigenvalue is `λ−κ`
   (`IsLeast {λ−κ, λ+κ} (λ−κ)`), and `Δ = λ − (λ−κ) = κ`.

2. `binding_defect_eq_concurrence` (the prize) — the **exact** identity

       κ = C(ρ) · λ .

   Equivalently, since `tr Bc = 2λ`, `Δ = C(ρ) · (tr Bc)/2`. The mass lost to
   binding (`Δ = κ`) equals the off-diagonal coherence/concurrence of the coupled
   block times the aperture `λ`.

3. `concurrence_eq` — the closed form `C(ρ) = κ/λ`.

4. `binding_below_threshold_iff_entangled` — `Δ ≠ 0 ↔ C(ρ) ≠ 0`: the state binds
   strictly below the constituent sum iff the coupled block is entangled (`κ ≠ 0`).

## Honesty note

The identity `Δ = κ = C(ρ)·λ` is an **exact equality**, not an approximation, with
an explicit and standard normalization: `C(ρ)` is the `ℓ₁` off-diagonal coherence
`2‖ρ₀₁‖` of `ρ = Bc / tr Bc`. The normalization factor is exactly the aperture
`λ = (tr Bc)/2`, i.e. `Δ = C(ρ)·(tr Bc)/2`. The only extra hypothesis beyond
`0 ≤ κ ≤ λ` is `0 < λ` (needed so `ρ = Bc/tr Bc` is well defined; when `λ = 0` the
regime forces `κ = 0` and `Δ = 0` trivially). The block being a bona fide density
matrix (PSD) is the stated physical regime `0 ≤ κ ≤ λ`; the algebraic coherence
identity itself holds for all `0 ≤ κ`, `0 < λ`.
