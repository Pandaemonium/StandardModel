# Summary of changes for run 270aa2d5-0fac-4691-af68-46866da92bc7
## F5 verdict: the carrier's OWN closure curvature K lands in the binding plane — the carrier binds, unconditionally.

I added `src/CarrierClosurePlane.lean` (builds cleanly, no `sorry`/`admit`/`native_decide`/new `axiom`; kernel footprint exactly `[propext, Classical.choice, Quot.sound]`, guarded with in-file `#print axioms`), building on the given `DerivedInteraction`/`InteractingTwoBody` definitions without weakening them. A companion `ARISTOTLE_SUMMARY.md` records the findings.

**1. The carrier's K.** Reading the off-diagonal closure part off the mass block `B(λ,κ) = λ·I + i·κ·K` gives the explicit real antisymmetric generator `carrierK = !![0,0,0; 0,0,-1; 0,1,0]`. Proved: `massBlock_eq_carrierK` shows `B(λ,κ) = λ·I + i·κ·carrierK` exactly (so `carrierK` genuinely IS the block's closure generator), plus `carrierK_isReal` and `carrierK_antisymm` (`Kᵀ = −K`).

**2. Which plane (finite matrix identity).** `carrierK_eq_closureCurvature` proves `carrierK = closureCurvature`, the excited-mode/binding-plane curvature. `carrierK_ground_spectator` proves row/column 0 vanish (ground mode 0 is a spectator; curvature acts purely in the excited plane {1,2}). `carrierK_ne_closureCurvature2` proves it is NOT the ground-plane curvature, and `closureCurvature2_couples_ground` proves the ground-plane curvature does couple mode 0 — the decisive contrast.

**3. C → M upgrade.** Since the carrier's K is in the binding plane, I built the carrier's own second-quantized two-body Hamiltonian `carrierH2 = dΓ(diag d + i·κ·carrierK)` (`carrierH2_eq_H2der` identifies it with `H2der`) and fired the flagship `carrier_closure_binds`: for a sorted spectrum `d 0 ≤ d 1 ≤ d 2` and `κ > 0`, `carrierH2` has least eigenvalue `boundEnergy d κ` lying strictly below the free two-body threshold `pairThreshold d` — with NO "if the closure acts among excited modes" hypothesis. This turns "closure can bind" into "this carrier's closure binds."

The honest opposite case is also pinned down: a carrier would fail to bind only if its curvature coupled the ground mode (the `closureCurvature2` plane), where `derived_wrongPlane_no_binding` puts the least eigenvalue exactly at threshold for weak κ. The actual carrier provably does the opposite.

All changes are committed and pushed to `origin/main`.

# F5 — Does the carrier's OWN closure curvature `K` land in the binding plane?

**Verdict: YES. The carrier's closure curvature is the binding-plane (excited-mode)
curvature, so this carrier binds — unconditionally.**

New file: `src/CarrierClosurePlane.lean` (kernel-checked, footprint
`[propext, Classical.choice, Quot.sound]`, guarded with in-file `#print axioms`).
Builds on `src/DerivedInteraction.lean` and `src/InteractingTwoBody.lean` without
weakening them.

## 1. The carrier's `K`

The carrier one-particle mass block is `B(λ,κ) = λ·I + i·κ·K` on `Fin 3`. Reading
the off-diagonal *closure* part off the block gives the explicit real
antisymmetric generator

```
carrierK = !![0,0,0;
              0,0,-1;
              0,1,0]
```

- `massBlock_eq_carrierK` : `B(λ,κ) = λ·I + i·κ·carrierK` **exactly** — so
  `carrierK` is genuinely the closure generator of the carrier block.
- `massBlock_closurePart` : `B(λ,κ) − λ·I = i·κ·carrierK`.
- `carrierK_isReal`, `carrierK_antisymm` (`Kᵀ = −K`) : it is a legitimate real
  antisymmetric closure curvature.

## 2. Which plane it occupies (finite matrix identity)

- `carrierK_eq_closureCurvature` : `carrierK = closureCurvature` — the
  **excited-mode / binding-plane** curvature of `DerivedInteraction`.
- `carrierK_ground_spectator` : row and column `0` of `carrierK` vanish — the
  ground mode `0` is a spectator; the curvature acts purely in the excited plane
  `{1,2}`.
- `carrierK_ne_closureCurvature2` : `carrierK ≠ closureCurvature2` — it is **not**
  the ground-plane (no-binding) curvature.
- `closureCurvature2_couples_ground` : the ground-plane curvature *does* couple
  mode `0` (`(0,1)` entry `≠ 0`) — the decisive geometric contrast.

## 3. The C → M upgrade: the carrier binds unconditionally

Because the carrier's own `K` lands in the binding plane, the conditional theorem
`derived_boundState_below_threshold` fires with the carrier's own mass-block data,
removing the "if the closure acts among the excited modes" hypothesis for this
carrier.

- `carrierOneBody`, `carrierH2` : the carrier's own second-quantized two-body
  Hamiltonian, `carrierH2 = dΓ(diag d + i·κ·carrierK)`, built directly from the
  mass-block closure curvature.
- `carrierH2_eq_H2der` : `carrierH2 = H2der` — the carrier's own `K` is the
  curvature whose second quantization is the binding interaction.
- **`carrier_closure_binds`** (flagship): for a sorted spectrum
  `d 0 ≤ d 1 ≤ d 2` and `κ > 0`,

  ```
  IsLeast (spectrumC (carrierH2 d κ)) (boundEnergy d κ)  ∧
      boundEnergy d κ < pairThreshold d
  ```

  i.e. the carrier's closure geometry produces a genuine two-body bound state
  strictly below the constituent threshold, with no plane-choice hypothesis.

## What a *non-binding* carrier would require

By `carrierK_ground_spectator` vs `closureCurvature2_couples_ground`: a carrier
would fail to bind only if its closure curvature coupled the ground mode `0`
(the `closureCurvature2` plane), in which case `derived_wrongPlane_no_binding`
gives least eigenvalue exactly at threshold for `κ² ≤ (d 2 − d 0)(d 2 − d 1)`.
The actual carrier `K` provably does the opposite: it leaves mode `0` a spectator
and couples the excited modes `{1,2}`, so it binds.

## Axiom footprint

`massBlock_eq_carrierK`, `carrierK_eq_closureCurvature`, and
`carrier_closure_binds` each depend only on
`[propext, Classical.choice, Quot.sound]` (in-file `#print axioms`).
