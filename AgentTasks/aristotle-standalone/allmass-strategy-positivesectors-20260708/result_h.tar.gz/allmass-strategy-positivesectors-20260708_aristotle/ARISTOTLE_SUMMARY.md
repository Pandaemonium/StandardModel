# Summary of changes for run e7ce38ba-ae38-48a0-900a-a885c6d7b234
Delivered program step 2 — a classification of which finite Krein carriers have a positive mass sector — as kernel-checked Lean theorems in `RequestProject/Main.lean` (builds cleanly, no `sorry`/`admit`/`native_decide`/new `axiom`, Mathlib only). Every headline result has an in-file `#print axioms` line confirming the footprint `[propext, Classical.choice, Quot.sound]`. A companion write-up is in `ARISTOTLE_SUMMARY.md`.

Model: the carrier's reduced sector form is a Hermitian matrix `M`; a positive mass sector means `M.PosDef` (`HasPositiveMassSector`), with the mass gap the least eigenvalue; `IsIndefinite` means neither `M` nor `-M` is positive semidefinite.

1. Sufficient positivity criterion (aperture dominance / grading separation), generalizing `M6 = 1 + BᴴB` beyond the `Cl(4)` witness:
   - `posDef_aperture_add_gram`: `A.PosDef → (A + BᴴB).PosDef` (closure entering squared, as a Gram term, can never destabilize a positive aperture).
   - `posDef_one_add_gram`: `(1 + BᴴB).PosDef`; `separatedSector_posDef`: `(a•1 + BᴴB).PosDef` for any closure strength when `a>0`.
   - Mass gap: `massGap_one_add_gram` (Rayleigh quotient ≥ ‖x‖², gap ≥ 1), `massGap_pos`, `eigenvalues_pos_of_positiveMassSector`; `gram_posSemidef` shows the closure alone is only semidefinite.
   - Explicit reconstruction of the witness: `T2_B`, `T2_M6 = 1 + T2_Bᴴ T2_B`, `T2_positive_mass`, `T2_massGap`.

2. No-go / "too balanced" regime (grading coincidence): with the chirality `Γ = diag(1,-1)` (`chir`, shown a traceless Hermitian involution), the balanced doublet `balancedSector a c = a•1 + c•Γ = diag(a+c,a-c)` has the closure enter linearly and compete with the aperture; `balanced_indefinite` proves no positive sector exists once `a < |c|`.

3. Trichotomy / finite phase diagram, cut at the exact threshold `|c| = a`: `balanced_massive` (`|c|<a` ⇒ PosDef), `balanced_critical` (`|c|=a` ⇒ PosSemidef, not PosDef — massless zero mode), `balanced_indefinite` (`|c|>a` ⇒ indefinite), unified in `balanced_phase_classification` (for every `a>0` exactly one phase occurs). The structural threshold separating the massive from the balanced regime is the grading itself — squared (Gram) vs linear closure — with the numerical boundary `|c| = a` inside the coincident regime.

The design principle "enough Clifford room lets the closure be signed while the aperture stabilizes" is made precise as: a closure graded away from chirality enters as `BᴴB` (always positive semidefinite) rather than `c•Γ` (indefinite). `ARISTOTLE_SUMMARY.md` records the honest proved-vs-conjectured boundary (necessity in fully general carriers and higher-dimension multi-edge trichotomy beyond the `1+BᴴB` and `diag(a±c)` normal forms are stated but not formalized).

# Positive mass sectors of finite Krein carriers — summary

This delivers program **step 2**: turning the `Cl(4)` witness `T2_positive_mass` from an
example into a theorem, with a sufficient positivity criterion, the matching no-go, and a
finite phase diagram. All results are in `RequestProject/Main.lean`, are kernel-checked with
footprint `[propext, Classical.choice, Quot.sound]` (in-file `#print axioms` block), use
Mathlib only, and contain no `sorry`/`admit`/`native_decide`/new `axiom`.

## Model

A finite Krein carrier, after constraint/quotient/sector selection, is described by its
**sector form** — a Hermitian matrix `M : Matrix n n ℂ`. The carrier
*has a positive mass sector* (`HasPositiveMassSector M`) exactly when `M` is positive
definite (`M.PosDef`); the physical masses are its eigenvalues, all positive, and the ground
eigenvalue is the **mass gap**. `IsIndefinite M` means neither `M` nor `-M` is positive
semidefinite (the form takes both signs), so there is no positive sector.

The sector form splits as `aperture + closure`. The entire classification is controlled by
**how the closure enters**, which depends on whether the closure bivector `b` coincides with
the chirality `Γ`.

## 1. Sufficient positivity criterion (aperture dominance / grading separation)

**Design principle, made precise:** *enough Clifford room lets the closure be signed while
the aperture stabilizes.* When the closure is graded away from chirality (`b ≠ Γ`), it can
only enter the sector form **squared**, as a Gram term `Bᴴ B`, which is positive
semidefinite for every `B`. Hence it can never destabilize a positive aperture.

- `posDef_aperture_add_gram` : `A.PosDef → (A + Bᴴ B).PosDef` — the general criterion.
- `posDef_one_add_gram` : `(1 + Bᴴ B).PosDef` — the abstract `M6 = 1 + Bᴴ B` mechanism.
- `separatedSector_posDef` : for `0 < a`, `(a • 1 + Bᴴ B).PosDef` for **any** closure block
  `B` — grading separation gives a single massive phase, independent of closure strength.
- `massGap_one_add_gram` : `xᴴ(1 + Bᴴ B)x ≥ xᴴx = ‖x‖²`, i.e. mass gap `≥ 1`.
- `massGap_pos`, `eigenvalues_pos_of_positiveMassSector` : a positive sector has an
  all-positive spectrum and a strictly positive least eigenvalue.
- `gram_posSemidef` : the closure alone `Bᴴ B` is only positive **semi**definite — the
  aperture is what supplies the gap.

The `Cl(4)` witness is reconstructed explicitly: `T2_B : Matrix (Fin 2) (Fin 4) ℂ`
(two edges into a 4-dim carrier), `T2_M6 = 1 + T2_Bᴴ T2_B`, with `T2_positive_mass`,
`T2_massGap` (gap `≥ 1`), and `T2_closure_posSemidef`.

## 2. The no-go / "too balanced" regime (grading coincidence)

When the closure bivector coincides with the chirality `Γ = diag(1,-1)` (`chir`;
`chir_involution`, `chir_trace = 0`, `chir_isHermitian`), the closure enters **linearly** as
`c • Γ` with `Γ` indefinite, and now competes directly with the aperture. The single-doublet
sector form is `balancedSector a c = a • 1 + c • Γ = diag(a+c, a-c)` (`balancedSector_eq`).

- `balanced_indefinite` : for `0 ≤ a` and `a < |c|`, `IsIndefinite (balancedSector a c)` —
  no positive sector exists.

## 3. The phase diagram (trichotomy)

The **exact threshold** separating positivity from the no-go is `|c| = a`:

- `balanced_massive`  : `|c| < a  → PosDef`                       (massive)
- `balanced_critical` : `0 < a, |c| = a → PosSemidef ∧ ¬ PosDef`  (critical / massless zero mode)
- `balanced_indefinite`: `0 ≤ a, |c| > a → IsIndefinite`          (indefinite)

`balancedPhase a c` computes the phase from the threshold, and
`balanced_phase_classification` proves that for every `0 < a` the carrier realizes exactly
the named phase — a finite, mutually exclusive and exhaustive phase diagram for the existence
of physical mass, as a function of aperture strength `a` and closure strength `c`.

The two regimes together: grading **separation** (`b ≠ Γ`, closure squared) → one massive
phase for all closure strengths; grading **coincidence** (`b = Γ`, closure linear) →
massive/critical/indefinite trichotomy cut at `|c| = a`. The structural threshold is the
grading itself (squared vs linear closure); within the coincident regime the numerical
threshold is `|c| = a`.

## Proved vs conjectured (honest boundary)

**Proved (kernel-checked):** the sufficient criterion and its `M6 = 1 + Bᴴ B` /
`a • 1 + Bᴴ B` instances with mass gaps; the positive-spectrum / mass-gap statements; the
explicit `Cl(4)` witness; the full massive/critical/indefinite trichotomy and phase
classification for the balanced doublet family; the chirality being a traceless Hermitian
involution.

**Not formalized here (scope / conjectural):** that grading coincidence is *necessary* for an
indefinite phase in a fully general carrier (only the two representative families are
compared); the trichotomy for genuinely multi-edge, higher Clifford-dimension carriers beyond
the `1 + Bᴴ B` and `diag(a±c)` normal forms (the `2×2` doublet and the Gram normal form are
the small explicit models); and the interaction with explicit Gauss/BRST quotient data, which
is here absorbed into the reduced sector form `M`.
