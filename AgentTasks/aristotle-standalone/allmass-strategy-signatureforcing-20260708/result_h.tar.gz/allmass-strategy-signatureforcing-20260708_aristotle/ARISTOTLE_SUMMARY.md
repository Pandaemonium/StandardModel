# Summary of changes for run 125e0095-b460-431c-9d02-e38fe0fcb653
Delivered the null-edge mass program (Conjecture M) work in `RequestProject/Main.lean`. The file builds cleanly; every proved statement is kernel-checked with axiom footprint `[propext, Classical.choice, Quot.sound]` via an in-file `#print axioms` guard. No `sorry`/`admit`/`native_decide`/new `axiom`/`@[implemented_by]`; Mathlib only.

Rung 1 — fully proved. `null_forces_indefinite`: a real quadratic form with a nonzero isotropic (null) vector is neither positive- nor negative-definite (one line from `PosDef.anisotropic`). Split into `null_forces_not_posDef` / `null_forces_not_negDef` (the latter via `PosDef (-Q)`), plus the contrapositive `posDef_no_null`. The Clifford wrapper `clifford_null_forces_indefinite` shows a genuine null edge (`c(v) = ι Q v ≠ 0` yet `c(v)^2 = 0`) forces indefiniteness, using `CliffordAlgebra.ι_sq_scalar` and injectivity of the structure map.

Concrete witnesses — fully proved. Explicit null vectors give `Q13_indefinite` (signature (1,3)) and `Q22_indefinite` (signature (2,2)), showing indefiniteness alone does not single out Lorentzian — which motivates a second selector.

Celestial cross-check — clean part fully proved. The sphere connectedness dichotomy underlying the celestial-quadric selector: `S^{p-1}` is connected for rank > 1 (`celestial_sphere_connected`), while the p=1 case is the two-point set `{-1,1}` (`celestial_sphere_dim_one_eq`) which is not preconnected (`celestial_sphere_disconnected_dim_one`). The full quotient topology (S^{p-1}×S^{q-1})/ℤ₂ is not formalized.

Rung 2 — pre-registered probe (stated, not proved, definition only). A precise finite reflection-positivity formulation: `RPDatum`, `RPGram`, `IsReflectionPositive`, `HasNondegeneratePhysicalSector`, the two-part claim `ReflectionPositivityProbe` ((1,3) passes with a nondegenerate physical sector; every (2,2) RP datum degenerates), and the explicit `ReflectionPositivityKill` statement. A clean finite quadratic-form theorem was not reachable because the (1,3)-vs-(2,2) distinction lives in the OS lattice/tensor structure rather than the quadratic form alone, so rung 2 is delivered as the precise probe the strategy allows.

Full details and honest status are in `ARISTOTLE_SUMMARY.md`. All work is committed and pushed.

# ARISTOTLE_SUMMARY.md — Conjecture M (null-edge mass program)

All work lives in `RequestProject/Main.lean`. It builds cleanly, and every *proved*
statement is kernel-checked with axiom footprint `[propext, Classical.choice, Quot.sound]`
(verified by the in-file `#print axioms` block). No `sorry` / `admit` / `native_decide` /
new `axiom` / `@[implemented_by]` is used. Mathlib only.

## Rung 1 — proved

The null primitive forces indefiniteness, one line from the definition of positive
definiteness (a positive-definite form is anisotropic, so it has no nonzero null vector).

- `null_forces_not_posDef` — a nonzero isotropic vector rules out positive-definiteness.
- `null_forces_not_negDef` — same for negative-definiteness (phrased as `PosDef (-Q)`).
- `Indefinite Q := ¬ Q.PosDef ∧ ¬ (-Q).PosDef`.
- `null_forces_indefinite` — **main rung 1**: one nonzero null vector ⟹ `Indefinite Q`,
  for any real quadratic form `Q : QuadraticForm R V` over an ordered commutative ring.
- `posDef_no_null` — the contrapositive "definite ⟹ no null edge" reading.
- `clifford_null_forces_indefinite` — **Clifford wrapper**: for a real Clifford algebra,
  a null edge (`c(v) = ι Q v ≠ 0` but `c(v)^2 = 0`) forces `Q` indefinite. Uses
  `CliffordAlgebra.ι_sq_scalar` (`c(v)^2 = Q(v) • 1`) and injectivity of
  `algebraMap ℝ (CliffordAlgebra Q)`.

## Concrete witnesses — proved

Explicit null edges show both signatures are indefinite, so indefiniteness *alone* does
not select Lorentzian (this is what motivates rung 2):

- `Q13 := weightedSumSquares ℝ ![1,-1,-1,-1]`, null vector `![1,1,0,0]` ⟹ `Q13_indefinite`.
- `Q22 := weightedSumSquares ℝ ![1,1,-1,-1]`, null vector `![1,0,1,0]` ⟹ `Q22_indefinite`.

## Celestial-quadric cross-check — proved (clean part)

The projective null quadric of signature `(p,q)` is `(S^{p-1} × S^{q-1})/ℤ₂`; it collapses
to a single sphere exactly when a spherical factor degenerates (`p = 1` or `q = 1`). The
clean formal heart is the connectedness dichotomy of the factor `S^{p-1}`:

- `celestial_sphere_connected` — `S^{p-1}` is connected for rank `> 1` (via
  `isConnected_sphere`).
- `celestial_sphere_dim_one_eq` — the `p = 1` sphere in `ℝ` is `{-1, 1}`.
- `celestial_sphere_disconnected_dim_one` — that two-point set is **not** preconnected.

The full quotient topology `(S^{p-1} × S^{q-1})/ℤ₂` is not formalized here; the proved
dichotomy is the load-bearing degeneration (`p = 1` ↔ one time direction).

## Rung 2 — pre-registered probe (stated, not proved)

Rung 2 is delivered as a precise `Prop`-valued definition, as the strategy permits when the
full Osterwalder–Schrader proof is out of reach. It is a definition only (no proof, hence
no `sorry` and no axiom footprint):

- `RPDatum n g` — a finite reflection-positivity datum: a linear involution `θ`
  (Euclidean-time reflection) that is a `g`-isometry, plus a coordinate subset `S`
  spanning the positive-time sector.
- `RPGram D` — the reflected Gram matrix, entries `polar g (θ eᵢ) eⱼ` for `i,j ∈ S`.
- `IsReflectionPositive D := (RPGram D).PosSemidef`.
- `HasNondegeneratePhysicalSector D := RPGram D ≠ 0`.
- `ReflectionPositivityProbe` — **the probe**: `(1,3)` admits an RP datum with a
  nondegenerate physical sector, while every RP datum for `(2,2)` has a degenerate one.
- `ReflectionPositivityKill` — the explicit KILL statement (a `(2,2)` RP datum with a
  nondegenerate physical sector); proving it would refute the selector.

## Honest status

- Rung 1 (including Clifford wrapper): **fully proved.**
- Concrete `(1,3)`/`(2,2)` indefiniteness witnesses: **fully proved.**
- Celestial cross-check: the sphere connectedness dichotomy is **fully proved**; the full
  quotient-topology statement is not formalized.
- Rung 2: **stated as a precise pre-registered probe**, not proved. A clean finite
  quadratic-form theorem was not reachable because the `(1,3)`-vs-`(2,2)` distinction lives
  in the OS lattice/tensor structure, not in the quadratic form alone; hence the probe.
