import Mathlib

/-!
# Extremal null-edge mass configurations as spherical-code theory

This file develops the "§3-layer kinematics" of the null-edge mass program: the mass
of a finite null-edge program is a pairwise energy functional on the Bloch sphere, and
this reduction imports spherical-code / design theory.

The main deliverables are:

* `spinor_lagrange` — the Lagrange (Cauchy–Binet) identity for `ℂ²`, splitting the
  product of spinor norms into a Hermitian overlap part and a holomorphic wedge part.
* `pair_disagreement_eq` — for **unit** spinors the wedge magnitude is `1 - fidelity`,
  the quarter squared chordal distance `sin²(θ/2)` of the celestial directions.
* `bundleMass_eq_energy` — the bundle mass `Σ wᵢ wⱼ |ψᵢ ∧ ψⱼ|²` equals the chordal
  energy functional over the spinors.
* `normSq_sum_eq_gram`, `chordal_energy_eq`, `chordal_energy_le`,
  `chordal_energy_eq_iff_balanced` — the moment identity and first-moment analysis:
  the total mass depends only on the **first moment** `Σ wᵢ n̂ᵢ`, hence is blind to
  higher moments (it cannot distinguish an antipodal pair from a tetrahedron).
* `frame_potential_lower_bound` — the Welch / frame-potential LP bound
  `(Σ‖vᵢ‖²)² ≤ d · Σᵢⱼ ⟨vᵢ,vⱼ⟩²`, the design lower bound in disguise.
* The regular tetrahedron section: it is balanced (`tetra_balanced`), a spherical
  `2`-design (`tetra_two_design`), and a **tight** design attaining the frame-potential
  bound with equality (`tetra_frame_potential`, `tetra_frame_potential_tight`).
-/

open scoped BigOperators
open Complex Finset

namespace NullEdgeMass

/-! ## Spinor layer: the Lagrange identity in `ℂ²` -/

/-- Hermitian overlap of two spinors `⟨ψ, φ⟩ = conj(ψ₀)φ₀ + conj(ψ₁)φ₁`. -/
def sInner (ψ φ : Fin 2 → ℂ) : ℂ :=
  (starRingEnd ℂ) (ψ 0) * φ 0 + (starRingEnd ℂ) (ψ 1) * φ 1

/-- Holomorphic wedge (ε-bracket) of two spinors `ψ ∧ φ = ψ₀φ₁ - ψ₁φ₀`. -/
def sWedge (ψ φ : Fin 2 → ℂ) : ℂ := ψ 0 * φ 1 - ψ 1 * φ 0

/-- Squared norm of a spinor. -/
def sNormSq (ψ : Fin 2 → ℂ) : ℝ := normSq (ψ 0) + normSq (ψ 1)

/-- A spinor is a unit spinor if its squared norm is `1`. -/
def IsUnitSpinor (ψ : Fin 2 → ℂ) : Prop := sNormSq ψ = 1

/-- **Lagrange / Cauchy–Binet identity in `ℂ²`.**  The product of spinor norms splits
into the squared Hermitian overlap plus the squared holomorphic wedge. -/
theorem spinor_lagrange (ψ φ : Fin 2 → ℂ) :
    sNormSq ψ * sNormSq φ = normSq (sInner ψ φ) + normSq (sWedge ψ φ) := by
  simp only [sNormSq, sInner, sWedge, Complex.normSq_apply, Complex.add_re, Complex.add_im,
    Complex.mul_re, Complex.mul_im, Complex.sub_re, Complex.sub_im, Complex.conj_re,
    Complex.conj_im]
  ring

/-- The wedge magnitude is symmetric up to sign, so its squared norm is symmetric. -/
theorem normSq_sWedge_comm (ψ φ : Fin 2 → ℂ) :
    normSq (sWedge ψ φ) = normSq (sWedge φ ψ) := by
  have : sWedge φ ψ = - sWedge ψ φ := by simp only [sWedge]; ring
  rw [this, Complex.normSq_neg]

/-- **Pair disagreement = chordal energy.**  For unit spinors the squared wedge equals
`1 - fidelity`, i.e. `sin²(θ/2)`, a quarter of the squared chordal distance of the
Bloch directions. -/
theorem pair_disagreement_eq {ψ φ : Fin 2 → ℂ} (hψ : IsUnitSpinor ψ) (hφ : IsUnitSpinor φ) :
    normSq (sWedge ψ φ) = 1 - normSq (sInner ψ φ) := by
  have h := spinor_lagrange ψ φ
  rw [IsUnitSpinor] at hψ hφ
  rw [hψ, hφ] at h
  linarith

/-- The pair disagreement lies in `[0,1]` for unit spinors (a quarter squared chordal
distance). -/
theorem pair_disagreement_nonneg (ψ φ : Fin 2 → ℂ) : 0 ≤ normSq (sWedge ψ φ) :=
  Complex.normSq_nonneg _

/-! ## Bundle mass as a pairwise energy functional -/

variable {ι : Type*}

/-- The bundle mass `det P = Σᵢⱼ wᵢ wⱼ |ψᵢ ∧ ψⱼ|²`: the total null-direction
disagreement of a finite null-edge program. -/
def bundleMass (s : Finset ι) (w : ι → ℝ) (ψ : ι → (Fin 2 → ℂ)) : ℝ :=
  ∑ i ∈ s, ∑ j ∈ s, w i * w j * normSq (sWedge (ψ i) (ψ j))

/-- **Bundle mass is the chordal energy of the spinors.**  The mass equals the pairwise
energy built from spinor norms and Hermitian overlaps. -/
theorem bundleMass_eq_energy (s : Finset ι) (w : ι → ℝ) (ψ : ι → (Fin 2 → ℂ)) :
    bundleMass s w ψ =
      ∑ i ∈ s, ∑ j ∈ s,
        w i * w j * (sNormSq (ψ i) * sNormSq (ψ j) - normSq (sInner (ψ i) (ψ j))) := by
  unfold bundleMass
  refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
  have h := spinor_lagrange (ψ i) (ψ j)
  have : normSq (sWedge (ψ i) (ψ j))
      = sNormSq (ψ i) * sNormSq (ψ j) - normSq (sInner (ψ i) (ψ j)) := by linarith
  rw [this]

/-- For a bundle of **unit** spinors the mass is the chordal-distance energy
`Σᵢⱼ wᵢ wⱼ (1 - fidelityᵢⱼ)`. -/
theorem bundleMass_unit_eq_energy (s : Finset ι) (w : ι → ℝ) (ψ : ι → (Fin 2 → ℂ))
    (hψ : ∀ i ∈ s, IsUnitSpinor (ψ i)) :
    bundleMass s w ψ =
      ∑ i ∈ s, ∑ j ∈ s, w i * w j * (1 - normSq (sInner (ψ i) (ψ j))) := by
  unfold bundleMass
  refine Finset.sum_congr rfl (fun i hi => Finset.sum_congr rfl (fun j hj => ?_))
  rw [pair_disagreement_eq (hψ i hi) (hψ j hj)]

/-! ## Moment layer: mass is controlled by the first moment -/

section Moments

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- **Gram / moment identity.**  The squared norm of a weighted sum equals the double
sum of weighted inner products (the second moment written via the Gram matrix). -/
theorem normSq_sum_eq_gram (s : Finset ι) (w : ι → ℝ) (v : ι → E) :
    ‖∑ i ∈ s, w i • v i‖ ^ 2 = ∑ i ∈ s, ∑ j ∈ s, (w i * w j) * (inner ℝ (v i) (v j)) := by
  rw [← real_inner_self_eq_norm_sq, sum_inner]
  simp_rw [inner_sum, real_inner_smul_left, real_inner_smul_right]
  refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
  ring

/-- **First-moment reduction of the chordal energy.**  For any weights and directions
the chordal energy `Σᵢⱼ wᵢ wⱼ (1 - ⟨nᵢ,nⱼ⟩)` equals `(Σ wᵢ)² - ‖Σ wᵢ nᵢ‖²`: it depends
on the directions **only through the first moment** `Σ wᵢ nᵢ`. -/
theorem chordal_energy_eq (s : Finset ι) (w : ι → ℝ) (n : ι → E) :
    ∑ i ∈ s, ∑ j ∈ s, w i * w j * (1 - inner ℝ (n i) (n j))
      = (∑ i ∈ s, w i) ^ 2 - ‖∑ i ∈ s, w i • n i‖ ^ 2 := by
  have hgram := normSq_sum_eq_gram s w n
  have hconst : (∑ i ∈ s, w i) ^ 2 = ∑ i ∈ s, ∑ j ∈ s, w i * w j := by
    rw [sq, Finset.sum_mul_sum]
  rw [hconst, hgram, ← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  rw [← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl (fun j _ => ?_)
  ring

/-- **First-moment upper bound.**  The chordal energy never exceeds `(Σ wᵢ)²`. -/
theorem chordal_energy_le (s : Finset ι) (w : ι → ℝ) (n : ι → E) :
    ∑ i ∈ s, ∑ j ∈ s, w i * w j * (1 - inner ℝ (n i) (n j)) ≤ (∑ i ∈ s, w i) ^ 2 := by
  rw [chordal_energy_eq]
  have : (0 : ℝ) ≤ ‖∑ i ∈ s, w i • n i‖ ^ 2 := sq_nonneg _
  linarith

/-- **Extremality ⇔ balance.**  The chordal energy attains its bound `(Σ wᵢ)²` exactly
when the configuration is balanced, `Σ wᵢ n̂ᵢ = 0` (the "rest frame" condition). -/
theorem chordal_energy_eq_iff_balanced (s : Finset ι) (w : ι → ℝ) (n : ι → E) :
    (∑ i ∈ s, ∑ j ∈ s, w i * w j * (1 - inner ℝ (n i) (n j))) = (∑ i ∈ s, w i) ^ 2
      ↔ ∑ i ∈ s, w i • n i = 0 := by
  rw [chordal_energy_eq]
  constructor
  · intro h
    have hz : ‖∑ i ∈ s, w i • n i‖ ^ 2 = 0 := by linarith
    have : ‖∑ i ∈ s, w i • n i‖ = 0 := by
      have := sq_eq_zero_iff.mp hz; exact this
    exact norm_eq_zero.mp this
  · intro h
    rw [h]; simp

/-- **First-moment triviality (kill of `det P`'s distinguishing power).**  Two
configurations with equal total weight and equal first moment have *equal* chordal mass,
even if they are geometrically non-isomorphic (e.g. an antipodal pair vs. a tetrahedron).
The total mass sees only the first moment. -/
theorem chordal_energy_first_moment_blind
    (s : Finset ι) (w : ι → ℝ) (n : ι → E)
    (t : Finset ι) (u : ι → ℝ) (m : ι → E)
    (hw : ∑ i ∈ s, w i = ∑ i ∈ t, u i)
    (hmom : ∑ i ∈ s, w i • n i = ∑ i ∈ t, u i • m i) :
    (∑ i ∈ s, ∑ j ∈ s, w i * w j * (1 - inner ℝ (n i) (n j)))
      = ∑ i ∈ t, ∑ j ∈ t, u i * u j * (1 - inner ℝ (m i) (m j)) := by
  rw [chordal_energy_eq, chordal_energy_eq, hw, hmom]

end Moments

/-! ## Frame potential: the design lower bound (Welch bound) -/

section FramePotential

variable {d : ℕ}

/-- Euclidean dot product on `Fin d → ℝ`. -/
def dotD (u v : Fin d → ℝ) : ℝ := ∑ a, u a * v a

/-
**Frame-potential / Welch lower bound.**  For any finite family of vectors in `ℝ^d`,
`(Σᵢ ‖vᵢ‖²)² ≤ d · Σᵢⱼ ⟨vᵢ,vⱼ⟩²`.  Equality characterises tight designs.  This is the
LP bound that spherical-code theory contributes to the mass budget.
-/
theorem frame_potential_lower_bound (s : Finset ι) (v : ι → (Fin d → ℝ)) :
    (∑ i ∈ s, dotD (v i) (v i)) ^ 2
      ≤ (d : ℝ) * ∑ i ∈ s, ∑ j ∈ s, (dotD (v i) (v j)) ^ 2 := by
  -- `M a b = Σᵢ vᵢₐ vᵢᵦ`, the (unnormalised) covariance matrix.
  set M : Fin d → Fin d → ℝ := fun a b => ∑ i ∈ s, v i a * v i b with hM
  -- Trace of `M` equals `Σᵢ ‖vᵢ‖²`.
  have htr : ∑ i ∈ s, dotD (v i) (v i) = ∑ a, M a a := by
    simp only [dotD, hM]; rw [Finset.sum_comm]
  -- Reorder four nested sums (indices vs. coordinates).
  have hreorder : ∀ (F : ι → ι → Fin d → Fin d → ℝ),
      (∑ i ∈ s, ∑ j ∈ s, ∑ a, ∑ b, F i j a b)
        = ∑ a, ∑ b, ∑ i ∈ s, ∑ j ∈ s, F i j a b := by
    intro F
    simp_rw [← Finset.sum_product']
    exact Finset.sum_nbij' (fun p => (p.2.2.1, p.2.2.2, p.1, p.2.1))
      (fun q => (q.2.2.1, q.2.2.2, q.1, q.2.1)) (by simp) (by simp)
      (by rintro ⟨i, j, a, b⟩ _; rfl) (by rintro ⟨a, b, i, j⟩ _; rfl)
      (by rintro ⟨i, j, a, b⟩ _; rfl)
  -- Frobenius norm² of `M` equals the frame potential.
  have hfp : (∑ i ∈ s, ∑ j ∈ s, (dotD (v i) (v j)) ^ 2) = ∑ a, ∑ b, (M a b) ^ 2 := by
    have keyL : ∀ i j, (dotD (v i) (v j)) ^ 2
        = ∑ a, ∑ b, (v i a * v i b) * (v j a * v j b) := by
      intro i j; simp only [dotD, sq]; rw [Finset.sum_mul_sum]
      exact Finset.sum_congr rfl (fun a _ => Finset.sum_congr rfl (fun b _ => by ring))
    simp_rw [keyL]
    rw [hreorder (fun i j a b => (v i a * v i b) * (v j a * v j b))]
    refine Finset.sum_congr rfl (fun a _ => Finset.sum_congr rfl (fun b _ => ?_))
    simp only [hM, sq]; rw [Finset.sum_mul_sum]
  rw [htr, hfp]
  -- Cauchy–Schwarz on the diagonal, then drop the off-diagonal nonneg terms.
  have hcs : (∑ a, M a a) ^ 2 ≤ (d : ℝ) * ∑ a, (M a a) ^ 2 := by
    have h := sum_mul_sq_le_sq_mul_sq (univ : Finset (Fin d)) (fun _ => (1 : ℝ)) (fun a => M a a)
    simpa using h
  have hdrop : ∑ a, (M a a) ^ 2 ≤ ∑ a, ∑ b, (M a b) ^ 2 :=
    Finset.sum_le_sum (fun a _ =>
      Finset.single_le_sum (f := fun b => (M a b) ^ 2) (fun b _ => sq_nonneg _)
        (Finset.mem_univ a))
  exact hcs.trans (mul_le_mul_of_nonneg_left hdrop (Nat.cast_nonneg d))
end FramePotential

/-! ## The regular tetrahedron: a tight spherical 2-design -/

section Tetrahedron

/-- The four (unnormalised) vertices of a regular tetrahedron inscribed in the cube. -/
def tetra : Fin 4 → (Fin 3 → ℝ)
  | 0 => ![ 1,  1,  1]
  | 1 => ![ 1, -1, -1]
  | 2 => ![-1,  1, -1]
  | 3 => ![-1, -1,  1]

/-- Each tetrahedron vertex has squared norm `3`. -/
theorem tetra_normSq (i : Fin 4) : dotD (tetra i) (tetra i) = 3 := by
  fin_cases i <;>
    · simp only [tetra, dotD, Fin.sum_univ_three, Matrix.cons_val]; norm_num

/-- Distinct tetrahedron vertices have inner product `-1` (the regular tetrahedron
angle, `cos θ = -1/3` after normalisation). -/
theorem tetra_inner {i j : Fin 4} (h : i ≠ j) : dotD (tetra i) (tetra j) = -1 := by
  fin_cases i <;> fin_cases j <;>
    first
      | (exact absurd rfl h)
      | · simp only [tetra, dotD, Fin.sum_univ_three, Matrix.cons_val]; norm_num

/-- **The tetrahedron is balanced** (`1`-design / rest frame): its vertices sum to `0`. -/
theorem tetra_balanced : ∑ i, tetra i = 0 := by
  funext a
  fin_cases a <;> · simp only [Fin.sum_univ_four, tetra]; norm_num

/-- **The tetrahedron is a spherical `2`-design.**  For every `x`, `Σᵢ ⟨tᵢ, x⟩² =
4 ‖x‖²` (equivalently `(4/3)‖x‖²` for the normalised vertices, matching `N/d = 4/3`). -/
theorem tetra_two_design (x : Fin 3 → ℝ) :
    ∑ i, (dotD (tetra i) x) ^ 2 = 4 * dotD x x := by
  simp only [Fin.sum_univ_four, tetra, dotD, Fin.sum_univ_three, Matrix.cons_val]
  ring

/-- The tetrahedron frame potential is `48`. -/
theorem tetra_frame_potential :
    ∑ i, ∑ j, (dotD (tetra i) (tetra j)) ^ 2 = 48 := by
  simp only [Fin.sum_univ_four, tetra, dotD, Fin.sum_univ_three, Matrix.cons_val]
  norm_num

/-- The sum of squared norms of the tetrahedron vertices is `12`. -/
theorem tetra_trace : ∑ i, dotD (tetra i) (tetra i) = 12 := by
  simp only [Fin.sum_univ_four]
  rw [tetra_normSq 0, tetra_normSq 1, tetra_normSq 2, tetra_normSq 3]; norm_num

/-- **The tetrahedron is a tight design.**  It attains the frame-potential lower bound
with equality: `(Σ‖tᵢ‖²)² = 3 · Σᵢⱼ ⟨tᵢ,tⱼ⟩² = 144`.  Hence it is mass-extremal among
`4`-direction bundles in the frame-potential (LP) sense. -/
theorem tetra_frame_potential_tight :
    (∑ i, dotD (tetra i) (tetra i)) ^ 2
      = (3 : ℝ) * ∑ i, ∑ j, (dotD (tetra i) (tetra j)) ^ 2 := by
  rw [tetra_trace, tetra_frame_potential]; norm_num

end Tetrahedron

/-! ## Axiom-footprint guard

Each main result depends only on the permitted kernel axioms
`[propext, Classical.choice, Quot.sound]` (no `sorry`/`admit`/`native_decide`/new
`axiom`). -/

#print axioms spinor_lagrange
#print axioms pair_disagreement_eq
#print axioms bundleMass_eq_energy
#print axioms bundleMass_unit_eq_energy
#print axioms normSq_sum_eq_gram
#print axioms chordal_energy_eq
#print axioms chordal_energy_le
#print axioms chordal_energy_eq_iff_balanced
#print axioms chordal_energy_first_moment_blind
#print axioms frame_potential_lower_bound
#print axioms tetra_balanced
#print axioms tetra_two_design
#print axioms tetra_frame_potential_tight

end NullEdgeMass
