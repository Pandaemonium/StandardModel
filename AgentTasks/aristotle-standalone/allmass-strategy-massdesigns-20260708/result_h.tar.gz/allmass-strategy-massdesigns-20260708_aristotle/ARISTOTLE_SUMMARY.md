# Summary of changes for run 94e0f241-09d6-4e9d-b6f1-91939a5ca9da
Formalized the "extremal mass configurations = spherical-code theory" program (from STRATEGY_PROMPT.md) in a new file `RequestProject/NullEdgeMass.lean`. The file builds cleanly, contains no `sorry`/`admit`/`native_decide`/new `axiom`, and every main theorem is guarded by an in-file `#print axioms` reporting exactly `[propext, Classical.choice, Quot.sound]`.

Proved (kernel-checked):

1. Chordal-energy identity (target 1):
   - `spinor_lagrange`: the Lagrange/Cauchy–Binet identity in ℂ², `‖ψ‖²‖φ‖² = |⟨ψ,φ⟩|² + |ψ∧φ|²` (holding simultaneously for the Hermitian overlap and the holomorphic wedge).
   - `pair_disagreement_eq`: for unit spinors `|ψ∧φ|² = 1 − fidelity = sin²(θ/2)` = quarter squared chordal distance.
   - `bundleMass_eq_energy` / `bundleMass_unit_eq_energy`: bundle mass `det P = Σ wᵢwⱼ|ψᵢ∧ψⱼ|²` equals the chordal pair-energy of the celestial directions.

2. First-moment analysis (target 2):
   - `normSq_sum_eq_gram`: Gram/moment identity `‖Σ wᵢvᵢ‖² = Σ wᵢwⱼ⟨vᵢ,vⱼ⟩`.
   - `chordal_energy_eq`: chordal energy `= (Σwᵢ)² − ‖Σ wᵢnᵢ‖²`, depending only on the first moment.
   - `chordal_energy_le`, `chordal_energy_eq_iff_balanced`: mass ≤ (Σwᵢ)², with equality iff balanced (`Σ wᵢnᵢ = 0`).
   - `chordal_energy_first_moment_blind`: the concrete kill of `det P`'s distinguishing power — configurations with equal weight and first moment have equal total mass even when non-isomorphic (antipodal pair vs. tetrahedron).

3. Design lower bound and tight-design instance (target 3):
   - `frame_potential_lower_bound`: the Welch/frame-potential LP bound `(Σ‖vᵢ‖²)² ≤ d·Σ⟨vᵢ,vⱼ⟩²`.
   - Regular tetrahedron: `tetra_balanced` (1-design), `tetra_two_design` (spherical 2-design: Σ⟨tᵢ,x⟩² = 4‖x‖²), and `tetra_frame_potential_tight` showing it attains the frame-potential bound with equality (144 = 3·48) — a tight, mass-extremal 4-direction design.

Honest status (recorded in `ARISTOTLE_SUMMARY.md`): the general design hierarchy ("spectra maximally uniform ⇔ t-designs"), Cohn–Kumar universal optimality, general k-th moment determination, and the Conjecture I kill via two non-isomorphic 2-designs are stated but not formalized (research-level / absent from Mathlib); the concrete t=2 extremal instance, the general LP bound, and the stronger first-moment blindness of `det P` are fully proved.

# Extremal null-edge mass configurations as spherical-code theory

All results live in `RequestProject/NullEdgeMass.lean`. The file builds cleanly against
the pinned Mathlib, contains **no** `sorry`/`admit`/`native_decide`/new `axiom`, and each
main theorem is guarded by an in-file `#print axioms`, all reporting exactly the permitted
footprint `[propext, Classical.choice, Quot.sound]`.

## What landed (proved, kernel-checked)

### 1. Chordal-energy identity (Strategy target 1)

* `spinor_lagrange` — the Lagrange / Cauchy–Binet identity in `ℂ²`:
  `‖ψ‖²‖φ‖² = |⟨ψ,φ⟩|² + |ψ ∧ φ|²`, splitting the product of spinor norms into the
  Hermitian overlap `sInner ψ φ = conj(ψ₀)φ₀ + conj(ψ₁)φ₁` and the holomorphic wedge
  `sWedge ψ φ = ψ₀φ₁ − ψ₁φ₀`.  (Verified: the identity holds with the *holomorphic*
  wedge and *Hermitian* inner product simultaneously.)
* `pair_disagreement_eq` — for **unit** spinors, `|ψ ∧ φ|² = 1 − |⟨ψ,φ⟩|²`, i.e.
  `sin²(θ/2)`, a quarter of the squared chordal distance of the Bloch directions.
* `bundleMass_eq_energy` / `bundleMass_unit_eq_energy` — the bundle mass
  `det P = Σᵢⱼ wᵢwⱼ |ψᵢ ∧ ψⱼ|²` equals the chordal pair-energy of the spinors
  (`Σᵢⱼ wᵢwⱼ (1 − fidelityᵢⱼ)` in the unit-spinor case).  This realises "bundle mass =
  pairwise energy functional on `S²`".

### 2. First-moment analysis (Strategy target 2)

* `normSq_sum_eq_gram` — the Gram / moment identity
  `‖Σ wᵢ vᵢ‖² = Σᵢⱼ wᵢwⱼ ⟨vᵢ,vⱼ⟩` in any real inner-product space.
* `chordal_energy_eq` — the chordal energy `Σᵢⱼ wᵢwⱼ(1 − ⟨nᵢ,nⱼ⟩)` equals
  `(Σ wᵢ)² − ‖Σ wᵢ nᵢ‖²`: it depends on the directions **only through the first moment**
  `Σ wᵢ nᵢ`.
* `chordal_energy_le` — the mass never exceeds `(Σ wᵢ)²`.
* `chordal_energy_eq_iff_balanced` — the bound is attained **iff** the configuration is
  balanced, `Σ wᵢ nᵢ = 0` (the rest-frame condition).
* `chordal_energy_first_moment_blind` — the concrete **kill of `det P`'s distinguishing
  power**: any two configurations with equal total weight and equal first moment have
  *equal* total mass, even when geometrically non-isomorphic (e.g. a balanced antipodal
  pair vs. a tetrahedron).  So `det P` alone cannot separate them; higher moments are
  needed.

### 3. Design lower bound and a tight-design instance (Strategy target 3)

* `frame_potential_lower_bound` — the Welch / frame-potential LP bound in `ℝᵈ`:
  `(Σᵢ ‖vᵢ‖²)² ≤ d · Σᵢⱼ ⟨vᵢ,vⱼ⟩²`.  This is the design lower bound that spherical-code
  theory contributes to the mass budget (proved by rewriting the frame potential as the
  Frobenius norm² of the covariance matrix `M`, Cauchy–Schwarz on its diagonal, and
  dropping off-diagonal nonnegative terms).
* Regular tetrahedron section (`tetra`):
  * `tetra_normSq`, `tetra_inner` — vertices have squared norm `3`, pairwise inner
    product `−1` (the `cos θ = −1/3` regular-tetrahedron angle).
  * `tetra_balanced` — the vertices sum to `0` (a `1`-design / rest frame).
  * `tetra_two_design` — `Σᵢ ⟨tᵢ, x⟩² = 4‖x‖²` for all `x`, i.e. the tetrahedron is a
    spherical **`2`-design** (`(4/3)‖x‖²` after normalisation, matching `N/d = 4/3`).
  * `tetra_frame_potential`, `tetra_trace`, `tetra_frame_potential_tight` — the
    tetrahedron **attains the frame-potential bound with equality**
    (`(Σ‖tᵢ‖²)² = 3·Σᵢⱼ⟨tᵢ,tⱼ⟩² = 144`), so it is a *tight* design and mass-extremal
    among `4`-direction bundles in the frame-potential (LP) sense.

## What is stated in the program but not formalised here (honest status)

* **General design hierarchy.**  The full claim "sub-bundle mass spectra are maximally
  uniform *exactly* on spherical `t`-designs" is not formalised in generality.  What is
  proved is the concrete instance for `t = 2` (the tetrahedron attains the `2`-design /
  frame-potential extremum) together with the general LP lower bound
  (`frame_potential_lower_bound`) that any such extremality must respect.
* **Cohn–Kumar universal optimality.**  Complete monotonicity of `sin²(θ/2)` in chordal
  distance² is the input to Cohn–Kumar universal optimality; that theorem is not present
  in Mathlib and is not reproved here.  Only its LP-bound shadow (the frame-potential
  bound) is established.
* **`k`-th moment determination.**  The second-moment link is made precise
  (`normSq_sum_eq_gram`, `frame_potential_lower_bound`); the general statement that
  `k`-sub-bundle masses determine the `k`-th direction moments is not formalised.
* **Conjecture I kill (two non-isomorphic `2`-designs with distinguishable pair-mass
  multisets).**  Not formalised.  The related and arguably sharper phenomenon — that the
  *total* mass `det P` is blind to everything beyond the first moment — is proved as
  `chordal_energy_first_moment_blind`, which already exhibits distinct configurations
  (antipodal pair vs. tetrahedron) with identical total mass but different pair-mass
  multisets.

## Verification

`lake build RequestProject.NullEdgeMass` succeeds. The trailing `#print axioms` block in
the file reports `[propext, Classical.choice, Quot.sound]` for every delivered theorem.
