# Summary of changes for run f04dbc54-5460-4277-a11f-7dc9682dfdb5
Delivered a self-contained, kernel-checked finite-geometric theory of the soldering/gravity E-slot (F7) in `RequestProject/Soldering.lean`, with `ARISTOTLE_SUMMARY.md` documenting the results and honest boundary. The file builds cleanly (no warnings), and an in-file `#print axioms` block confirms every theorem's footprint is a subset of `[propext, Classical.choice, Quot.sound]` — no `sorry`, `native_decide`, `@[implemented_by]`, or new `axiom`.

Model. An abstract unital *-ring `R` is the carrier's operator algebra; a `KreinForm` bundles a self-adjoint invertible metric `η` and its inverse, giving the Krein adjoint `kadj a = ηi·(star a)·η` (the finite `∇^#`). The E-slot is `Eslot φ D = φ·(kadj D − D) = φ(∇^#−∇)`. `kadj` is proved an involutive anti-homomorphism. All results specialise to `Matrix (Fin n) (Fin n) ℚ` (η=1), used for concrete witnesses.

What was proved:
1. Transformation law. `kadj_conj`: under a finite frame change `∇ ↦ Ui∇U`, the Krein adjoint conjugates by `U^# = kadj U`, not by `U`. `Eslot_tensorial`: on the Krein-unitary (metric-preserving) subgroup (`kadj U = Ui`), with `φ ↦ Ui φ U`, the E-slot transforms tensorially by conjugation `Ui·E_#·U` — a genuine geometric object, not an inhomogeneous connection. `Eslot_not_tensorial_witness`: an explicit invertible, non-Krein-unitary 2×2 matrix for which tensoriality genuinely fails. Verdict: tensorial exactly on the metric-preserving gauge group, inhomogeneous outside it.
2. Contorsion vs nonmetricity. Splitting along the Krein involution, `kadj_tor` shows the torsion piece `tor a = a − kadj a` is metric-compatible (kadj-anti-self-adjoint) = contorsion, and `kadj_nm` shows `nm a = a + kadj a` is metric-violating (kadj-self-adjoint) = nonmetricity, with `tor_add_nm`. `pure_torsion_dead_witness`: an explicit E_# with nonzero nonmetricity part, so the channel is not pure teleparallel torsion. Structural finding: a central self-adjoint (scalar) turn field makes E_# pure contorsion; nonmetricity is created precisely by a non-commuting/non-symmetric turn field.
3. No double-counting. The closure Q_C (non-normality commutator `D·kadj D − kadj D·D`) is kadj-self-adjoint (even grade, `kadj_Qc`) while `tor E_#` is kadj-anti-self-adjoint (odd grade). `kadj_decomp_unique` gives a unique even/odd grade decomposition with explicit projections; `no_double_count`/`Qc_tor_no_double_count` show an even (gauge) and odd (geometric) quantity summing to zero force both to vanish — complementary grade sectors, so gauge-mass and geometric torsion-mass are distinct summands with no curvature double-counting.

Honest boundary (in the summary): the proved no-double-counting separates the torsion part of E_# from Q_C; the nonmetricity part shares Q_C's grade, so fully separating it needs a finer ℤ/2×ℤ/2 grade/parity refinement. The contorsion/nonmetricity names are justified by finite structure (metric-compatible skew vs metric-violating symmetric under η); identification with continuum tensors needs a refinement limit that is left conjectural.

# F7 — A discrete-geometric transformation law for the soldering (gravity) E-slot

All results below are in `RequestProject/Soldering.lean`. Every theorem is
kernel-checked with axiom footprint a subset of
`[propext, Classical.choice, Quot.sound]` (verified by the `#print axioms` block
at the bottom of the file). No `sorry`, `native_decide`, `@[implemented_by]`, or
new `axiom` is used.

## The model

The finite operator algebra of the carrier is an abstract unital `*`-ring `R`
(`Ring R`, `StarRing R`). A **Krein form** (`KreinForm`) packages a self-adjoint
invertible fundamental symmetry `η` (the metric) with its inverse `ηi`. The
**Krein adjoint** is

```
kadj a = ηi * (star a) * η          -- the finite analogue of ∇^#
```

and the soldering / gravity **E-slot** is

```
Eslot φ D = φ * (kadj D − D)         -- E_# = φ (∇^# − ∇)
```

`kadj` is proved to be an involutive anti-homomorphism (`kadj_involutive`,
`kadj_mul`, `kadj_add`, `kadj_one`, ...). Everything specialises to matrices:
`matKrein n` is the Euclidean Krein form on `Matrix (Fin n) (Fin n) ℚ` (`η = 1`,
so `kadj = star = transpose`), used for the concrete witnesses.

**Self-adjoint gauge class.** `Eslot_eq_zero_of_selfadj` : `kadj D = D ⇒ E_# = 0`;
and `selfadj_of_Eslot_eq_zero` : if the turn field is left-invertible then
`E_# = 0 ⇒ kadj D = D`. So `E_#` vanishes exactly on `∇^# = ∇`.

## 1. The transformation law (proved)

Under a finite frame / connection change `∇ ↦ Ui ∇ U` (with `U` a unit, `Ui` its
inverse):

* **General law — `kadj_conj`:**
  ```
  kadj (Ui * D * U) = kadj U * kadj D * kadj Ui
  ```
  i.e. `(∇')^# = U^# · ∇^# · (U^#)⁻¹`. The Krein adjoint is conjugated by
  `U^# = kadj U`, **not** by `U` itself (`kadj_unit_inv` shows
  `kadj Ui * kadj U = 1`). The gap between `U` and `U^#` is exactly the failure of
  `U` to be metric-preserving.

* **Tensorial law — `Eslot_tensorial`:** on the **Krein-unitary subgroup**
  (`kadj U = Ui`, i.e. `U^# = U⁻¹`, i.e. `U` preserves the metric), with the turn
  field carried along `φ ↦ Ui φ U`,
  ```
  Eslot (Ui φ U) (Ui D U) = Ui · (Eslot φ D) · U .
  ```
  The E-slot transforms **tensorially** — by the adjoint (conjugation) action —
  so it is a genuine geometric object, not an inhomogeneously-transforming
  connection. (The individual connection `∇` and adjoint `∇^#` do transform, but
  their metric defect transforms covariantly.)

* **Verdict, tensorial vs inhomogeneous — `Eslot_not_tensorial_witness`:** off the
  Krein-unitary subgroup tensoriality genuinely **fails**. Explicit `2×2` rational
  witness: `U = [[1,1],[0,1]]` is invertible (`Uwit_inv`) but not Krein-unitary
  (`Uwit_not_krein`), and for it
  `Eslot (Ui φ U)(Ui D U) ≠ Ui (Eslot φ D) U`.

  **So `E_#` is tensorial precisely on the metric-preserving gauge group and
  inhomogeneous outside it**; the obstruction is measured by the non-unitarity
  `U^# U ≠ 1` (the adjoint conjugates by `U^#` instead of `U`).

## 2. Contorsion vs nonmetricity (proved)

Split any operator along the Krein involution:
```
tor a = a − kadj a      (kadj-anti-self-adjoint)  -- contorsion  / torsion piece
nm  a = a + kadj a      (kadj-self-adjoint)       -- nonmetricity piece
tor_add_nm :  nm a + tor a = a + a
```

* **`kadj_tor` :** `kadj (tor a) = − tor a`. The torsion piece is
  `kadj`-anti-self-adjoint, i.e. **metric-compatible** (`η·tor` is skew): this is
  the finite **contorsion**.
* **`kadj_nm` :** `kadj (nm a) = nm a`. The nonmetricity piece is
  `kadj`-self-adjoint, i.e. the **metric-violating** (`∇g ≠ 0`) defect: finite
  **nonmetricity**.

Applied to the E-slot (`kadj_tor_Eslot`), the contorsion piece of `E_#` is
`tor (Eslot φ D)`.

* **Pure-torsion is dead — `pure_torsion_dead_witness`:** there is an explicit
  `E_#` (turn field `φ = [[1,2],[0,1]]`, connection `D = [[0,1],[0,0]]`) with
  `nm (Eslot φ D) ≠ 0`. Both `tor (Eslot φ D) ≠ 0` and `Qc D ≠ 0` for it as well
  (`tor_witness_ne_zero`, `Qc_witness_ne_zero`).

  **Structural finding:** if the turn field `φ` is central and
  `kadj`-self-adjoint (a plain scalar), then `E_# = φ(∇^# − ∇)` is itself purely
  `kadj`-anti-self-adjoint (`E_#^# = −E_#`) — pure contorsion. The nonmetricity
  content of `E_#` is created **exactly** by the non-commuting / non-symmetric turn
  field. That is precisely why "pure torsion" is dead: a generic turn field forces
  genuine nonmetricity.

## 3. No double-counting with the closure `Q_C` (proved)

The gauge closure / curvature is modelled as the non-normality commutator
`Qc D = D · kadj D − kadj D · D`.

* **`kadj_Qc` :** `kadj (Qc D) = Qc D` — the closure is `kadj`-self-adjoint, i.e.
  lives in the **even grade** sector.
* **`kadj_tor_Eslot` :** the torsion part of `E_#` is `kadj`-anti-self-adjoint,
  i.e. lives in the **odd grade** sector.
* **`kadj_decomp_unique` :** (over any ring with `Invertible (2)`) every operator
  splits **uniquely** into an even (`kadj`-self-adjoint) and an odd
  (`kadj`-anti-self-adjoint) part, each recovered from the total by the projection
  `⅟2 (s ± kadj s)`.
* **`no_double_count` / `Qc_tor_no_double_count` :** an even (gauge/closure)
  quantity and an odd (geometric/torsion) quantity that sum to zero must both
  vanish. The two sectors are complementary, so summing them loses no information
  and identifies nothing: **gauge-mass (`Q_C`) and geometric torsion-mass
  (`tor E_#`) are genuinely distinct summands of the mass budget** — different
  grade/parity pieces of the square, no double-counting of curvature.

## Honest conjectural boundary

* **Nonmetricity vs curvature grade collision.** The clean, proved
  no-double-counting separates the *torsion* part of `E_#` (odd grade) from `Q_C`
  (even grade). The *nonmetricity* part `nm (E_#)` is itself `kadj`-self-adjoint,
  hence the **same grade** as `Q_C`. Separating `nm (E_#)` from the closure
  curvature is **not** achieved by the single Krein involution used here; it needs
  a finer grading (a second commuting parity distinguishing the `φ`-built
  nonmetricity from the `∇`-built curvature, i.e. the full ℤ/2×ℤ/2 grade/parity of
  the four-channel square). This is left conjectural.

* **Continuum identification.** The names "contorsion" and "nonmetricity" are
  justified here by the *finite* structural properties (metric-compatible skew vs
  metric-violating symmetric under the fundamental symmetry `η`). Matching these
  finite pieces to the continuum contorsion / nonmetricity tensors requires a
  refinement (continuum) limit, which is not formalised.

* **Model of `Q_C`.** `Q_C` is taken as the non-normality commutator of a single
  transport; a fully independent finite gauge curvature would further strengthen
  the independence statement. The current theorems already establish grade/parity
  complementarity, which is the load-bearing "no double-counting" claim.

## What lands

Kernel-checked theorems for: the finite transformation law (general +
tensorial), the tensorial-vs-inhomogeneous verdict with an explicit failing
witness, the contorsion (`kadj_tor`) / nonmetricity (`kadj_nm`) classification,
the death of pure-torsion (explicit witness), and no-double-counting of the
torsion E-slot against the closure `Q_C` via unique grade decomposition.
