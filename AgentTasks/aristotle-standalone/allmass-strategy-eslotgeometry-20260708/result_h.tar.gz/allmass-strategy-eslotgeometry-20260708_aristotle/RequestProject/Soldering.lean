import Mathlib

/-!
# The soldering / gravity E-slot: a discrete-geometric transformation law (F7)

This file gives the fourth ("soldering", gravity-shaped) channel

  `E_# = φ · (∇^# − ∇)`

of the finite null-edge carrier a genuine discrete-geometric transformation law.

## Model

We work in an abstract unital `*`-ring `R` (`Ring R`, `StarRing R`), which is the
finite operator algebra of a Krein carrier.  A *Krein form* packages a fundamental
symmetry `η` (self-adjoint invertible metric) together with its inverse.  The
**Krein adjoint** of an operator `a` is

  `kadj a = η⁻¹ · (star a) · η`,

the analogue of the metric-adjoint `∇^#`.  All statements specialise to matrices
`Matrix (Fin n) (Fin n) 𝕜` (take `η = 1` for the Euclidean/`star`-adjoint case),
and the concrete witnesses below live in `Matrix (Fin 2) (Fin 2) ℚ`.

## Results

* `kadj` is an involutive anti-homomorphism (`kadj_involutive`, `kadj_mul`, ...).
* **Self-adjoint gauge class** — `Eslot_eq_zero_of_selfadj` and
  `selfadj_of_Eslot_eq_zero`: `E_# = 0` exactly on `∇^# = ∇`.
* **General transformation law** — `kadj_conj`: under a finite frame change
  `∇ ↦ U⁻¹ ∇ U`, the Krein adjoint is conjugated by `kadj U` rather than by `U`.
* **Tensorial law** — `Eslot_tensorial`: on the Krein-unitary subgroup
  (`kadj U = U⁻¹`) the E-slot transforms *tensorially* (by conjugation), i.e. as a
  genuine geometric object (contorsion / nonmetricity), not inhomogeneously like a
  connection.
* **Inhomogeneity witness** — `Eslot_not_tensorial_witness`: off the Krein-unitary
  subgroup tensoriality genuinely fails.
* **Torsion / nonmetricity split** — `kadj_tor` (contorsion: metric-compatible,
  `kadj`-anti-self-adjoint) vs `kadj_nm` (nonmetricity: metric-violating,
  `kadj`-self-adjoint), with `tor_add_nm`.
* **Pure-torsion is dead** — `pure_torsion_dead_witness`: an explicit `E_#` with
  non-vanishing nonmetricity part.
* **No double-counting with the closure `Q_C`** — `Qc` (gauge closure/curvature) is
  `kadj`-self-adjoint (even grade), while the torsion part of `E_#` is
  `kadj`-anti-self-adjoint (odd grade); `kadj_decomp_unique` /
  `no_double_count` show these occupy complementary grade sectors, so geometric
  mass and gauge mass are distinct summands of the mass budget.
-/

namespace Soldering

variable {R : Type*} [Ring R] [StarRing R]

/-- A finite Krein form: a self-adjoint invertible fundamental symmetry `η`. -/
structure KreinForm (R : Type*) [Ring R] [StarRing R] where
  η : R
  ηi : R
  left_inv : ηi * η = 1
  right_inv : η * ηi = 1
  eta_selfadj : star η = η

namespace KreinForm

variable (K : KreinForm R)

/-- The Krein adjoint `∇^# = η⁻¹ (star ∇) η`. -/
def kadj (a : R) : R := K.ηi * star a * K.η

/--
The inverse metric is also self-adjoint.
-/
theorem etai_selfadj : star K.ηi = K.ηi := by
  have h_star_ηi : star K.ηi = K.ηi := by
    have h_inv : K.ηi * K.η = 1 := by
      exact K.left_inv
    have h_inv' : K.η * K.ηi = 1 := by
      exact K.right_inv
    have h_star_η : star K.η = K.η := by
      exact K.eta_selfadj
    have h_star_ηi : star K.ηi * K.η = 1 := by
      simpa [ h_star_η ] using congr_arg Star.star h_inv';
    apply_fun ( · * K.ηi ) at h_star_ηi h_inv; simp_all +decide [ mul_assoc ] ;
  exact h_star_ηi

@[simp] theorem kadj_add (a b : R) : K.kadj (a + b) = K.kadj a + K.kadj b := by
  unfold KreinForm.kadj; simp +decide [ mul_add, add_mul ] ;

@[simp] theorem kadj_zero : K.kadj 0 = 0 := by
  simp +decide [ KreinForm.kadj ]

@[simp] theorem kadj_neg (a : R) : K.kadj (-a) = - K.kadj a := by
  unfold KreinForm.kadj; simp [mul_assoc]

@[simp] theorem kadj_sub (a b : R) : K.kadj (a - b) = K.kadj a - K.kadj b := by
  unfold KreinForm.kadj; simp +decide [ sub_mul, mul_sub ] ;

@[simp] theorem kadj_one : K.kadj 1 = 1 := by
  simp +decide [ KreinForm.kadj, KreinForm.left_inv ]

/--
`kadj` is an anti-homomorphism of the operator algebra.
-/
theorem kadj_mul (a b : R) : K.kadj (a * b) = K.kadj b * K.kadj a := by
  unfold KreinForm.kadj; simp [mul_assoc]
  simp [← mul_assoc, K.right_inv]

/--
`kadj` is an involution.
-/
@[simp] theorem kadj_involutive (a : R) : K.kadj (K.kadj a) = a := by
  simp [KreinForm.kadj, mul_assoc, K.eta_selfadj, K.etai_selfadj]
  simp [← mul_assoc, K.left_inv]

/-- The soldering / gravity E-slot `E_# = φ (∇^# − ∇)`. -/
def Eslot (φ D : R) : R := φ * (K.kadj D - D)

/-- Torsion (contorsion) part: the `kadj`-anti-self-adjoint piece. -/
def tor (a : R) : R := a - K.kadj a

/-- Nonmetricity part: the `kadj`-self-adjoint piece. -/
def nm (a : R) : R := a + K.kadj a

/-- The gauge closure / curvature `Q_C`, modelled as the non-normality commutator
`∇ ∇^# − ∇^# ∇`. -/
def Qc (D : R) : R := D * K.kadj D - K.kadj D * D

/-! ### Self-adjoint gauge class -/

/--
`E_#` vanishes on the self-adjoint gauge class `∇^# = ∇`.
-/
theorem Eslot_eq_zero_of_selfadj (φ D : R) (h : K.kadj D = D) :
    K.Eslot φ D = 0 := by
      -- Substitute $K.kadj D = D$ into the definition of $E_#$.
      simp [Soldering.KreinForm.Eslot, h]

/--
Conversely, if the turn field `φ` is left-invertible and `E_# = 0`, then the
connection is in the self-adjoint gauge class.
-/
theorem selfadj_of_Eslot_eq_zero (φ ψ D : R) (hφ : ψ * φ = 1)
    (h : K.Eslot φ D = 0) : K.kadj D = D := by
      simp_all +decide [ mul_sub, sub_eq_zero, KreinForm.Eslot ];
      apply_fun ( ψ * · ) at h; simp_all +decide [ ← mul_assoc ] ;

/-! ### General transformation law and tensoriality -/

/--
**General transformation law.** Under a finite frame change `∇ ↦ Ui ∇ U`
(`U` a unit with inverse `Ui`), the Krein adjoint is conjugated by `kadj U`:
`(Ui ∇ U)^# = (U^#) ∇^# (Ui^#)`, with `(U^#)(Ui^#) = 1`.
-/
theorem kadj_conj (U Ui D : R) :
    K.kadj (Ui * D * U) = K.kadj U * K.kadj D * K.kadj Ui := by
      convert K.kadj_mul ( Ui * D ) U using 1;
      rw [ K.kadj_mul, mul_assoc ]

/--
The frame-change factors of the adjoint are mutually inverse.
-/
theorem kadj_unit_inv (U Ui : R) (h : U * Ui = 1) :
    K.kadj Ui * K.kadj U = 1 := by
      rw [ ← K.kadj_mul, h, K.kadj_one ]

/--
**Tensorial transformation law.** On the Krein-unitary subgroup
(`kadj U = Ui`, i.e. `U^# = U⁻¹`, i.e. `U` preserves the metric), the E-slot
transforms *tensorially* — by conjugation — provided the turn field is carried
along, `φ ↦ Ui φ U`.  Hence `E_#` is a genuine geometric object, not an
inhomogeneously-transforming connection. -/
theorem Eslot_tensorial (U Ui φ D : R) (hUUi : U * Ui = 1)
    (hkrein : K.kadj U = Ui) :
    K.Eslot (Ui * φ * U) (Ui * D * U) = Ui * K.Eslot φ D * U := by
  have hUi : K.kadj Ui = U := by
    have h := congrArg K.kadj hkrein; rw [kadj_involutive] at h; exact h.symm
  unfold KreinForm.Eslot
  rw [kadj_conj, hkrein, hUi]
  calc (Ui * φ * U) * (Ui * K.kadj D * U - Ui * D * U)
      = Ui * φ * (U * Ui) * K.kadj D * U - Ui * φ * (U * Ui) * D * U := by noncomm_ring
    _ = Ui * φ * 1 * K.kadj D * U - Ui * φ * 1 * D * U := by rw [hUUi]
    _ = Ui * (φ * (K.kadj D - D)) * U := by noncomm_ring

/-! ### Torsion / nonmetricity split -/

/--
The two parities reconstruct twice the operator.
-/
theorem tor_add_nm (a : R) : K.nm a + K.tor a = a + a := by
  unfold KreinForm.nm KreinForm.tor; abel1;

/--
**Contorsion piece.** The torsion part is `kadj`-anti-self-adjoint, i.e.
metric-compatible — this is the contorsion.
-/
theorem kadj_tor (a : R) : K.kadj (K.tor a) = - K.tor a := by
  rw [ show K.tor a = a - K.kadj a from rfl, kadj_sub ];
  rw [ kadj_involutive, neg_sub ]

/--
**Nonmetricity piece.** The nonmetricity part is `kadj`-self-adjoint, i.e. the
metric-violating (`∇g ≠ 0`) defect.
-/
theorem kadj_nm (a : R) : K.kadj (K.nm a) = K.nm a := by
  simp +decide [ KreinForm.nm, add_comm ]

/-! ### No double-counting: distinct grade/parity sectors -/

/--
The closure / curvature `Q_C` is `kadj`-self-adjoint: it lives in the even
grade sector.
-/
theorem kadj_Qc (D : R) : K.kadj (K.Qc D) = K.Qc D := by
  unfold KreinForm.Qc; simp +decide [ KreinForm.kadj_sub, KreinForm.kadj_mul, KreinForm.kadj_involutive ] ;

/--
The torsion part of the E-slot is `kadj`-anti-self-adjoint: it lives in the odd
grade sector.
-/
theorem kadj_tor_Eslot (φ D : R) :
    K.kadj (K.tor (K.Eslot φ D)) = - K.tor (K.Eslot φ D) := by
  exact K.kadj_tor _

/--
**Unique grade decomposition.** Any operator splits uniquely into a
`kadj`-self-adjoint (even, gauge/closure) and a `kadj`-anti-self-adjoint (odd,
geometric/torsion) part; each part is recovered from the sum by a projection.
This is the finite grade/parity orthogonality underlying "no double-counting".
-/
theorem kadj_decomp_unique [Invertible (2 : R)] (s x y : R)
    (hx : K.kadj x = x) (hy : K.kadj y = -y) (hsum : x + y = s) :
    x = ⅟(2 : R) * (s + K.kadj s) ∧ y = ⅟(2 : R) * (s - K.kadj s) := by
  have hk : K.kadj s = x - y := by rw [← hsum, kadj_add, hx, hy, sub_eq_add_neg]
  refine ⟨?_, ?_⟩
  · rw [hk, ← hsum, show x + y + (x - y) = x + x by abel, ← two_mul]
    exact (invOf_mul_cancel_left 2 x).symm
  · rw [hk, ← hsum, show x + y - (x - y) = y + y by abel, ← two_mul]
    exact (invOf_mul_cancel_left 2 y).symm

/-- **No double-counting.** An even-grade (gauge/closure) quantity and an
odd-grade (geometric/torsion) quantity summing to zero must both vanish: the two
sectors are complementary, so `Q_C`-mass and `E_#`-torsion-mass are genuinely
distinct summands and cannot be confused. -/
theorem no_double_count [Invertible (2 : R)] (x y : R)
    (hx : K.kadj x = x) (hy : K.kadj y = -y) (h : x + y = 0) :
    x = 0 ∧ y = 0 := by
  have hxy := kadj_decomp_unique K 0 x y hx hy h
  simp [kadj_zero] at hxy
  exact hxy

/-- Specialisation: the gauge closure `Q_C` and the geometric torsion of `E_#`
occupy complementary grade sectors — they cannot cancel unless each is zero. -/
theorem Qc_tor_no_double_count [Invertible (2 : R)] (φ D : R)
    (h : K.Qc D + K.tor (K.Eslot φ D) = 0) :
    K.Qc D = 0 ∧ K.tor (K.Eslot φ D) = 0 :=
  K.no_double_count _ _ (K.kadj_Qc D) (K.kadj_tor_Eslot φ D) h

end KreinForm

/-! ## Concrete witnesses over `Matrix (Fin 2) (Fin 2) ℚ` (Euclidean `η = 1`) -/

/-- The Euclidean Krein form on `n×n` rational matrices (`η = 1`, so
`kadj a = star a = aᵀ`). -/
def matKrein (n : ℕ) : KreinForm (Matrix (Fin n) (Fin n) ℚ) where
  η := 1
  ηi := 1
  left_inv := by simp
  right_inv := by simp
  eta_selfadj := by simp

/-- For the Euclidean matrix Krein form the Krein adjoint is the ordinary
(conjugate-)transpose. -/
theorem matKrein_kadj (n : ℕ) (a : Matrix (Fin n) (Fin n) ℚ) :
    (matKrein n).kadj a = star a := by
  simp [matKrein, KreinForm.kadj]

/-- A non-Krein-unitary frame change (upper unitriangular, `Uᵀ ≠ U⁻¹`). -/
def Uwit : Matrix (Fin 2) (Fin 2) ℚ := !![1, 1; 0, 1]
/-- The genuine matrix inverse of `Uwit`. -/
def Uiwit : Matrix (Fin 2) (Fin 2) ℚ := !![1, -1; 0, 1]
/-- A turn field that does not commute with the defect (non-symmetric). -/
def phiwit : Matrix (Fin 2) (Fin 2) ℚ := !![1, 2; 0, 1]
/-- A non-self-adjoint connection (nilpotent, `Dᵀ ≠ D`). -/
def Dwit : Matrix (Fin 2) (Fin 2) ℚ := !![0, 1; 0, 0]

/-- `Uwit` is genuinely invertible with inverse `Uiwit`. -/
theorem Uwit_inv : Uwit * Uiwit = 1 := by
  simp only [Uwit, Uiwit, Matrix.mul_fin_two, Matrix.one_fin_two]; norm_num

/-- `Uwit` is **not** Krein-unitary: `kadj U ≠ U⁻¹`. -/
theorem Uwit_not_krein : (matKrein 2).kadj Uwit ≠ Uiwit := by
  intro h
  have h01 := congr_fun (congr_fun h 0) 1
  simp only [matKrein_kadj, Uwit, Uiwit, Matrix.star_apply, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.of_apply, Matrix.cons_val', Matrix.empty_val',
    Matrix.cons_val_fin_one, star_zero] at h01
  norm_num at h01

/-- **Inhomogeneity witness.** Off the Krein-unitary subgroup the E-slot does *not*
transform tensorially: the tensorial law fails for `Uwit`. -/
theorem Eslot_not_tensorial_witness :
    (matKrein 2).Eslot (Uiwit * phiwit * Uwit) (Uiwit * Dwit * Uwit)
      ≠ Uiwit * (matKrein 2).Eslot phiwit Dwit * Uwit := by
  intro h
  have h00 := congr_fun (congr_fun h 0) 0
  simp only [KreinForm.Eslot, matKrein_kadj, Uwit, Uiwit, phiwit, Dwit,
    Matrix.mul_apply, Matrix.sub_apply, Fin.sum_univ_two, Matrix.star_apply,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.of_apply, Matrix.cons_val',
    Matrix.empty_val', Matrix.cons_val_fin_one] at h00
  norm_num at h00

/-- **Pure-torsion is dead.** There is an `E_#` whose nonmetricity part is nonzero,
so the soldering channel is not pure teleparallel torsion. -/
theorem pure_torsion_dead_witness :
    (matKrein 2).nm ((matKrein 2).Eslot phiwit Dwit) ≠ 0 := by
  intro h
  have h00 := congr_fun (congr_fun h 0) 0
  simp only [KreinForm.nm, KreinForm.Eslot, matKrein_kadj, phiwit, Dwit,
    Matrix.add_apply, Matrix.mul_apply, Matrix.sub_apply, Fin.sum_univ_two,
    Matrix.star_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.of_apply,
    Matrix.zero_apply, Matrix.cons_val', Matrix.empty_val', Matrix.cons_val_fin_one,
    star_zero] at h00
  norm_num at h00

/-- The torsion part of the same witness is also nonzero (both defect types
genuinely present). -/
theorem tor_witness_ne_zero :
    (matKrein 2).tor ((matKrein 2).Eslot phiwit Dwit) ≠ 0 := by
  intro h
  have h10 := congr_fun (congr_fun h 1) 0
  simp only [KreinForm.tor, KreinForm.Eslot, matKrein_kadj, phiwit, Dwit,
    Matrix.mul_apply, Matrix.sub_apply, Fin.sum_univ_two, Matrix.star_apply,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.of_apply, Matrix.zero_apply,
    Matrix.cons_val', Matrix.empty_val', Matrix.cons_val_fin_one] at h10
  norm_num at h10

/-- The closure `Q_C` of the witness connection is nonzero. -/
theorem Qc_witness_ne_zero :
    (matKrein 2).Qc Dwit ≠ 0 := by
  intro h
  have h00 := congr_fun (congr_fun h 0) 0
  simp only [KreinForm.Qc, matKrein_kadj, Dwit, Matrix.mul_apply, Matrix.sub_apply,
    Fin.sum_univ_two, Matrix.star_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.of_apply, Matrix.zero_apply, Matrix.cons_val', Matrix.empty_val',
    Matrix.cons_val_fin_one] at h00
  norm_num at h00

/-! ## Axiom footprint check

Every result below reduces to the permitted kernel footprint
`[propext, Classical.choice, Quot.sound]` (no `sorry`, `native_decide`, or new
`axiom`). -/
section AxiomAudit
open Soldering.KreinForm

-- transformation law and geometric verdict
#print axioms Soldering.KreinForm.kadj_conj
#print axioms Soldering.KreinForm.Eslot_tensorial
#print axioms Soldering.KreinForm.selfadj_of_Eslot_eq_zero
#print axioms Soldering.KreinForm.Eslot_eq_zero_of_selfadj
-- torsion / nonmetricity classification
#print axioms Soldering.KreinForm.kadj_tor
#print axioms Soldering.KreinForm.kadj_nm
#print axioms Soldering.KreinForm.tor_add_nm
-- no double-counting
#print axioms Soldering.KreinForm.kadj_Qc
#print axioms Soldering.KreinForm.kadj_tor_Eslot
#print axioms Soldering.KreinForm.kadj_decomp_unique
#print axioms Soldering.KreinForm.no_double_count
#print axioms Soldering.KreinForm.Qc_tor_no_double_count
-- concrete witnesses
#print axioms Soldering.Uwit_inv
#print axioms Soldering.Uwit_not_krein
#print axioms Soldering.Eslot_not_tensorial_witness
#print axioms Soldering.pure_torsion_dead_witness
#print axioms Soldering.tor_witness_ne_zero
#print axioms Soldering.Qc_witness_ne_zero

end AxiomAudit

end Soldering