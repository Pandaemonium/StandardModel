# Summary of changes for run dead2dd5-0da0-457a-8e5b-ca9f42d74df2
Delivered a complete, kernel-checked formalization in `RequestProject/Main.lean` (plus `ARISTOTLE_SUMMARY.md`) of the Connes spectral distance for a finite null-edge carrier and the edge-recovery result on an explicit 2-vertex witness.

What was proved (all with axiom footprint exactly `[propext, Classical.choice, Quot.sound]`, no `sorry`/`admit`/`native_decide`/new `axiom`, verified by an in-file `#print axioms` guard and a clean build):

- Faithful definitions for a finite carrier: `diracCommutator D f = D·diag f − diag f·D`, the unit-Lipschitz ball `lipBall D = {f | ‖[D,f]‖ ≤ 1}` using Mathlib's genuine L² matrix operator norm (C*-norm on `EuclideanSpace ℂ (Fin n)`), and `spectralDist D x y = sSup {|f x − f y| : f ∈ lipBall D}`. A reusable general lemma `entry_norm_le_l2_opNorm` bounds each matrix entry by the L² operator norm.
- The witness `Dm m = ![![0,m],![m,0]]` (mass/decoration scale `m>0`), shown self-adjoint; the commutator entry computed exactly as `m·(f 1 − f 0)`; the optimizer `fwit m = ![0,1/m]` whose commutator is the unitary rotation matrix of operator norm 1.
- The prize, `spectral_distance_two_point`: `spectralDist (Dm m) 0 1 = 1/m`, via an `IsGreatest` argument (upper bound `lipBall_sep_le` + attainment `fwit_mem_lipBall`/`fwit_sep`).
- `spectral_distance_recovers_edges`: the adjacent pair is placed at finite positive distance `1/m`, with unit mass (`m=1`) giving a unit edge — vertices and distances recovered from `(A,D)`, decoration scale sets the units.
- `spectral_distance_nondegenerate`: distance is strictly positive and finite (the degeneracy "Kill" condition is avoided).
- Finite Malament step `causal_order_recovers_adjacency`: the causal-link relation `CausallyLinked D` read off from `D` reproduces exactly the carrier's adjacency on the witness.

Honest boundary (also in the summary file): this is background independence on a finite witness, not a continuum reconstruction theorem; the definitions are stated for general finite `n` but the `= 1/m` computation is for the 2-vertex carrier. The self-adjoint (Riemannian) witness carries no time arrow, so `CausallyLinked` is the symmetric adjacency relation; orienting it into a genuine causal order via a Lorentzian/Krein form is set up in the definition but left as the next step, not claimed.

# Background independence via the Connes spectral distance — finite witness

This project formalizes, in Lean 4 + Mathlib, the **Connes spectral distance** for a finite
null-edge carrier and proves that on an explicit witness it *recovers* the metric and
adjacency data of the carrier from the algebraic datum `(A, D)` alone. All results are
kernel-checked, with no `sorry` / `admit` / `native_decide` / new `axiom`, and the axiom
footprint of every headline theorem is exactly `[propext, Classical.choice, Quot.sound]`
(verified in-file by `#print axioms` at the bottom of `RequestProject/Main.lean`).

## What was delivered

All content is in `RequestProject/Main.lean`.

### 1. The spectral distance, defined for a finite carrier

* `NullEdge.diracCommutator D f = D * diagonal f - diagonal f * D` — the commutator `[D, f]`
  of the Dirac operator `D : Matrix (Fin n) (Fin n) ℂ` with the diagonal multiplication
  operator of a function `f` on the vertex set.
* `NullEdge.lipBall D = { f | ‖[D,f]‖ ≤ 1 }` — the unit-Lipschitz ball. The norm `‖·‖` is
  the genuine **L² operator norm** of matrices (Mathlib's `Matrix.Norms.L2Operator`
  C*-norm, i.e. the operator norm on `EuclideanSpace ℂ (Fin n)`), so the formalization is
  faithful to Connes' definition, not a proxy.
* `NullEdge.spectralDist D x y = sSup { |f x − f y| : f ∈ lipBall D }` — the spectral
  distance.

A reusable general lemma `entry_norm_le_l2_opNorm` shows each matrix entry is bounded by the
L² operator norm; this is what turns the sup into a finite optimization.

### 2. The 2-vertex witness (T2 carrier)

* `NullEdge.Dm m = ![![0, m], ![m, 0]]` with decoration / mass scale `m > 0`, shown
  self-adjoint (`Dm_isSelfAdjoint`), so it is a legitimate Dirac operator.
* The commutator entry is computed exactly: `[Dm m, f]₀₁ = m·(f 1 − f 0)`
  (`diracComm_Dm_entry01`).
* The optimizer `fwit m = ![0, 1/m]` has commutator equal to the unitary rotation matrix
  `![![0,1],![-1,0]]` (`diracComm_Dm_fwit`), whose L² operator norm is exactly `1`
  (`rotation_l2_opNorm`, via `CStarRing.norm_of_mem_unitary`).

### 3. The prize — edge recovery

* `spectral_distance_two_point` : `spectralDist (Dm m) 0 1 = 1 / m` for `m > 0`.
  Proved as an `IsGreatest` statement: the upper bound `lipBall_sep_le` (from the
  entry/operator-norm bound) and attainment `fwit_mem_lipBall` + `fwit_sep`.
* `spectral_distance_recovers_edges` : the adjacent pair `0, 1` is placed at the finite,
  strictly positive distance `1/m`, and a unit mass scale (`m = 1`) recovers exactly a
  unit edge. So the vertex set and its distances are read off from `(A, D)`; the decoration
  scale `m` sets the units.
* `spectral_distance_nondegenerate` : `0 < spectralDist (Dm m) 0 1` — the "Kill" condition
  (distance degenerating to `0` or `∞`) is avoided.

### 4. Finite Malament step — causal order

* `NullEdge.CausallyLinked D x y := (x = y) ∨ (D x y ≠ 0)` — the causal-link relation read
  directly from the Dirac operator.
* `causal_order_recovers_adjacency` : on the witness every pair of vertices is causally
  linked, reproducing exactly the adjacency of the complete 2-vertex graph. The
  topological/adjacency data is thus recovered from `(A, D)`.

## Honest boundary

* This is **background independence on a finite witness**, not a continuum reconstruction
  theorem. The result is proved for the explicit 2-vertex (T2) carrier; the definitions
  (`diracCommutator`, `lipBall`, `spectralDist`, `CausallyLinked`, `entry_norm_le_l2_opNorm`)
  are stated for general finite `n`, but the metric computation `= 1/m` is established for
  this witness.
* The witness Dirac operator is self-adjoint (Riemannian), so it carries **no time arrow**:
  `CausallyLinked` here is the symmetric adjacency relation. The definition is written so
  that, in a genuine Lorentzian/Krein carrier, the sign of the Krein form would orient the
  relation into a causal *order*; formalizing that orientation is left as the natural next
  step and is not claimed here.
* No claim is made about whether these particular definitions/results already appear in
  Mathlib; the spectral-distance and carrier definitions here are project-local.

## Verification

`RequestProject/Main.lean` builds cleanly. The in-file `#print axioms` guard reports, for
each headline theorem, dependence only on `[propext, Classical.choice, Quot.sound]`.
