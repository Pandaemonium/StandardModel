# Summary of changes for run 83a6ffc5-8b18-48d4-a76b-c97184229580
Completed the finite-seesaw formalization (Conjecture E) in `src/SchurSeesaw.lean` (namespace `PhysicsSM.Draft.NullEdge.SchurSeesaw`). The file builds cleanly against Mathlib, has no `sorry`/`admit`/`native_decide` and introduces no new axioms; in-file `#print axioms` guards plus verification confirm every delivered theorem has footprint exactly `[propext, Classical.choice, Quot.sound]`.

Delivered results (with the `True` placeholders replaced by the real statements):

- `seesaw_suppression` (Target 1): for a coupling `B` from the visible sector to a positive-definite hidden block `M`, and a protected mode `v` with `A *ᵥ v = 0`, the induced effective mass obeys `|⟨v, (A − B M⁻¹ Bᴴ) v⟩| ≤ ‖Bᴴ v‖² / λ_min(M)`, written concretely as `|(star v ⬝ᵥ (A − B M⁻¹ Bᴴ) *ᵥ v).re| ≤ (star (Bᴴ *ᵥ v) ⬝ᵥ (Bᴴ *ᵥ v)).re / leastEigen hM`. As the hidden scale `λ_min(M) → ∞` the bound → 0 (resolvent suppression, not tuning).
- `seesaw_zero_iff_no_overlap` (Target 2): `⟨v, (A − B M⁻¹ Bᴴ) v⟩ = 0 ↔ Bᴴ *ᵥ v = 0` — the induced mass vanishes iff the protected mode has no overlap with the hidden coupling.

Supporting lemmas:
- `seesaw_effective_mass_eq`: `⟨v, (A − B M⁻¹ Bᴴ) v⟩ = −⟨Bᴴ v, M⁻¹ (Bᴴ v)⟩` on a protected mode.
- `resolvent_quadratic_bound` (the resolvent estimate used): `⟨w, M⁻¹ w⟩ ≤ ‖w‖² / λ_min(M)` for positive-definite `M`, proved via the eigenbasis of `M`.
- `leastEigen`/`leastEigen_pos`/`leastEigen_le`: the least eigenvalue `λ_min(M)` and its basic facts.

Honesty note (also in `ARISTOTLE_SUMMARY.md`): the suppression bound is the clean `‖Bᴴ v‖² / λ_min(M)` with unit constant — no different constant is needed; `‖·‖²` denotes the Euclidean squared norm `(star · ⬝ᵥ ·).re`. The only added hypothesis beyond the prompt is `[Nonempty nh]` on the bound (a nonempty hidden block), required so that `λ_min(M)` is well-defined; the Hermitian hypothesis on `A` turned out unnecessary for this quantity since `A *ᵥ v = 0` kills the visible term. A short writeup is in `ARISTOTLE_SUMMARY.md`. All work is committed and pushed.

# Finite seesaw — small mass from protected leakage through a heavy hidden block (Conjecture E)

All results live in `src/SchurSeesaw.lean`, namespace
`PhysicsSM.Draft.NullEdge.SchurSeesaw`. The file builds cleanly against Mathlib,
contains no `sorry`/`admit`/`native_decide` and introduces no new axioms. The
in-file `#print axioms` guards confirm every delivered theorem has footprint
exactly `[propext, Classical.choice, Quot.sound]`.

## Setup / conventions

For a visible block `A : Matrix nv nv ℂ`, a coupling `B : Matrix nv nh ℂ` and a
hidden block `M : Matrix nh nh ℂ`, integrating out the hidden register produces the
effective (Schur-complement) visible operator `A − B M⁻¹ Bᴴ`. A *protected* mode is
`v : nv → ℂ` with `A *ᵥ v = 0`. The (squared) Euclidean norm of a vector `w` is
written `(star w ⬝ᵥ w).re = ∑ i, ‖w i‖²`, and the quadratic form `⟨w, X w⟩` is
`star w ⬝ᵥ X *ᵥ w`. The least eigenvalue `λ_min(M)` is `leastEigen hM`, defined as
`Finset.univ.inf' _ hM.1.eigenvalues` (requires `[Nonempty nh]`, i.e. a nonempty
hidden block) and shown positive (`leastEigen_pos`).

## Delivered results

### `seesaw_effective_mass_eq`
On a protected mode, the induced effective mass is exactly the (negated) hidden
resolvent form:
`star v ⬝ᵥ (A − B M⁻¹ Bᴴ) *ᵥ v = −(star (Bᴴ *ᵥ v) ⬝ᵥ M⁻¹ *ᵥ (Bᴴ *ᵥ v))`.
Since `A *ᵥ v = 0`, the visible term drops out and only the leakage channel `Bᴴ v`
into `M⁻¹` survives.

### `resolvent_quadratic_bound` (the resolvent lemma used)
For positive-definite `M` and any hidden vector `w`,
`(star w ⬝ᵥ M⁻¹ *ᵥ w).re ≤ (star w ⬝ᵥ w).re / leastEigen hM`,
i.e. `⟨w, M⁻¹ w⟩ ≤ ‖w‖² / λ_min(M)`. Proof: diagonalize `M` in its orthonormal
eigenbasis; `M⁻¹` acts by `1/μ_j` on eigenvector `j`, so the form is
`∑_j |c_j|²/μ_j ≤ (1/λ_min) ∑_j |c_j|²`, using `μ_j ≥ λ_min > 0` termwise.

### `seesaw_suppression` (TARGET 1 — the exact suppression bound)
`|(star v ⬝ᵥ (A − B M⁻¹ Bᴴ) *ᵥ v).re| ≤ (star (Bᴴ *ᵥ v) ⬝ᵥ (Bᴴ *ᵥ v)).re / leastEigen hM`,
that is
`|⟨v, (A − B M⁻¹ Bᴴ) v⟩| ≤ ‖Bᴴ v‖² / λ_min(M)`.
This is exactly the clean bound — **no extra constant is needed**: the constant is
literally `1`, giving `‖Bᴴ v‖² / λ_min(M)`. As the hidden scale grows
(`λ_min(M) → ∞`) the induced visible mass is driven to `0`: resolvent suppression,
not tuning. (Because `A *ᵥ v = 0` kills the visible contribution, no Hermitian
hypothesis on `A` is required for this quantity; the estimate is a pure resolvent
bound. `M` positive-definite is what is used.)

### `seesaw_zero_iff_no_overlap` (TARGET 2 — exact protection)
`star v ⬝ᵥ (A − B M⁻¹ Bᴴ) *ᵥ v = 0 ↔ Bᴴ *ᵥ v = 0`:
the induced effective mass vanishes **iff** the protected mode has no overlap with
the hidden coupling. Protection is exact iff the leakage channel is closed. Proof:
the mass equals `−⟨Bᴴ v, M⁻¹ (Bᴴ v)⟩` with `M⁻¹` positive-definite, so it is zero
iff `Bᴴ v = 0`.

## Honesty note on the constant

The suppression bound is the clean `‖Bᴴ v‖² / λ_min(M)` with unit constant; no
weaker constant was required. `‖·‖²` is the Euclidean squared norm written
concretely as `(star · ⬝ᵥ ·).re`. The only structural hypothesis added beyond the
prompt is `[Nonempty nh]` in the bound (and its helper lemmas), needed so that the
minimum eigenvalue `λ_min(M)` is well-defined; this is exactly the statement that a
hidden block is present, which is intrinsic to the seesaw mechanism.
