# Strategy memo — QC-leading bridge after finite `Z2` normalization

Scope: decision-forcing review of the next honest bridge from the GateYM
finite-`Z2` leading closure-flux coefficient to the carrier torus curvature slot.
No code is patched here. Mathlib lemma names below were checked against the
pinned toolchain (`Real.tanh_lt_one`, `Real.neg_one_lt_tanh` exist; strict
positivity of `tanh` on `(0,∞)` is `by rw [Real.tanh_eq_sinh_div_cosh]; positivity`).

---

## 0. One-paragraph verdict

The current `QCLeading` surface is **logically sound but rhetorically
over-labelled**, and it does **not yet reach anything on the carrier side**.
Every theorem in `QCLeading.lean` is a scalar identity about `Real.tanh beta`
(via `TYAreaLaw.partitionRatio`); nothing in it touches `Z2`, an operator, a
measure, or an expectation. The carrier `nabla_commutator_path_difference` is an
operator identity over `Site = ZMod 2 × ZMod 2`. **There is no shared object**
(no scalar observable extracted from `plaquetteCurvature`) connecting the two.
Therefore the next bridge must be either (a) a pure GateYM sharpening, (b) a pure
carrier corollary of the proved curvature identity, or (c) a *statement-level
contract* that names the missing observable as a parameter. An expectation
theorem `⟨Q_C⟩ = tanh beta` is **not** derivable now and would be an overclaim.

---

## 1. Can the current decomposition succeed as stated, or is it mis-scoped?

**As identities: yes, it succeeds and is already essentially kernel-checked.**
`leadingClosureFluxCoeff_eq_partitionRatio` (`rfl`),
`leadingClosureFluxCoeff_eq_tanh`, `_eq_exp_neg_osSpectralGap` (guarded by
`0 < beta`), and the `Z2LeadingQCReadout` bundle are all true and non-vacuous.
The `0 < beta` hypothesis is load-bearing (for `beta ≤ 0`, `tanh beta ≤ 0` and
`exp (-gap)` / `log (tanh beta)` break), so the guard is correct, not decorative.

**As a bridge: it is mis-scoped by naming, and incomplete by construction.**

- **Naming over-reach.** The file is named `QCLeading` and exports
  `Z2LeadingQCReadout`, `os_gap_value`, `SlabGapChain`, but the mathematical
  content is exactly "`leadingClosureFluxCoeff beta = tanh beta` and its `log`/`exp`
  rearrangements." There is **no `Z2` structure and no spectral operator** in the
  file. If `OSReconstruction.osSpectralGap` is *defined* as
  `-Real.log (partitionRatio beta)`, then `os_gap_value` is a definitional
  relabelling, and calling it a "spectral gap" invites a reader to think a
  transfer-matrix spectrum was analysed. That is the single biggest scoping risk:
  a correct scalar identity wearing an operator-theoretic costume.
- **Structural gap to the carrier.** `leadingClosureFluxCoeff : ℝ` is a number;
  `plaquetteCurvature U a b : Site → (W →ₗ[R] W)` is an operator field. No map
  from the latter to the former exists in-tree. Until a scalar observable is
  defined on the carrier side, *no equality theorem can bridge the two*, and any
  `⟨Q_C⟩`-shaped statement would be vacuous-or-false rather than a theorem.

**Conclusion for Q1:** keep the identities; treat the `QCLeading` bundle as a
*coefficient readout*, not a QC bridge. Do **not** grow it into an expectation
claim. The bridge is a separate, still-missing rung.

---

## 2. Sharpest honest next decomposition (finite `Z2` coeff → carrier curvature)

Four rungs, each independently checkable, ordered so that no rung assumes an
object that does not yet exist:

1. **Coefficient shape (pure GateYM).** Pin the *analytic character* of the
   leading coefficient that any later positivity would rest on: `0 < coeff < 1`
   for `beta > 0`, and strict monotonicity in `beta`. This is the honest,
   non-overclaiming precursor to positivity — it says the leading closure-flux
   weight is a strict probability-like factor, and stops there.

2. **Curvature corollary (pure carrier).** Read off the *one cheap direction* of
   the proved `nabla_commutator_path_difference`: vanishing plaquette curvature ⇒
   covariant differences commute. This needs **no** shift invertibility and does
   **not** collide with the `mZero_iff_commute` iff job (which owns the hard
   converse). It is the "flat ⇒ closed" leading-order fact.

3. **Bridge contract (statement-level design file).** Introduce an *interface*
   `Prop` that takes the carrier-side scalar observable as a **parameter** (a
   function `Site → (W →ₗ[R] W)` data ↦ `ℝ`, or a plain `ℝ` placeholder) and
   asserts the leading-order normalization `observable = leadingClosureFluxCoeff
   beta` **as a field**, together with the `0 < · < 1` bounds from rung 1. This
   commits to *what Q_C's carrier scalar must be* without asserting any measure
   or expectation. No `axiom`, no `@[implemented_by]`; the observable is a
   hypothesis/parameter.

4. **(Deferred) expectation bridge.** Only after an actual observable/measure is
   defined on the carrier can `⟨Q_C⟩ = tanh beta` (or a bound) be *stated*, and
   even then leading-order only. This rung is **out of scope now** and should not
   be attempted before rung 3 is ratified.

Rungs 1 and 2 are pure mathematics, safe to implement immediately. Rung 3 is a
modeling commitment and should be ratified first (see §5). Rung 4 is blocked.

---

## 3. Counterexample / vacuity / overclaim risks in the current `QCLeading` surface

- **Overclaim by naming (`osSpectralGap`, `SlabGapChain`, `Z2...`).** Highest
  risk. Nothing false, but the labels suggest a proven transfer-Hamiltonian
  spectral gap and `Z2`-specific content that the file does not contain. If
  `osSpectralGap := -log (partitionRatio)`, state that plainly in the docstring
  so `os_gap_value` is not mistaken for a spectral theorem. **Do not** let this
  file be cited as evidence of a mass gap.
- **Bundle inflation / weakness masquerading as strength.** `Z2LeadingQCReadout`
  is a conjunction of true relabellings; it is not vacuous, but it is *weak* and
  easy to over-cite. Keep it as a convenience readout, not a headline result.
- **`0 < beta` correctly guards genuine failure, not vacuity.** For `beta ≤ 0`
  the `exp/log` identities are false, so the guard is load-bearing. Good — but it
  means any downstream statement inherits the `beta > 0` regime; don't silently
  drop it.
- **No positivity-beyond-leading-order is present — keep it that way.** The
  honest ceiling now is `0 < coeff < 1` (rung 1). Do **not** add `⟨Q_C⟩ ≥ 0` in
  general, an `SU(2)` claim, a continuum gap, or a Wilson/TY-ratio = transfer-gap
  equality in generality. Each is on the prohibited list and none is in reach.
- **Bridge vacuity trap.** If a `⟨Q_C⟩ = coeff` statement is written before a real
  observable exists, it will either be vacuous (guarded by an unsatisfiable
  hypothesis) or false. Rung 3's *parameterized* contract avoids this by making
  the observable an explicit input rather than a fabricated definition.

---

## 4. Three highest-value next Lean statements

Namespaces follow the existing tree. Sketches are precise enough to implement;
proof hints are honest (checked lemma names where relevant).

### 4.1 `leadingClosureFluxCoeff_mem_Ioo` — pure GateYM, do now

```lean
namespace PhysicsSM.Draft.NullEdge.GateYM.QCLeading

/-- Leading closure-flux weight is a strict probability-like factor for `β > 0`.
    This is the honest analytic precursor to any later positivity claim; it does
    NOT assert positivity of `⟨Q_C⟩` beyond leading order. -/
theorem leadingClosureFluxCoeff_mem_Ioo {beta : ℝ} (hbeta : 0 < beta) :
    leadingClosureFluxCoeff beta ∈ Set.Ioo (0 : ℝ) 1 := by
  rw [leadingClosureFluxCoeff_eq_tanh]
  refine ⟨?_, Real.tanh_lt_one beta⟩
  rw [Real.tanh_eq_sinh_div_cosh]; positivity
```

Value: gives downstream the exact `0 < coeff < 1` fact, isolates the honest
positivity ceiling, zero overclaim. Optional companion:
`leadingClosureFluxCoeff_lt_one (beta : ℝ) : leadingClosureFluxCoeff beta < 1`
(unconditional, `Real.tanh_lt_one`) and a strict-monotonicity lemma
`leadingClosureFluxCoeff` on `Set.Ici 0` if a monotone `tanh` fact is available
(derive from `Real.artanh` order-iso or `deriv`; flag as a small sub-search).

### 4.2 `nabla_commute_of_plaquetteCurvature_zero` — pure carrier, do now

```lean
namespace PhysicsSM.Draft.NullEdge.Carrier.Torus

/-- Flat ⇒ closed (leading order): if every plaquette curvature vanishes as a
    section, the covariant differences commute. One-directional corollary of
    `nabla_commutator_path_difference`; needs no shift invertibility and does not
    overlap the `mZero_iff_commute` converse. -/
theorem nabla_commute_of_plaquetteCurvature_zero
    (U : Fin 2 → Site → (W →ₗ[R] W))
    (h : ∀ a b, plaquetteCurvature U a b = 0) (a b : Fin 2) :
    (nabla U a).comp (nabla U b) = (nabla U b).comp (nabla U a) := by
  have hid := nabla_commutator_path_difference U a b
  -- rewrite RHS: gaugeLM 0 = 0, hence composite = 0, hence commutator = 0
  -- then `sub_eq_zero` gives the equality
  sorry
```

Value: the first genuinely *carrier-side* leading-order consequence of the landed
curvature identity, cheap, and it is exactly the "closure defect controls
commutativity" direction that the eventual `Q_C` slot needs — without claiming
the iff. Implementation: `gaugeLM_zero`/`map_zero` on the plaquette section, then
`sub_eq_zero.mp`.

### 4.3 `LeadingQCCarrierContract` — statement-level bridge design file (ratify first)

New file `PhysicsSM/Draft/NullEdge/GateYM/QCCarrierBridge.lean`:

```lean
namespace PhysicsSM.Draft.NullEdge.GateYM.QCLeading

/-- Statement-level contract for the leading-order QC bridge. The carrier-side
    scalar observable `qc` is a PARAMETER, not a defined measure/expectation:
    this file fixes *what the bridge must say* (leading normalization to
    `tanh β`, with the strict `(0,1)` window) without constructing an observable
    or asserting any expectation. To be discharged only once a real observable
    exists; introduces no axioms. -/
structure LeadingQCCarrierContract (beta : ℝ) (hbeta : 0 < beta) (qc : ℝ) : Prop where
  observable_eq_leadingCoeff : qc = leadingClosureFluxCoeff beta
  coeff_pos  : 0 < leadingClosureFluxCoeff beta
  coeff_lt_one : leadingClosureFluxCoeff beta < 1

/-- Sanity: the contract is inhabited exactly at the leading value (no vacuity,
    no overclaim). -/
theorem leadingQCCarrierContract_at_coeff (beta : ℝ) (hbeta : 0 < beta) :
    LeadingQCCarrierContract beta hbeta (leadingClosureFluxCoeff beta) where
  observable_eq_leadingCoeff := rfl
  coeff_pos := (leadingClosureFluxCoeff_mem_Ioo hbeta).1
  coeff_lt_one := (leadingClosureFluxCoeff_mem_Ioo hbeta).2
```

Value: makes the missing rung explicit and *forces the observable-definition
decision into the open* while proving only what is honestly provable (that the
contract is inhabited at the leading value). It cannot be mistaken for an
expectation theorem because `qc` is an input. When a real observable
`qcCarrier U ... : ℝ` is later defined, the open obligation is precisely
`qcCarrier ... = leadingClosureFluxCoeff beta` — nothing more, leading order only.

---

## 5. What to send to Fable call 03 before proof spend

- **Ratify: 4.3 `LeadingQCCarrierContract`** (and, implicitly, the definition of
  the carrier-side scalar observable it anticipates). This is a *modeling
  commitment*: asserting that the carrier `Q_C` scalar normalizes to `tanh beta`
  at leading order is a design choice, not a theorem derivable from current
  in-tree objects. Ratify the contract shape (fields, the `qc` parameter, the
  `beta > 0` regime, "leading order only") **before** anyone defines `qcCarrier`
  and spends proof effort on `observable_eq_leadingCoeff`.
- **Do not gate 4.1 and 4.2 on Fable.** Both are pure mathematics with no
  modeling content: 4.1 is a `tanh` window bound, 4.2 is a one-line corollary of
  an already-landed identity. Implement them immediately; they de-risk 4.3 and
  produce checkable value regardless of the ratification outcome.
- **Explicitly out of scope until after ratification (and mostly beyond it):**
  any `⟨Q_C⟩` expectation theorem, any nonabelian/`SU(2)` statement, continuum or
  physical mass gap, general Wilson/TY-ratio = transfer-gap equality, and
  positivity beyond leading order. If Fable wants forward motion beyond 4.1–4.3,
  the correct next request is a *definition* of the carrier observable/measure,
  not another identity bundle.

---

### Bottom line

Ship 4.1 and 4.2 now (pure, honest, cheap). Freeze the `QCLeading` bundle as a
labelled *coefficient readout* and tighten its docstrings so `osSpectralGap`/
`Z2`/`SlabGap` naming cannot be read as spectral or `Z2`-structural results. Send
the 4.3 contract (plus the yet-to-be-defined carrier observable it names) to
Fable call 03 for ratification before any expectation-bridge proof spend.
